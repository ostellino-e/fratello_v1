/* =========================================================
   FRATELLO v4.0 — SEGURIDAD, USUARIOS, DISPOSITIVOS Y BACKUPS
   ========================================================= */

const SEG_STORAGE_KEY = "fratello_seguridad_v400";
const SEG_DEVICE_KEY = "fratello_device_id_v400";
const SEG_DEVICE_NAME_KEY = "fratello_device_name_v400";
const SEG_AUDIT_LIMIT = 250;
let seguridadFratello = { usuarios: [], dispositivos: [], auditoria: [], backups: [] };
let dispositivoFratelloActual = null;
let dispositivoAutorizadoActual = false;
let usuarioSeguridadEdicionId = null;

function segId(prefijo) {
  return `${prefijo}_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;
}
function segAhora() { return new Date().toISOString(); }
function segEscapar(valor) {
  return String(valor ?? "").replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
}
function segCargarLocal() {
  try {
    const raw = JSON.parse(localStorage.getItem(SEG_STORAGE_KEY) || "null");
    if (raw && typeof raw === "object") seguridadFratello = {
      usuarios: Array.isArray(raw.usuarios) ? raw.usuarios : [],
      dispositivos: Array.isArray(raw.dispositivos) ? raw.dispositivos : [],
      auditoria: Array.isArray(raw.auditoria) ? raw.auditoria : [],
      backups: Array.isArray(raw.backups) ? raw.backups : []
    };
  } catch (e) { console.warn("Seguridad local:", e); }
}
function segGuardarLocal() {
  localStorage.setItem(SEG_STORAGE_KEY, JSON.stringify(seguridadFratello));
}
function segNombreDispositivo() {
  const ua = navigator.userAgent || "";
  const movil = /Android|iPhone|iPad/i.test(ua);
  const navegador = /Edg/i.test(ua) ? "Edge" : /Chrome/i.test(ua) ? "Chrome" : /Firefox/i.test(ua) ? "Firefox" : /Safari/i.test(ua) ? "Safari" : "Navegador";
  const sistema = /Windows/i.test(ua) ? "Windows" : /Android/i.test(ua) ? "Android" : /iPhone|iPad/i.test(ua) ? "iPhone/iPad" : /Mac/i.test(ua) ? "Mac" : "Equipo";
  return `${movil ? "Celular" : "PC"} ${sistema} · ${navegador}`;
}
function segObtenerDispositivoActual() {
  let id = localStorage.getItem(SEG_DEVICE_KEY);
  if (!id) {
    id = segId("device");
    localStorage.setItem(SEG_DEVICE_KEY, id);
  }
  let nombre = localStorage.getItem(SEG_DEVICE_NAME_KEY);
  if (!nombre) {
    nombre = segNombreDispositivo();
    localStorage.setItem(SEG_DEVICE_NAME_KEY, nombre);
  }
  return { id, nombre, userAgent: navigator.userAgent || "", ultimaActividad: segAhora() };
}
async function segGuardarRemoto() {
  segGuardarLocal();
  if (!db || !usuarioAdministradorActual?.uid) return;
  try {
    await db.collection("seguridadFratello").doc("configuracion").set(seguridadFratello, { merge: true });
  } catch (e) {
    console.warn("No se pudo sincronizar seguridad:", e);
  }
}
async function segCargarRemoto() {
  segCargarLocal();
  if (!db || !usuarioAdministradorActual?.uid) return;
  try {
    const snap = await db.collection("seguridadFratello").doc("configuracion").get();
    if (snap.exists) {
      const data = snap.data() || {};
      seguridadFratello = {
        usuarios: Array.isArray(data.usuarios) ? data.usuarios : seguridadFratello.usuarios,
        dispositivos: Array.isArray(data.dispositivos) ? data.dispositivos : seguridadFratello.dispositivos,
        auditoria: Array.isArray(data.auditoria) ? data.auditoria : seguridadFratello.auditoria,
        backups: Array.isArray(data.backups) ? data.backups : seguridadFratello.backups
      };
      segGuardarLocal();
    }
  } catch (e) {
    console.warn("Seguridad remota no disponible; se usa copia local:", e);
  }
}
async function segAuditar(tipo, accion, detalle = "") {
  const item = {
    id: segId("audit"), fecha: segAhora(), tipo, accion, detalle,
    usuario: usuarioAdministradorActual?.email || "Sin identificar",
    uid: usuarioAdministradorActual?.uid || "",
    dispositivoId: dispositivoFratelloActual?.id || "",
    dispositivo: dispositivoFratelloActual?.nombre || segNombreDispositivo()
  };
  seguridadFratello.auditoria.unshift(item);
  seguridadFratello.auditoria = seguridadFratello.auditoria.slice(0, SEG_AUDIT_LIMIT);
  await segGuardarRemoto();
  renderAuditoriaSeguridad();
}
function segPermisosPorRol(rol) {
  const mapa = {
    administrador: ["produccion","pedidos","caja","administracion","configuracion"],
    encargado: ["produccion","pedidos","caja"],
    atencion: ["pedidos","caja"],
    produccion: ["produccion","pedidos"]
  };
  return mapa[rol] || [];
}
function segRolDelUsuario(usuario) {
  if (!usuario) return null;
  const email = String(usuario.email || "").toLowerCase();
  const registrado = seguridadFratello.usuarios.find(u => String(u.email || "").toLowerCase() === email && u.activo !== false);
  if (registrado) return registrado.rol || "atencion";
  return "administrador"; // compatibilidad y primer administrador
}
function obtenerRolUsuario(usuario) {
  return segRolDelUsuario(usuario);
}
function tieneRolAdministrador() {
  return Boolean(usuarioAdministradorActual && rolUsuarioActual === "administrador" && dispositivoAutorizadoActual);
}
function segAplicarPermisosUI() {
  const rol = rolUsuarioActual;
  const usuario = seguridadFratello.usuarios.find(u => String(u.email || "").toLowerCase() === String(usuarioAdministradorActual?.email || "").toLowerCase());
  const permisos = usuario?.permisos?.length ? usuario.permisos : segPermisosPorRol(rol);
  const puedeAdmin = permisos.includes("administracion") && dispositivoAutorizadoActual;
  $("tarjetaAdministracionInicio")?.classList.toggle("hidden", !puedeAdmin);
  document.body.dataset.rolFratello = rol || "invitado";
}
async function segVerificarDispositivo(usuario) {
  dispositivoFratelloActual = segObtenerDispositivoActual();
  if (!usuario) {
    dispositivoAutorizadoActual = false;
    return false;
  }
  await segCargarRemoto();
  const existentes = seguridadFratello.dispositivos.filter(d => d.uid === usuario.uid);
  let actual = existentes.find(d => d.id === dispositivoFratelloActual.id);
  if (!actual) {
    const primerDispositivo = existentes.length === 0;
    actual = {
      ...dispositivoFratelloActual,
      uid: usuario.uid,
      email: usuario.email || "",
      estado: primerDispositivo ? "autorizado" : "pendiente",
      creadoEn: segAhora(),
      ultimaActividad: segAhora()
    };
    seguridadFratello.dispositivos.unshift(actual);
    await segGuardarRemoto();
    await segAuditar("dispositivo", primerDispositivo ? "Primer dispositivo autorizado" : "Nuevo dispositivo pendiente", actual.nombre);
  } else {
    actual.ultimaActividad = segAhora();
    actual.nombre = actual.nombre || dispositivoFratelloActual.nombre;
    await segGuardarRemoto();
  }
  dispositivoAutorizadoActual = actual.estado === "autorizado";
  renderDispositivosSeguridad();
  if (!dispositivoAutorizadoActual) {
    alert("Este dispositivo todavía no está autorizado. Ingresá desde un equipo autorizado para aprobarlo.");
    try { await authFratello?.signOut(); } catch {}
    return false;
  }
  return true;
}
function renderUsuariosSeguridad() {
  const cont = $("listaUsuariosSeguridad");
  if (!cont) return;
  if (!seguridadFratello.usuarios.length) {
    cont.innerHTML = '<div class="securityEmpty">Todavía no agregaste usuarios. Tu cuenta actual continúa como administrador principal.</div>';
    return;
  }
  cont.innerHTML = seguridadFratello.usuarios.map(u => `
    <article class="securityRow">
      <div class="securityAvatar">${u.rol === "administrador" ? "👑" : u.rol === "produccion" ? "👨‍🍳" : u.rol === "atencion" ? "🧾" : "👨‍💼"}</div>
      <div class="securityRowMain"><strong>${segEscapar(u.nombre || u.email)}</strong><small>${segEscapar(u.email)} · ${segEscapar(u.rol)}</small>
      <div class="securityPermissionTags">${(u.permisos || []).map(p => `<span>${segEscapar(p)}</span>`).join("")}</div></div>
      <span class="securityStatus ${u.activo === false ? "blocked" : "authorized"}">${u.activo === false ? "Bloqueado" : "Activo"}</span>
      <div class="securityRowActions"><button onclick="editarUsuarioSeguridad('${u.id}')">Editar</button><button onclick="alternarUsuarioSeguridad('${u.id}')">${u.activo === false ? "Activar" : "Bloquear"}</button><button class="danger" onclick="eliminarUsuarioSeguridad('${u.id}')">Eliminar</button></div>
    </article>`).join("");
}
function mostrarFormUsuarioSeguridad(item = null) {
  usuarioSeguridadEdicionId = item?.id || null;
  $("formUsuarioSeguridad")?.classList.remove("hidden");
  $("segUsuarioNombre").value = item?.nombre || "";
  $("segUsuarioEmail").value = item?.email || "";
  $("segUsuarioRol").value = item?.rol || "atencion";
  $("segUsuarioActivo").checked = item?.activo !== false;
  const permisos = item?.permisos || segPermisosPorRol($("segUsuarioRol").value);
  document.querySelectorAll("[data-seg-permiso]").forEach(c => c.checked = permisos.includes(c.dataset.segPermiso));
}
function ocultarFormUsuarioSeguridad() {
  usuarioSeguridadEdicionId = null;
  $("formUsuarioSeguridad")?.classList.add("hidden");
}
async function guardarUsuarioSeguridad() {
  const email = String($("segUsuarioEmail")?.value || "").trim().toLowerCase();
  const nombre = String($("segUsuarioNombre")?.value || "").trim();
  if (!email || !email.includes("@")) return alert("Ingresá un correo válido.");
  const permisos = [...document.querySelectorAll("[data-seg-permiso]:checked")].map(c => c.dataset.segPermiso);
  const item = {
    id: usuarioSeguridadEdicionId || segId("user"), nombre, email,
    rol: $("segUsuarioRol").value, activo: $("segUsuarioActivo").checked,
    permisos, actualizadoEn: segAhora()
  };
  const idx = seguridadFratello.usuarios.findIndex(u => u.id === item.id);
  if (idx >= 0) seguridadFratello.usuarios[idx] = item; else seguridadFratello.usuarios.unshift(item);
  await segGuardarRemoto();
  await segAuditar("usuario", idx >= 0 ? "Usuario actualizado" : "Usuario agregado", `${email} · ${item.rol}`);
  ocultarFormUsuarioSeguridad();
  renderUsuariosSeguridad();
}
window.editarUsuarioSeguridad = id => mostrarFormUsuarioSeguridad(seguridadFratello.usuarios.find(u => u.id === id));
window.alternarUsuarioSeguridad = async id => {
  const u = seguridadFratello.usuarios.find(x => x.id === id); if (!u) return;
  u.activo = u.activo === false; await segGuardarRemoto(); await segAuditar("usuario", u.activo ? "Usuario activado" : "Usuario bloqueado", u.email); renderUsuariosSeguridad();
};
window.eliminarUsuarioSeguridad = async id => {
  const u = seguridadFratello.usuarios.find(x => x.id === id); if (!u || !confirm(`¿Eliminar a ${u.email}?`)) return;
  seguridadFratello.usuarios = seguridadFratello.usuarios.filter(x => x.id !== id); await segGuardarRemoto(); await segAuditar("usuario","Usuario eliminado",u.email); renderUsuariosSeguridad();
};
function renderDispositivosSeguridad() {
  const actual = dispositivoFratelloActual || segObtenerDispositivoActual();
  if ($("segDispositivoActualNombre")) $("segDispositivoActualNombre").textContent = actual.nombre;
  const estadoActual = seguridadFratello.dispositivos.find(d => d.id === actual.id)?.estado || "pendiente";
  const badge = $("segDispositivoActualEstado");
  if (badge) { badge.textContent = estadoActual; badge.className = `securityStatus ${estadoActual === "autorizado" ? "authorized" : estadoActual === "bloqueado" ? "blocked" : "pending"}`; }
  const cont = $("listaDispositivosSeguridad");
  if (!cont) return;
  const lista = seguridadFratello.dispositivos.filter(d => !usuarioAdministradorActual?.uid || d.uid === usuarioAdministradorActual.uid);
  cont.innerHTML = lista.length ? lista.map(d => `
    <article class="securityRow">
      <div class="securityAvatar">${/Celular|Android|iPhone/i.test(d.nombre) ? "📱" : "💻"}</div>
      <div class="securityRowMain"><strong>${segEscapar(d.nombre)}</strong><small>${segEscapar(d.email || "")}<br>Última actividad: ${new Date(d.ultimaActividad || d.creadoEn).toLocaleString("es-AR")}${d.id === actual.id ? " · Este dispositivo" : ""}</small></div>
      <span class="securityStatus ${d.estado === "autorizado" ? "authorized" : d.estado === "bloqueado" ? "blocked" : "pending"}">${segEscapar(d.estado)}</span>
      <div class="securityRowActions">${d.estado !== "autorizado" ? `<button onclick="autorizarDispositivoSeguridad('${d.id}')">Autorizar</button>` : ""}<button onclick="bloquearDispositivoSeguridad('${d.id}')">${d.estado === "bloqueado" ? "Desbloquear" : "Bloquear"}</button><button class="danger" onclick="eliminarDispositivoSeguridad('${d.id}')">Eliminar</button></div>
    </article>`).join("") : '<div class="securityEmpty">No hay dispositivos registrados.</div>';
}
window.autorizarDispositivoSeguridad = async id => { const d=seguridadFratello.dispositivos.find(x=>x.id===id); if(!d)return; d.estado="autorizado"; await segGuardarRemoto(); await segAuditar("dispositivo","Dispositivo autorizado",d.nombre); renderDispositivosSeguridad(); };
window.bloquearDispositivoSeguridad = async id => { const d=seguridadFratello.dispositivos.find(x=>x.id===id); if(!d)return; d.estado=d.estado==="bloqueado"?"autorizado":"bloqueado"; await segGuardarRemoto(); await segAuditar("dispositivo",d.estado==="bloqueado"?"Dispositivo bloqueado":"Dispositivo desbloqueado",d.nombre); renderDispositivosSeguridad(); if(d.id===dispositivoFratelloActual?.id && d.estado==="bloqueado") authFratello?.signOut(); };
window.eliminarDispositivoSeguridad = async id => { const d=seguridadFratello.dispositivos.find(x=>x.id===id); if(!d||!confirm("¿Eliminar este dispositivo?"))return; seguridadFratello.dispositivos=seguridadFratello.dispositivos.filter(x=>x.id!==id); await segGuardarRemoto(); await segAuditar("dispositivo","Dispositivo eliminado",d.nombre); renderDispositivosSeguridad(); };
function renderAuditoriaSeguridad() {
  const cont = $("listaAuditoriaSeguridad"); if (!cont) return;
  const filtro = $("filtroAuditoriaSeguridad")?.value || "";
  const lista = seguridadFratello.auditoria.filter(a => !filtro || a.tipo === filtro);
  cont.innerHTML = lista.length ? lista.map(a => `<article class="auditRow"><div class="auditDot"></div><div><strong>${segEscapar(a.accion)}</strong><small>${new Date(a.fecha).toLocaleString("es-AR")} · ${segEscapar(a.usuario)} · ${segEscapar(a.dispositivo)}</small>${a.detalle ? `<p>${segEscapar(a.detalle)}</p>` : ""}</div><span>${segEscapar(a.tipo)}</span></article>`).join("") : '<div class="securityEmpty">Todavía no hay movimientos para mostrar.</div>';
}
function segDatosBackup() {
  const claves = Object.keys(localStorage).filter(k => k.startsWith("fratello"));
  const local = {}; claves.forEach(k => local[k] = localStorage.getItem(k));
  return { formato:"FratelloBackup", version:"4.0", creadoEn:segAhora(), usuario:usuarioAdministradorActual?.email || "", localStorage:local };
}
function segDescargar(nombre, contenido, tipo="application/json") {
  const blob = new Blob([contenido], {type:tipo}); const url=URL.createObjectURL(blob); const a=document.createElement("a"); a.href=url; a.download=nombre; a.click(); setTimeout(()=>URL.revokeObjectURL(url),1000);
}
async function descargarBackupCompleto() {
  const datos=segDatosBackup(); const fecha=adminFinHoy(); segDescargar(`fratello_backup_${fecha}.json`,JSON.stringify(datos,null,2));
  seguridadFratello.backups.unshift({id:segId("backup"),fecha:segAhora(),tipo:"Descarga completa",usuario:usuarioAdministradorActual?.email||""});
  seguridadFratello.backups=seguridadFratello.backups.slice(0,50); await segGuardarRemoto(); await segAuditar("backup","Copia completa descargada",fecha); renderBackupsSeguridad();
}
async function restaurarBackupCompleto() {
  const archivo=$("archivoRestaurarBackup")?.files?.[0]; if(!archivo)return alert("Seleccioná un archivo de copia.");
  if(!confirm("La restauración reemplazará datos locales de Fratello. ¿Continuar?"))return;
  try { const datos=JSON.parse(await archivo.text()); if(datos.formato!=="FratelloBackup"||!datos.localStorage)throw new Error("Formato inválido");
    Object.entries(datos.localStorage).forEach(([k,v])=>localStorage.setItem(k,v)); await segAuditar("backup","Copia restaurada",archivo.name); alert("Copia restaurada. La aplicación se recargará."); location.reload();
  } catch(e){ alert("No se pudo restaurar: "+e.message); }
}
function exportarAdministracionCSV() {
  const filas=[["Tipo","Fecha","Concepto","Categoría/Cliente","Medio","Monto","Estado"]];
  (administracionFinanciera.ingresosExternos||[]).forEach(x=>filas.push(["Ingreso",x.fecha,x.descripcion||"",x.cliente||"",x.medio||"",x.monto||0,x.cobrado===false?"Pendiente":"Cobrado"]));
  (administracionFinanciera.gastosManuales||[]).forEach(x=>filas.push(["Gasto",x.fecha,x.motivo||"",x.categoria||"",x.medio||"",x.monto||0,x.pagado===false?"Pendiente":"Pagado"]));
  (administracionFinanciera.presupuestos||[]).forEach(x=>filas.push(["Presupuesto",x.mes||"",x.concepto||"",x.categoria||"","",x.monto||0,""]));
  const csv="\ufeff"+filas.map(f=>f.map(v=>`"${String(v??"").replace(/"/g,'""')}"`).join(";")).join("\n");
  segDescargar(`fratello_administracion_${adminFinHoy()}.csv`,csv,"text/csv;charset=utf-8"); segAuditar("backup","Administración exportada a CSV","");
}
function imprimirInformeAdministracion() {
  renderAdministracionFinanciera(); segAuditar("backup","Informe enviado a impresión/PDF",""); window.print();
}
function renderBackupsSeguridad() {
  const cont=$("listaBackupsSeguridad"); if(!cont)return;
  cont.innerHTML=seguridadFratello.backups.length?seguridadFratello.backups.map(b=>`<article class="securityRow"><div class="securityAvatar">💾</div><div class="securityRowMain"><strong>${segEscapar(b.tipo)}</strong><small>${new Date(b.fecha).toLocaleString("es-AR")} · ${segEscapar(b.usuario)}</small></div></article>`).join(""):'<div class="securityEmpty">Todavía no hay copias registradas.</div>';
}
async function registrarBackupManual() {
  seguridadFratello.backups.unshift({id:segId("backup"),fecha:segAhora(),tipo:"Registro manual",usuario:usuarioAdministradorActual?.email||""});
  seguridadFratello.backups=seguridadFratello.backups.slice(0,50); await segGuardarRemoto(); await segAuditar("backup","Copia registrada manualmente",""); renderBackupsSeguridad();
}
function renderSeguridadCompleta() { renderUsuariosSeguridad(); renderDispositivosSeguridad(); renderAuditoriaSeguridad(); renderBackupsSeguridad(); segAplicarPermisosUI(); }
function iniciarSeguridadFratello() {
  if (window.__FRATELLO_SEGURIDAD_V400__) return; window.__FRATELLO_SEGURIDAD_V400__=true;
  segCargarLocal(); dispositivoFratelloActual=segObtenerDispositivoActual();
  $("btnNuevoUsuarioSeguridad")?.addEventListener("click",()=>mostrarFormUsuarioSeguridad());
  $("btnCancelarUsuarioSeguridad")?.addEventListener("click",ocultarFormUsuarioSeguridad);
  $("btnGuardarUsuarioSeguridad")?.addEventListener("click",guardarUsuarioSeguridad);
  $("segUsuarioRol")?.addEventListener("change",()=>{const p=segPermisosPorRol($("segUsuarioRol").value);document.querySelectorAll("[data-seg-permiso]").forEach(c=>c.checked=p.includes(c.dataset.segPermiso));});
  $("btnActualizarDispositivos")?.addEventListener("click",async()=>{await segCargarRemoto();renderDispositivosSeguridad();});
  $("btnActualizarAuditoria")?.addEventListener("click",async()=>{await segCargarRemoto();renderAuditoriaSeguridad();});
  $("filtroAuditoriaSeguridad")?.addEventListener("change",renderAuditoriaSeguridad);
  $("btnDescargarBackupCompleto")?.addEventListener("click",descargarBackupCompleto);
  $("btnRestaurarBackup")?.addEventListener("click",restaurarBackupCompleto);
  $("btnExportarAdministracionCSV")?.addEventListener("click",exportarAdministracionCSV);
  $("btnImprimirInformeAdministracion")?.addEventListener("click",imprimirInformeAdministracion);
  $("btnCrearRegistroBackup")?.addEventListener("click",registrarBackupManual);
  renderSeguridadCompleta();
}


function nombreDiaProduccion(valor) {
  const nombres = {
    lunes_jueves: "Lunes a jueves",
    viernes: "Viernes",
    sabado: "Sábado",
    domingo: "Domingo"
  };
  return nombres[valor] || "Sin seleccionar";
}

function actualizarTarjetaDiaPedidos() {
  const selectorProduccion = $("diaProduccion");
  const selectorPedidos = $("diaProduccionPedidos");
  const selectorInicio = $("diaProduccionInicio");

  const checkProduccion = $("checkProduccionCompleta");
  const checkPedidos = $("checkDiaPedidos");
  const checkInicio = $("checkDiaInicio");

  const estadoPedidos = $("estadoDiaPedidos");
  const estadoInicio = $("estadoDiaInicio");

  const tarjetaPedidos = $("tarjetaDiaPedidos");
  const tarjetaInicio = $("tarjetaDiaInicio");

  if (!selectorProduccion || !checkProduccion) return;

  if (selectorPedidos) selectorPedidos.value = selectorProduccion.value;
  if (selectorInicio) selectorInicio.value = selectorProduccion.value;

  if (checkPedidos) checkPedidos.checked = checkProduccion.checked;
  if (checkInicio) checkInicio.checked = checkProduccion.checked;

  const textoEstado = checkProduccion.checked
    ? "Producción confirmada"
    : "Producción seleccionada";

  if (estadoPedidos) estadoPedidos.textContent = textoEstado;
  if (estadoInicio) estadoInicio.textContent = textoEstado;

  [tarjetaPedidos, tarjetaInicio].forEach(tarjeta => {
    if (!tarjeta) return;
    tarjeta.classList.toggle("confirmada", checkProduccion.checked);
    tarjeta.classList.toggle("pendiente", !checkProduccion.checked);
  });
}

function fechaProximaParaGrupoProduccion(grupo) {
  const hoy = new Date();
  hoy.setHours(12, 0, 0, 0);

  const objetivos = {
    lunes_jueves: [1, 2, 3, 4],
    viernes: [5],
    sabado: [6],
    domingo: [0]
  }[grupo] || [];

  if (!objetivos.length) return $("fechaPedido")?.value || fechaISOManana();

  for (let avance = 0; avance <= 7; avance++) {
    const candidata = new Date(hoy);
    candidata.setDate(hoy.getDate() + avance);
    if (objetivos.includes(candidata.getDay())) {
      return candidata.toISOString().slice(0, 10);
    }
  }

  return fechaISOManana();
}

function grupoProduccionDesdeFecha(fecha) {
  if (!fecha) return "";
  const dia = new Date(fecha + "T12:00:00").getDay();
  if ([1, 2, 3, 4].includes(dia)) return "lunes_jueves";
  if (dia === 5) return "viernes";
  if (dia === 6) return "sabado";
  if (dia === 0) return "domingo";
  return "";
}

function sincronizarFechaConProduccion() {
  const grupo = $("diaProduccion")?.value || "";
  if (!grupo) return;

  const fecha = fechaProximaParaGrupoProduccion(grupo);
  if ($("fechaPedido")) $("fechaPedido").value = fecha;
  if ($("fechaCargarPedidosFijos")) $("fechaCargarPedidosFijos").value = fecha;

  asegurarPedidosFijosParaFecha(fecha, false);
  renderPedidosCargados();
  calcularDiferencias();
}

function sincronizarProduccionConFechaPedido() {
  const fecha = $("fechaPedido")?.value;
  const grupo = grupoProduccionDesdeFecha(fecha);
  if (!grupo) return;

  if ($("diaProduccion")) $("diaProduccion").value = grupo;
  if ($("diaProduccionPedidos")) $("diaProduccionPedidos").value = grupo;
  if ($("diaProduccionInicio")) $("diaProduccionInicio").value = grupo;
  if ($("fechaCargarPedidosFijos")) $("fechaCargarPedidosFijos").value = fecha;

  asegurarPedidosFijosParaFecha(fecha, false);
  renderProduccion();
  renderPedidosCargados();
  calcularDiferencias();
  actualizarTarjetaDiaPedidos();
}

function sincronizarDiaDesdeProduccion() {
  const selectorProduccion = $("diaProduccion");
  const selectorPedidos = $("diaProduccionPedidos");
  const checkProduccion = $("checkProduccionCompleta");
  const checkPedidos = $("checkDiaPedidos");

  if (!selectorProduccion || !selectorPedidos) return;

  selectorPedidos.value = selectorProduccion.value;

  // Si cambia el día, se destilda la confirmación para obligar a revisar.
  if (checkProduccion) checkProduccion.checked = false;
  if (checkPedidos) checkPedidos.checked = false;

  actualizarTarjetaDiaPedidos();
}

function sincronizarDiaDesdePedidos() {
  const selectorProduccion = $("diaProduccion");
  const selectorPedidos = $("diaProduccionPedidos");
  const checkProduccion = $("checkProduccionCompleta");
  const checkPedidos = $("checkDiaPedidos");

  if (!selectorProduccion || !selectorPedidos) return;

  selectorProduccion.value = selectorPedidos.value;

  // Dispara la lógica existente del cuadro 1: recarga producción y diferencias.
  selectorProduccion.dispatchEvent(new Event("change", { bubbles: true }));

  if (checkProduccion) checkProduccion.checked = false;
  if (checkPedidos) checkPedidos.checked = false;

  actualizarTarjetaDiaPedidos();
}

function iniciarSincronizacionDia() {
  const selectorProduccion = $("diaProduccion");
  const selectorPedidos = $("diaProduccionPedidos");
  const selectorInicio = $("diaProduccionInicio");

  const checkProduccion = $("checkProduccionCompleta");
  const checkPedidos = $("checkDiaPedidos");
  const checkInicio = $("checkDiaInicio");

  function cambiarDiaDesde(valor) {
    if (!selectorProduccion) return;

    selectorProduccion.value = valor;
    if (selectorPedidos) selectorPedidos.value = valor;
    if (selectorInicio) selectorInicio.value = valor;

    if (checkProduccion) checkProduccion.checked = false;
    if (checkPedidos) checkPedidos.checked = false;
    if (checkInicio) checkInicio.checked = false;

    selectorProduccion.dispatchEvent(new Event("change", { bubbles: true }));
    actualizarTarjetaDiaPedidos();
  }

  if (selectorProduccion) {
    selectorProduccion.addEventListener("change", () => {
      if (selectorPedidos) selectorPedidos.value = selectorProduccion.value;
      if (selectorInicio) selectorInicio.value = selectorProduccion.value;

      if (checkProduccion) checkProduccion.checked = false;
      if (checkPedidos) checkPedidos.checked = false;
      if (checkInicio) checkInicio.checked = false;

      actualizarTarjetaDiaPedidos();
      sincronizarFechaConProduccion();
    });
  }

  if (selectorPedidos) {
    selectorPedidos.addEventListener("change", () => cambiarDiaDesde(selectorPedidos.value));
  }

  if (selectorInicio) {
    selectorInicio.addEventListener("change", () => cambiarDiaDesde(selectorInicio.value));
  }

  function sincronizarChecks(origen) {
    const valor = origen?.checked || false;
    if (checkProduccion) checkProduccion.checked = valor;
    if (checkPedidos) checkPedidos.checked = valor;
    if (checkInicio) checkInicio.checked = valor;
    actualizarTarjetaDiaPedidos();
  }

  if (checkProduccion) checkProduccion.addEventListener("change", () => sincronizarChecks(checkProduccion));
  if (checkPedidos) checkPedidos.addEventListener("change", () => sincronizarChecks(checkPedidos));
  if (checkInicio) checkInicio.addEventListener("change", () => sincronizarChecks(checkInicio));

  actualizarTarjetaDiaPedidos();
}


function clientesConRecordatorioActivo() {
  return clientes.filter(nombre => {
    const datos = datosClientesCompletos[nombre];
    return datos && datos.enviarRecordatorio;
  });
}

function clientesQueYaPidieron() {
  return new Set(
    pedidos
      .filter(p => p && p.cliente)
      .map(p => normalizar(p.cliente))
  );
}

function obtenerClientesPendientes() {
  const enviados = clientesQueYaPidieron();

  return clientesConRecordatorioActivo().filter(nombre => {
    return !enviados.has(normalizar(nombre));
  });
}

function renderClientesPendientes() {
  const cont = $("listaClientesPendientes");
  const contador = $("contadorClientesPendientes");
  if (!cont || !contador) return;

  const pendientes = obtenerClientesPendientes();
  contador.textContent = `${pendientes.length} pendiente${pendientes.length === 1 ? "" : "s"}`;

  if (!pendientes.length) {
    cont.innerHTML = '<p class="pendingOk">✅ Todos los clientes con recordatorio ya enviaron pedido.</p>';
    actualizarEstadoColaRecordatorios();
    return;
  }

  cont.innerHTML = pendientes.map(nombre => {
    const datos = datosClientesCompletos[nombre] || {};
    const telefono = datos.telefono || "Sin teléfono";
    const seguro = nombre.replace(/'/g, "\\'");

    return `<div class="pendingClientRow">
      <label class="pendingClientSelect">
        <input type="checkbox" class="checkRecordatorioPendiente" value="${nombre}" checked>
        <span>
          <strong>${nombre}</strong>
          <small>📞 ${telefono}</small>
        </span>
      </label>
      <button type="button" onclick="recordarClientePendiente('${seguro}')">Recordar</button>
    </div>`;
  }).join("");

  actualizarEstadoColaRecordatorios();
}

function linkFormularioPedido() {
  const base = window.location.origin + window.location.pathname.replace("index.html", "");
  return base + "pedido.html";
}

function telefonoWhatsAppCliente(nombre) {
  const datos = datosClientesCompletos[nombre] || {};
  const telefono = normalizarTelefonoCliente(datos.telefono || "");

  if (!telefono) return "";
  if (telefono.startsWith("549")) return telefono;
  if (telefono.startsWith("54")) return "549" + telefono.slice(2);
  return "549" + telefono;
}

function mensajeRecordatorioCliente(nombre) {
  return `Hola ${nombre}! Te recordamos cargar tu pedido para la próxima entrega:

${linkFormularioPedido()}

Gracias, Fratello.`;
}

function recordarClientePendiente(nombre) {
  const telefono = telefonoWhatsAppCliente(nombre);

  if (!telefono) {
    alert(`El cliente ${nombre} no tiene teléfono cargado.`);
    return;
  }

  abrirWhatsApp(telefono, mensajeRecordatorioCliente(nombre));
}

function leerColaRecordatorios() {
  try {
    return JSON.parse(localStorage.getItem("fratello_cola_recordatorios") || "[]");
  } catch {
    return [];
  }
}

function guardarColaRecordatorios(cola) {
  localStorage.setItem("fratello_cola_recordatorios", JSON.stringify(cola || []));
  actualizarEstadoColaRecordatorios();
}

function actualizarEstadoColaRecordatorios() {
  const estado = $("estadoColaRecordatorios");
  const boton = $("btnRecordarPendientes");
  if (!estado || !boton) return;

  const cola = leerColaRecordatorios();

  if (!cola.length) {
    estado.classList.add("hidden");
    estado.textContent = "";
    boton.textContent = "📲 Enviar recordatorios seleccionados";
    return;
  }

  estado.classList.remove("hidden");
  estado.textContent = `Quedan ${cola.length} cliente${cola.length === 1 ? "" : "s"} por contactar.`;
  boton.textContent = `📲 Enviar siguiente (${cola.length})`;
}

function enviarSiguienteRecordatorioPendiente() {
  const cola = leerColaRecordatorios();

  if (!cola.length) {
    alert("No quedan recordatorios pendientes en la cola.");
    actualizarEstadoColaRecordatorios();
    return;
  }

  const siguiente = cola.shift();
  guardarColaRecordatorios(cola);

  abrirWhatsApp(
    siguiente.telefono,
    mensajeRecordatorioCliente(siguiente.nombre)
  );
}

function recordarTodosLosPendientes() {
  const colaExistente = leerColaRecordatorios();

  if (colaExistente.length) {
    enviarSiguienteRecordatorioPendiente();
    return;
  }

  const seleccionados = Array.from(
    document.querySelectorAll(".checkRecordatorioPendiente:checked")
  ).map(check => check.value);

  const nombres = seleccionados.length
    ? seleccionados
    : obtenerClientesPendientes();

  if (!nombres.length) {
    alert("No hay clientes pendientes seleccionados.");
    return;
  }

  const sinTelefono = [];
  const cola = [];

  nombres.forEach(nombre => {
    const telefono = telefonoWhatsAppCliente(nombre);
    if (!telefono) {
      sinTelefono.push(nombre);
      return;
    }
    cola.push({ nombre, telefono });
  });

  if (sinTelefono.length) {
    alert(
      "Estos clientes no tienen teléfono cargado y no se incluirán:\n\n" +
      sinTelefono.join("\n")
    );
  }

  if (!cola.length) return;

  guardarColaRecordatorios(cola);
  enviarSiguienteRecordatorioPendiente();
}




function guardarPedidosHoy() {
  localStorage.setItem("fratello_pedidos_hoy", JSON.stringify(pedidosHoy));
}

function depurarPedidosHoyPorJornada() {
  // Desde v3.8.1 no se borran los pedidos de jornadas anteriores.
  // Se conservan para la memoria semanal de tickets y la pestaña Pendientes.
  return pedidosHoy;
}

function limpiarFormularioPedidoHoy() {
  pedidoHoyEditandoId = null;
  if ($("clientePedidoHoy")) $("clientePedidoHoy").value = "";
  if ($("textoPedidoHoy")) $("textoPedidoHoy").value = "";
  if ($("horaEntregaPedidoHoy")) $("horaEntregaPedidoHoy").value = "";
  if ($("btnGuardarPedidoHoy")) $("btnGuardarPedidoHoy").textContent = "Guardar pedido para hoy";
}

function guardarPedidoHoyDesdeFormulario() {
  const cliente = $("clientePedidoHoy")?.value.trim() || "";
  const texto = $("textoPedidoHoy")?.value.trim() || "";
  const horaEntrega = $("horaEntregaPedidoHoy")?.value || "";

  if (!cliente) {
    alert("Ingresá el nombre del cliente.");
    $("clientePedidoHoy")?.focus();
    return;
  }

  if (!texto) {
    alert("Ingresá el pedido.");
    $("textoPedidoHoy")?.focus();
    return;
  }

  if (!/^\d{2}:\d{2}$/.test(horaEntrega)) {
    alert("Elegí la hora de entrega.");
    $("horaEntregaPedidoHoy")?.focus();
    return;
  }

  if (pedidoHoyEditandoId !== null) {
    const existente = pedidosHoy.find(p => Number(p.id) === Number(pedidoHoyEditandoId));
    if (existente) {
      existente.cliente = cliente;
      existente.texto = texto;
      existente.textoOriginal = texto;
      existente.horaEntrega = horaEntrega;
      existente.items = procesarTextoPedido(texto, cliente, existente.jornada || fechaOperativaActual());
      existente.actualizado = new Date().toISOString();
    }
  } else {
    const idPedidoHoy = Date.now();
    const jornada = fechaOperativaActual();
    const itemsProcesados = procesarTextoPedido(texto, cliente, jornada);

    pedidosHoy.push({
      id: idPedidoHoy,
      jornada,
      fecha: jornada,
      fechaEntrega: jornada,
      cliente,
      texto,
      textoOriginal: texto,
      horaEntrega,
      origen: "manual_hoy",
      confirmado: true,
      entregado: false,
      items: itemsProcesados,
      creado: new Date().toISOString()
    });
  }

  guardarPedidosHoy();
  sincronizarMemoriaTickets();
  limpiarFormularioPedidoHoy();
  renderPedidosHoy();
  renderTicketsPorDia();
}

function editarPedidoHoy(id) {
  const pedido = pedidosHoy.find(p => Number(p.id) === Number(id));
  if (!pedido) return;

  pedidoHoyEditandoId = pedido.id;
  if ($("clientePedidoHoy")) $("clientePedidoHoy").value = pedido.cliente || "";
  if ($("textoPedidoHoy")) $("textoPedidoHoy").value = pedido.texto || "";
  if ($("horaEntregaPedidoHoy")) $("horaEntregaPedidoHoy").value = pedido.horaEntrega || "";
  if ($("btnGuardarPedidoHoy")) $("btnGuardarPedidoHoy").textContent = "Guardar cambios";

  abrirSeccionFratello("seccionPedidosHoy");
  setTimeout(() => $("clientePedidoHoy")?.focus(), 80);
}

function eliminarPedidoHoy(id) {
  if (!confirm("¿Seguro que querés eliminar este pedido para hoy?")) return;

  pedidosHoy = pedidosHoy.filter(p => Number(p.id) !== Number(id));

  if (Number(pedidoHoyEditandoId) === Number(id)) {
    limpiarFormularioPedidoHoy();
  }

  guardarPedidosHoy();
  sincronizarMemoriaTickets();
  renderPedidosHoy();
  renderTicketsPorDia();
}

function alternarEntregadoPedidoHoy(id, entregado) {
  const pedido = pedidosHoy.find(p => Number(p.id) === Number(id));
  if (!pedido) return;

  pedido.entregado = Boolean(entregado);
  pedido.actualizado = new Date().toISOString();
  guardarPedidosHoy();
  sincronizarMemoriaTickets();
  guardarEnNube();
  renderPedidosHoy();
  renderTicketsPorDia();
}

function renderPedidosHoy() {
  const lista = $("listaPedidosHoy");
  const contador = $("contadorPedidosHoy");
  if (!lista) return;

  depurarPedidosHoyPorJornada();

  const jornadaActual = fechaOperativaActual();
  const pedidosJornada = pedidosHoy.filter(
    pedido => (pedido.jornada || pedido.fechaEntrega || pedido.fecha) === jornadaActual
  );

  const ordenados = [...pedidosJornada].sort((a, b) => {
    if (Boolean(a.entregado) !== Boolean(b.entregado)) {
      return Number(a.entregado) - Number(b.entregado);
    }
    return String(a.horaEntrega || "").localeCompare(String(b.horaEntrega || ""));
  });

  const pendientes = ordenados.filter(pedido => !pedido.entregado).length;
  if (contador) contador.textContent = String(pendientes);

  const badgeMenu = $("badgePedidosHoyPendientes");
  if (badgeMenu) {
    badgeMenu.textContent = String(pendientes);
    badgeMenu.classList.toggle("isZero", pendientes === 0);
    badgeMenu.setAttribute(
      "aria-label",
      `${pendientes} pedido${pendientes === 1 ? "" : "s"} pendiente${pendientes === 1 ? "" : "s"} de entregar`
    );
  }

  if (!ordenados.length) {
    lista.innerHTML = '<p class="todayOrdersEmpty">No hay pedidos cargados para esta jornada.</p>';
    return;
  }

  lista.innerHTML = ordenados.map(pedido => `
    <article class="todayOrderCard ${pedido.entregado ? "isDelivered" : ""}">
      <div class="todayOrderHead">
        <div>
          <strong>${escaparHtmlCatalogo(pedido.cliente || "Cliente")}</strong>
          <span>Entrega ${escaparHtmlCatalogo(pedido.horaEntrega || "")}</span>
        </div>

        <div class="todayOrderDeliveryState ${pedido.entregado ? "isDelivered" : ""}">
          ${pedido.entregado ? "✅ ENTREGADO" : "🕒 PENDIENTE"}
        </div>
      </div>

      <details class="todayOrderDetails">
        <summary>Ver pedido</summary>
        <div class="todayOrderText">${escaparHtmlCatalogo(pedido.texto || "").replace(/\n/g, "<br>")}</div>

        <div class="todayOrderActions">
          <button type="button" class="todayDeliveryButton ${pedido.entregado ? "undoDelivery" : ""}"
            onclick="alternarEntregadoPedidoHoy(${pedido.id}, ${pedido.entregado ? "false" : "true"})">
            ${pedido.entregado ? "↩️ Volver a pendiente" : "✅ Marcar como entregado"}
          </button>
          <button type="button" class="primary" onclick="verTicketPedidoHoy(${pedido.id})">👁 Ver ticket</button>
          <button type="button" onclick="editarPedidoHoy(${pedido.id})">✏️ Editar</button>
          <button type="button" onclick="descargarPdfPedidoHoy(${pedido.id})">📄 Ticket PDF</button>
          <button type="button" onclick="guardarJpgPedidoHoy(${pedido.id})">🖼 Ticket JPG</button>
          <button type="button" class="dangerBtn" onclick="eliminarPedidoHoy(${pedido.id})">🗑 Eliminar</button>
        </div>
      </details>
    </article>
  `).join("");
}


function origenPedidoNormalizado(pedido) {
  const origen = String(pedido?.origen || "").toLowerCase().trim();

  if (origen === "manual") return "manual";
  if (["externo", "formulario", "web", "cliente"].includes(origen)) return "externo";
  if (["fijo", "pedido_fijo", "automatico", "automático"].includes(origen)) return "fijo";

  if (pedido?.esFijo === true || pedido?.pedidoFijoId || pedido?.origenFijo === true) {
    return "fijo";
  }

  return origen || "desconocido";
}

function debeNotificarPedido(pedido) {
  const origen = origenPedidoNormalizado(pedido);
  return origen === "manual" || origen === "externo";
}

function emitirNotificacionPedidoSiCorresponde(pedido, opciones = {}) {
  if (!pedido || !debeNotificarPedido(pedido) || !notificacionesPermitidasParaPedido(pedido)) return false;

  const titulo = opciones.titulo || "Nuevo pedido";
  const cliente = pedido.cliente || "Cliente";
  const cuerpo = opciones.cuerpo || `Nuevo pedido de ${cliente}`;
  const fecha = fechaEntregaPedido(pedido) || fechaOperativaActual();

  try {
    if (typeof mostrarNotificacion === "function") {
      mostrarNotificacion(titulo, {
        body: cuerpo,
        tag: `pedido-${pedido.id || Date.now()}`,
        data: {
          url: `${location.origin}${location.pathname}?abrir=pedidos&fecha=${encodeURIComponent(fecha)}&pedido=${encodeURIComponent(pedido.id || "")}`,
          seccion: "seccionPedidos",
          fecha,
          pedidoId: pedido.id || null
        }
      });
      return true;
    }
  } catch (error) {
    console.error("No se pudo mostrar la notificación:", error);
  }

  return false;
}

function fechaOperativaActual() {
  const ahora = new Date();
  const fecha = new Date(ahora);
  if (ahora.getHours() < 6) fecha.setDate(fecha.getDate() - 1);
  return [
    fecha.getFullYear(),
    String(fecha.getMonth() + 1).padStart(2, "0"),
    String(fecha.getDate()).padStart(2, "0")
  ].join("-");
}

function fechasDesdeHoyHastaDomingo() {
  // v5.1.4: mostrar siempre siete días corridos desde la fecha operativa.
  // Evita que el domingo quede un solo día y que el lunes siguiente no aparezca
  // hasta actualizar o reiniciar la aplicación.
  const inicio = new Date(fechaOperativaActual() + "T12:00:00");
  const fechas = [];

  for (let i = 0; i < 7; i += 1) {
    const fecha = new Date(inicio);
    fecha.setDate(inicio.getDate() + i);
    fechas.push([
      fecha.getFullYear(),
      String(fecha.getMonth() + 1).padStart(2, "0"),
      String(fecha.getDate()).padStart(2, "0")
    ].join("-"));
  }
  return fechas;
}

function nombreDiaPedidos(fechaISO, esPrimero = false) {
  const fecha = new Date(fechaISO + "T12:00:00");
  const nombre = fecha.toLocaleDateString("es-AR", {
    weekday: "long",
    day: "2-digit",
    month: "2-digit"
  });
  return `${esPrimero ? "Hoy · " : ""}${nombre.charAt(0).toUpperCase()}${nombre.slice(1)}`;
}

function esPedidoFijoRobusto(pedido) {
  return pedido?.origen === "pedido_fijo" ||
    Boolean(pedido?.programacionId) ||
    Boolean(pedido?.programacionNombre) ||
    pedido?.esPedidoFijo === true;
}

function categoriaPedidoSemana(pedido) {
  if (esPedidoFijoRobusto(pedido)) return "fijos";
  if (pedido?.origen === "formulario_cliente") return "enlace";
  return "dia";
}

function etiquetaOrigenPedido(pedido) {
  if (esPedidoFijoRobusto(pedido)) return "🔁 Fijo";
  if (pedido?.origen === "formulario_cliente") return "📲 Enlace";
  return "✍️ Manual";
}

function htmlPedidoCompacto(pedido) {
  const itemsValidos = (pedido.items || []).filter(item => item.estado !== "NO PEDIDO");
  const confirmado = pedidoEstaConfirmado(pedido);
  const pendientesRevision = itemsValidos.filter(item =>
    item.productoAmbiguo ||
    item.unidadAmbigua ||
    String(item.estado || "").startsWith("REVISAR")
  ).length;

  let detalle = "";
  if (!itemsValidos.length) {
    detalle = '<p class="compactOrderEmpty">No se detectaron productos con cantidad.</p>';
  } else {
    detalle = `<div class="compactOrderItems">${itemsValidos.map(item => `
      <div class="compactOrderItem ${item.productoAmbiguo || item.unidadAmbigua || String(item.estado || "").startsWith("REVISAR") ? "needsReview" : ""}">
        <div class="compactOrderItemMain">
          <span>${escaparHtmlCatalogo(item.producto || "Producto")}</span>
          <strong>${fmt(item.cantidad)} ${escaparHtmlCatalogo(item.unidad || "")}</strong>
        </div>
        ${botonesResolverProducto(pedido.id, item)}
        ${botonesResolverUnidad(pedido.id, item)}
      </div>`).join("")}</div>`;
  }

  return `<article class="compactOrderCard ${confirmado ? "isConfirmed" : ""}" data-pedido-card-id="${pedido.id}">
    <div class="compactOrderTop">
      <div class="compactOrderName">
        <strong>${escaparHtmlCatalogo(pedido.cliente || "Cliente")}</strong>
        <span>${etiquetaOrigenPedido(pedido)} · ${itemsValidos.length} producto(s)</span>
      </div>
      <label class="compactConfirm ${confirmado ? "confirmed" : ""}">
        <input type="checkbox"
          ${confirmado ? "checked" : ""}
          onchange="alternarConfirmacionPedido(${pedido.id}, this.checked)">
        <span>${confirmado ? "Confirmado" : "Confirmar"}</span>
      </label>
    </div>

    <details class="compactOrderDetails" data-pedido-detalle="${pedido.id}">
      <summary>Ver pedido${pendientesRevision ? ` · ⚠️ ${pendientesRevision} por revisar` : ""}</summary>
      ${pendientesRevision ? '<div class="compactReviewAlert">Revisá y elegí la opción correcta antes de confirmar.</div>' : ""}
      ${detalle}
      <div class="compactOrderActions">
        <button type="button" onclick="editarPedidoCargado(${pedido.id})">✏️ Editar</button>
        <button type="button" onclick="descargarPdfPedidoIndividual(${pedido.id})">📄 PDF</button>
        <button type="button" class="btnEliminarPedido" onclick="borrarPedido(${pedido.id})">Eliminar</button>
      </div>
    </details>
  </article>`;
}

function htmlGrupoPedidosSemana(titulo, pedidosGrupo, tipo, abierto = false) {
  const cantidad = pedidosGrupo.length;
  return `<details class="weeklyOrderGroup ${tipo}" data-grupo="${tipo}" ${abierto ? "open" : ""}>
    <summary>
      <span>${titulo}</span>
      <span class="weeklyCount">${cantidad}</span>
    </summary>
    <div class="weeklyOrderGroupBody">
      ${tipo === "enlace" ? '<p class="weeklyGroupHint">Pedidos enviados por los clientes desde su enlace.</p>' : ""}
      ${cantidad
        ? pedidosGrupo.map(htmlPedidoCompacto).join("")
        : '<p class="weeklyEmpty">No hay pedidos en esta sección.</p>'}
    </div>
  </details>`;
}

function capturarEstadoPanelPedidosSemana(panel) {
  if (!panel) return null;

  return {
    dias: Array.from(panel.querySelectorAll(".weeklyDay[open]"))
      .map(el => el.dataset.fecha)
      .filter(Boolean),
    grupos: Array.from(panel.querySelectorAll(".weeklyDay")).flatMap(dia =>
      Array.from(dia.querySelectorAll(".weeklyOrderGroup[open]")).map(grupo => ({
        fecha: dia.dataset.fecha,
        tipo: grupo.dataset.grupo
      }))
    ),
    pedidos: Array.from(panel.querySelectorAll(".compactOrderDetails[open]"))
      .map(el => el.dataset.pedidoDetalle)
      .filter(Boolean),
    scrollY: window.scrollY
  };
}

function restaurarEstadoPanelPedidosSemana(panel, estado) {
  if (!panel || !estado) return;

  if (estado.dias.length) {
    panel.querySelectorAll(".weeklyDay").forEach(dia => {
      dia.open = estado.dias.includes(dia.dataset.fecha);
    });
  }

  estado.grupos.forEach(item => {
    const dia = panel.querySelector(`.weeklyDay[data-fecha="${item.fecha}"]`);
    const grupo = dia?.querySelector(`.weeklyOrderGroup[data-grupo="${item.tipo}"]`);
    if (grupo) grupo.open = true;
  });

  estado.pedidos.forEach(id => {
    const detalle = panel.querySelector(`.compactOrderDetails[data-pedido-detalle="${id}"]`);
    if (detalle) detalle.open = true;
  });

  requestAnimationFrame(() => {
    window.scrollTo({ top: estado.scrollY || 0, behavior: "auto" });
  });
}

function renderPanelPedidosSemana() {
  const panel = $("panelPedidosSemana");
  if (!panel) return;

  // Limpieza defensiva: ninguna copia eliminada puede volver a mostrarse.
  pedidos = pedidos.filter(pedido => !pedidoEstaEliminadoSync(pedido));

  const estadoAnterior = capturarEstadoPanelPedidosSemana(panel);
  const fechas = fechasDesdeHoyHastaDomingo();
  const fechaOperativa = fechaOperativaActual();

  fechas.forEach(fecha => {
    const tienePedidoNuevo = pedidos.some(pedido =>
      fechaEntregaPedido(pedido) === fecha &&
      !esPedidoFijoRobusto(pedido)
    );

    if (tienePedidoNuevo) {
      reabrirJornadaParaNuevoPedido(fecha);
    }

    asegurarPedidosFijosParaFecha(fecha, false);
  });

  panel.innerHTML = fechas.map((fecha, indice) => {
    const pedidosFecha = pedidos
      .filter(pedido => fechaEntregaPedido(pedido) === fecha)
      .sort((a, b) => String(a.cliente || "").localeCompare(String(b.cliente || ""), "es"));

    const enlace = pedidosFecha.filter(pedido => categoriaPedidoSemana(pedido) === "enlace");
    const dia = pedidosFecha.filter(pedido => categoriaPedidoSemana(pedido) === "dia");
    const fijos = pedidosFecha.filter(pedido => categoriaPedidoSemana(pedido) === "fijos");

    return `<details class="weeklyDay" data-fecha="${fecha}">
      <summary>
        <span>${nombreDiaPedidos(fecha, fecha === fechaOperativa)}</span>
        <span class="weeklyDayTotal">${pedidosFecha.length}</span>
      </summary>
      <div class="weeklyDayBody">
        ${htmlGrupoPedidosSemana("Pedidos recibidos desde enlace", enlace, "enlace", false)}
        ${htmlGrupoPedidosSemana("Pedidos del día", dia, "dia", false)}
        ${htmlGrupoPedidosSemana("Pedidos fijos", fijos, "fijos", false)}
      </div>
    </details>`;
  }).join("");

  // Mantener un solo día abierto a la vez para reducir el scroll.
  panel.querySelectorAll(".weeklyDay").forEach(detalle => {
    detalle.addEventListener("toggle", () => {
      if (!detalle.open) return;

      panel.querySelectorAll(".weeklyDay").forEach(otro => {
        if (otro !== detalle) otro.open = false;
      });

      const fechaAbierta = detalle.dataset.fecha || "";
      if (fechaAbierta && $("fechaPedido")) {
        $("fechaPedido").value = fechaAbierta;
      }

      sincronizarConfirmacionDiaDesdePedidos();
    });
  });

  restaurarEstadoPanelPedidosSemana(panel, estadoAnterior);
}

function volverArribaCuadro2() {
  abrirSeccionFratello("seccionPedidos");
  setTimeout(() => {
    $("inicioCuadro2")?.scrollIntoView({ behavior: "smooth", block: "start" });
    $("diaProduccionPedidos")?.focus();
  }, 80);
}

function fechaPanelSemanalAbierto() {
  const panelAbierto = document.querySelector("#panelPedidosSemana .weeklyDay[open]");
  return panelAbierto?.dataset?.fecha || "";
}

function estadoConfirmacionFechaSeleccionada() {
  // La fecha válida es la del día semanal que el usuario tiene abierto.
  // Ejemplo: el martes se confirman pedidos para el miércoles.
  const fechaPanel = fechaPanelSemanalAbierto();
  const fecha = fechaPanel || $("fechaPedido")?.value || fechaJornadaActual();

  const pedidosFecha = pedidos.filter(pedido =>
    fechaEntregaPedido(pedido) === fecha
  );
  const confirmados = pedidosFecha.filter(pedido =>
    pedidoEstaConfirmado(pedido)
  );

  return {
    fecha,
    pedidosFecha,
    confirmados,
    todosConfirmados:
      pedidosFecha.length > 0 &&
      confirmados.length === pedidosFecha.length
  };
}

function sincronizarConfirmacionDiaDesdePedidos() {
  const estado = estadoConfirmacionFechaSeleccionada();
  const checkDiaPedidos = $("checkDiaPedidos");

  if (checkDiaPedidos && estado.todosConfirmados) {
    checkDiaPedidos.checked = true;
  }

  return estado;
}

function continuarAlResumenSiEstaConfirmado() {
  const diaProduccion = $("diaProduccion")?.value || "";
  const diaPedidos = $("diaProduccionPedidos")?.value || diaProduccion;
  const checkProduccion = $("checkProduccionCompleta");
  const estado = sincronizarConfirmacionDiaDesdePedidos();

  if (!estado.pedidosFecha.length) {
    alert("No hay pedidos cargados para el día seleccionado.");
    return;
  }

  if (!estado.todosConfirmados) {
    const faltan = estado.pedidosFecha.length - estado.confirmados.length;
    alert(`Falta confirmar ${faltan} pedido(s) del día seleccionado.`);
    return;
  }

  if (!diaProduccion || !checkProduccion?.checked) {
    alert("Falta confirmar la producción del día seleccionado.");
    volverArribaCuadro2();
    return;
  }

  if (diaPedidos && diaProduccion !== diaPedidos) {
    alert("El día de Pedidos no coincide con el día confirmado en Producción.");
    volverArribaCuadro2();
    return;
  }

  abrirSeccionFratello("seccionResumen");
}


function normalizarTelefonoCliente(telefono) {
  return String(telefono || "").replace(/\D/g, "");
}

function limpiarFormularioClienteCompleto() {
  const nombre = $("nuevoClienteNombre");
  const telefono = $("nuevoClienteTelefono");
  const direccion = $("nuevoClienteDireccion");
  const barrio = $("nuevoClienteBarrio");
  const listaPrecio = $("nuevoClienteListaPrecio");
  const recordatorio = $("nuevoClienteRecordatorio");
  const notificaciones = $("nuevoClienteNotificaciones");
  const boton = $("btnGuardarClienteCompleto");

  if (nombre) {
    nombre.value = "";
    delete nombre.dataset.editando;
  }
  if (telefono) telefono.value = "";
  if (direccion) direccion.value = "";
  if (barrio) barrio.value = "";
  if (listaPrecio) renderSelectorListasCliente("auto");
  if (recordatorio) recordatorio.checked = false;
  if (notificaciones) notificaciones.checked = true;
  if (boton) boton.textContent = "➕ Agregar cliente";
}

function mostrarMensajeClienteCompleto(texto, error = false) {
  const el = $("mensajeClienteCompleto");
  if (!el) return;

  el.textContent = texto;
  el.style.display = "block";
  el.style.background = error ? "#ffe1de" : "#eaf7eb";
  el.style.color = error ? "#9b1c1c" : "#1f7a35";
}

function guardarClienteCompleto() {
  try {
    const nombreInput = $("nuevoClienteNombre");
    const telefonoInput = $("nuevoClienteTelefono");
    const direccionInput = $("nuevoClienteDireccion");
    const barrioInput = $("nuevoClienteBarrio");
    const listaPrecioInput = $("nuevoClienteListaPrecio");
    const recordatorioInput = $("nuevoClienteRecordatorio");
    const notificacionesInput = $("nuevoClienteNotificaciones");

    if (!nombreInput) {
      alert("No se encontró el formulario de clientes.");
      return;
    }

    const nombre = nombreInput.value.trim();
    const telefono = normalizarTelefonoCliente(telefonoInput?.value || "");
    const direccion = direccionInput?.value.trim() || "";
    const barrio = barrioInput?.value.trim() || "";
    const listaPrecio = listaPrecioInput?.value || "auto";
    const enviarRecordatorio = Boolean(recordatorioInput?.checked);
    const recibirNotificaciones = notificacionesInput ? Boolean(notificacionesInput.checked) : true;
    const nombreAnterior = nombreInput.dataset.editando || "";

    if (!nombre) {
      mostrarMensajeClienteCompleto("Escribí el nombre del cliente.", true);
      return;
    }

    if (!Array.isArray(clientes)) clientes = [];
    if (!datosClientesCompletos || typeof datosClientesCompletos !== "object") {
      datosClientesCompletos = {};
    }

    const duplicado = clientes.find(c =>
      normalizar(c) === normalizar(nombre) &&
      normalizar(c) !== normalizar(nombreAnterior)
    );

    if (duplicado) {
      mostrarMensajeClienteCompleto("Ya existe un cliente con ese nombre.", true);
      return;
    }

    if (nombreAnterior && nombreAnterior !== nombre) {
      clientes = clientes.map(c => c === nombreAnterior ? nombre : c);
      delete datosClientesCompletos[nombreAnterior];

      pedidos.forEach(p => {
        if (p.cliente === nombreAnterior) p.cliente = nombre;
        if (Array.isArray(p.items)) {
          p.items.forEach(i => {
            if (i.cliente === nombreAnterior) i.cliente = nombre;
          });
        }
      });
    } else if (!clientes.some(c => normalizar(c) === normalizar(nombre))) {
      clientes.push(nombre);
    }

    datosClientesCompletos[nombre] = {
      nombre, telefono, direccion, barrio, listaPrecio, enviarRecordatorio, recibirNotificaciones,
      actualizado: new Date().toISOString()
    };

    guardarTodo();
    renderClientes(nombre);
    renderListaClientesCompleta();

    limpiarFormularioClienteCompleto();
    mostrarMensajeClienteCompleto("Cliente guardado correctamente.");
  } catch (error) {
    console.error("Error al guardar cliente:", error);
    alert("No se pudo guardar el cliente.");
  }
}

function editarClienteCompleto(nombre) {
  const datos = datosClientesCompletos[nombre] || {
    nombre,
    telefono: "",
    direccion: "",
    barrio: "",
    listaPrecio: "auto",
    enviarRecordatorio: false,
    recibirNotificaciones: true
  };

  const nombreInput = $("nuevoClienteNombre");
  if (nombreInput) {
    nombreInput.value = datos.nombre || nombre;
    nombreInput.dataset.editando = nombre;
  }

  if ($("nuevoClienteTelefono")) $("nuevoClienteTelefono").value = datos.telefono || "";
  if ($("nuevoClienteDireccion")) $("nuevoClienteDireccion").value = datos.direccion || "";
  if ($("nuevoClienteBarrio")) $("nuevoClienteBarrio").value = datos.barrio || "";
  renderSelectorListasCliente(datos.listaPrecio || "auto");
  if ($("nuevoClienteRecordatorio")) $("nuevoClienteRecordatorio").checked = Boolean(datos.enviarRecordatorio);
  if ($("nuevoClienteNotificaciones")) $("nuevoClienteNotificaciones").checked = datos.recibirNotificaciones !== false;
  if ($("btnGuardarClienteCompleto")) $("btnGuardarClienteCompleto").textContent = "💾 Guardar cambios";

  abrirSeccionFratello("seccionClientes");
}

function eliminarClienteCompleto(nombre) {
  if (!confirm(`¿Seguro que querés eliminar a ${nombre}?`)) return;

  clientes = clientes.filter(c => c !== nombre);
  delete datosClientesCompletos[nombre];

  guardarTodo();
  renderClientes();
  actualizarPanelMemoriaEnvio();
  renderListaClientesCompleta();
  abrirSeccionFratello("seccionClientes");
}

function renderListaClientesCompleta() {
  const cont = $("listaClientesCompleta");
  if (!cont) return;

  if (!clientes.length) {
    cont.innerHTML = "<p>No hay clientes cargados.</p>";
    return;
  }

  cont.innerHTML = clientes.map(nombre => {
    const datos = datosClientesCompletos[nombre] || {};
    const tel = datos.telefono || "Sin teléfono";
    const dir = datos.direccion || "Sin dirección";
    const rec = datos.enviarRecordatorio ? "🔔 Recordatorio activado" : "🔕 Sin recordatorio";
    const recibirNotificaciones = datos.recibirNotificaciones !== false;
    const seguro = nombre.replace(/'/g, "\\'");

    return `<div class="clienteCompletoCard">
      <div>
        <strong>${nombre}</strong>
        <span>📞 ${tel}</span>
        <span>📍 ${dir}</span>
        <small>${rec}</small>
        <label class="clienteNotificationToggle">
          <input type="checkbox"
            ${recibirNotificaciones ? "checked" : ""}
            onchange="alternarNotificacionesCliente('${seguro}', this.checked)">
          <span>${recibirNotificaciones ? "🔔 Notificar pedidos" : "🔕 Pedidos silenciados"}</span>
        </label>
      </div>
      <div class="clienteCompletoActions">
        <button type="button" onclick="editarClienteCompleto('${seguro}')">✏️ Editar</button>
        <button type="button" onclick="configurarPedidoFijoCliente('${seguro}')">🔁 Pedido fijo</button>
        <button type="button" class="dangerBtn" onclick="eliminarClienteCompleto('${seguro}')">🗑️ Eliminar</button>
      </div>
    </div>`;
  }).join("");
}


function configurarPedidoFijoCliente(nombre) {
  abrirSeccionFratello("seccionClientes");
  renderSelectorClientesPedidoFijo();
  const selector = $("pedidoFijoCliente");
  if (selector) selector.value = nombre;
  const bloque = $("pedidosFijosClientes");
  if (bloque) {
    bloque.open = true;
    setTimeout(() => bloque.scrollIntoView({ behavior: "smooth", block: "start" }), 80);
  }
  if ($("pedidoFijoTexto")) $("pedidoFijoTexto").focus();
}

function mostrarInicioFratello(limpiarPila = true) {
  const inicio = document.getElementById("panelInicio");
  const contenido = document.getElementById("contenidoApp");

  document.querySelectorAll(".appSection").forEach(seccion => {
    seccion.classList.remove("seccionActiva");
  });

  if (inicio) inicio.classList.remove("hidden");
  if (contenido) contenido.classList.remove("contenidoVisible");

  seccionActualFratello = "inicio";
  if (limpiarPila) pilaNavegacionFratello = [];

  window.scrollTo({ top: 0, behavior: "smooth" });
}



const CLAVE_CONFIG_NOTIFICACIONES = "fratello_config_notificaciones";
let configuracionNotificaciones = {
  activas: true,
  sonido: true,
  vibracion: true,
  banners: true,
  agrupar: true,
  ...leerJsonLocalSeguro(CLAVE_CONFIG_NOTIFICACIONES, {})
};

let colaNotificacionesPedidos = [];
let temporizadorGrupoNotificaciones = null;

function guardarConfiguracionNotificaciones() {
  localStorage.setItem(
    CLAVE_CONFIG_NOTIFICACIONES,
    JSON.stringify(configuracionNotificaciones)
  );
  enviarPreferenciasNotificacionesAlServiceWorker();
  renderConfiguracionNotificaciones();
}

function clienteAceptaNotificaciones(nombreCliente) {
  const nombre = String(nombreCliente || "").trim();
  if (!nombre) return true;

  const clave = Object.keys(datosClientesCompletos || {}).find(
    item => normalizar(item) === normalizar(nombre)
  );
  const datos = clave ? datosClientesCompletos[clave] : null;

  // Compatibilidad: clientes existentes siguen notificando hasta que el usuario los desactive.
  return datos?.recibirNotificaciones !== false;
}

function notificacionesPermitidasParaPedido(pedido) {
  if (!configuracionNotificaciones.activas) return false;
  if (!configuracionNotificaciones.banners) return false;
  return clienteAceptaNotificaciones(pedido?.cliente);
}

async function enviarPreferenciasNotificacionesAlServiceWorker() {
  if (!("serviceWorker" in navigator)) return;

  const clientesSilenciados = Object.entries(datosClientesCompletos || {})
    .filter(([, datos]) => datos?.recibirNotificaciones === false)
    .map(([nombre]) => normalizar(nombre));

  const mensaje = {
    type: "ACTUALIZAR_PREFERENCIAS_NOTIFICACIONES",
    configuracion: configuracionNotificaciones,
    clientesSilenciados
  };

  try {
    const registro = await navigator.serviceWorker.ready;
    registro.active?.postMessage(mensaje);
    navigator.serviceWorker.controller?.postMessage(mensaje);
  } catch (error) {
    console.error("No se pudieron enviar preferencias al Service Worker:", error);
  }
}

function renderConfiguracionNotificaciones() {
  const ids = {
    chkNotificacionesActivas: "activas",
    chkNotificacionesSonido: "sonido",
    chkNotificacionesVibracion: "vibracion",
    chkNotificacionesBanners: "banners",
    chkNotificacionesAgrupar: "agrupar"
  };

  Object.entries(ids).forEach(([id, clave]) => {
    const input = $(id);
    if (input) input.checked = Boolean(configuracionNotificaciones[clave]);
  });

  const estado = $("estadoConfiguracionNotificaciones");
  if (estado) {
    estado.textContent = configuracionNotificaciones.activas
      ? "✅ Avisos generales activados"
      : "🔕 Todos los avisos están pausados";
  }
}

function cambiarConfiguracionNotificacionesDesdePantalla() {
  configuracionNotificaciones = {
    activas: Boolean($("chkNotificacionesActivas")?.checked),
    sonido: Boolean($("chkNotificacionesSonido")?.checked),
    vibracion: Boolean($("chkNotificacionesVibracion")?.checked),
    banners: Boolean($("chkNotificacionesBanners")?.checked),
    agrupar: Boolean($("chkNotificacionesAgrupar")?.checked)
  };
  guardarConfiguracionNotificaciones();
}

function alternarNotificacionesCliente(nombre, activo) {
  if (!datosClientesCompletos[nombre]) {
    datosClientesCompletos[nombre] = {
      nombre,
      telefono: "",
      direccion: "",
      barrio: "",
      listaPrecio: "auto",
      enviarRecordatorio: false
    };
  }

  datosClientesCompletos[nombre].recibirNotificaciones = Boolean(activo);
  datosClientesCompletos[nombre].actualizado = new Date().toISOString();

  guardarTodo();
  renderListaClientesCompleta();
  enviarPreferenciasNotificacionesAlServiceWorker();
}

function marcarNotificacionesVistasAlAbrirApp() {
  ultimaNotificacionVista = new Date().toISOString();
  localStorage.setItem(
    "fratello_ultima_notificacion_vista",
    ultimaNotificacionVista
  );
  actualizarCampanaNotificaciones();
}

let notificacionesHistorial = [];
let unsubscribeHistorialNotificaciones = null;
let ultimaNotificacionVista =
  localStorage.getItem("fratello_ultima_notificacion_vista") || "";

function fechaNotificacionISO(notificacion) {
  const valor = notificacion?.fechaISO || notificacion?.creadoEn || "";
  if (valor && typeof valor.toDate === "function") {
    return valor.toDate().toISOString();
  }

  const fecha = new Date(valor);
  return Number.isNaN(fecha.getTime()) ? "" : fecha.toISOString();
}

function mostrarFechaNotificacion(notificacion) {
  const iso = fechaNotificacionISO(notificacion);
  if (!iso) return "";

  return new Date(iso).toLocaleString("es-AR", {
    day: "2-digit",
    month: "2-digit",
    hour: "2-digit",
    minute: "2-digit"
  });
}

function cantidadNotificacionesNoLeidas() {
  return notificacionesHistorial.filter(notificacion => {
    const fecha = fechaNotificacionISO(notificacion);
    return fecha && (!ultimaNotificacionVista || fecha > ultimaNotificacionVista);
  }).length;
}

function actualizarCampanaNotificaciones() {
  const badge = $("badgeNotificaciones");
  const resumen = $("resumenNotificacionesInicio");
  const cantidad = cantidadNotificacionesNoLeidas();

  if (badge) {
    badge.textContent = String(cantidad);
    badge.classList.toggle("hidden", cantidad === 0);
  }

  if (resumen) {
    if (cantidad > 0) {
      resumen.textContent =
        `${cantidad} aviso${cantidad === 1 ? "" : "s"} sin leer`;
    } else if (notificacionesHistorial.length > 0) {
      resumen.textContent = "No hay avisos nuevos";
    } else {
      resumen.textContent = "Todavía no hay notificaciones";
    }
  }
}

function renderHistorialNotificaciones() {
  const lista = $("listaNotificaciones");
  const estado = $("estadoListaNotificaciones");
  if (!lista || !estado) return;

  if (!notificacionesHistorial.length) {
    estado.textContent = "Todavía no hay notificaciones guardadas.";
    lista.innerHTML = "";
    actualizarCampanaNotificaciones();
    return;
  }

  estado.textContent =
    `${notificacionesHistorial.length} notificación${
      notificacionesHistorial.length === 1 ? "" : "es"
    }`;

  lista.innerHTML = notificacionesHistorial.map(notificacion => {
    const titulo = notificacion.titulo || "Notificación de Fratello";
    const mensaje = notificacion.mensaje || notificacion.cuerpo || "";
    const cliente = notificacion.cliente || "";
    const fecha = mostrarFechaNotificacion(notificacion);

    return `<article class="notificationHistoryCard">
      <div class="notificationHistoryIcon">📦</div>
      <div class="notificationHistoryContent">
        <div class="notificationHistoryHeader">
          <strong>${titulo}</strong>
          <time>${fecha}</time>
        </div>
        ${cliente ? `<span class="notificationClient">${cliente}</span>` : ""}
        <p>${mensaje}</p>
      </div>
    </article>`;
  }).join("");

  actualizarCampanaNotificaciones();
}


async function borrarTodasLasNotificaciones() {
  if (!db) {
    alert("Firebase no está conectado.");
    return;
  }

  if (!confirm("¿Seguro que querés borrar todo el historial de notificaciones?")) {
    return;
  }

  const boton = $("btnBorrarNotificaciones");
  if (boton) {
    boton.disabled = true;
    boton.textContent = "Borrando...";
  }

  try {
    const snapshot = await db
      .collection("fratello_historial_notificaciones")
      .limit(200)
      .get();

    if (snapshot.empty) {
      alert("No hay notificaciones para borrar.");
      return;
    }

    const batch = db.batch();
    snapshot.docs.forEach(doc => batch.delete(doc.ref));
    await batch.commit();

    notificacionesHistorial = [];
    ultimaNotificacionVista = new Date().toISOString();
    localStorage.setItem(
      "fratello_ultima_notificacion_vista",
      ultimaNotificacionVista
    );

    renderHistorialNotificaciones();
    actualizarCampanaNotificaciones();
    alert("Notificaciones borradas correctamente.");
  } catch (error) {
    console.error("Error borrando notificaciones:", error);
    alert("No se pudieron borrar las notificaciones.");
  } finally {
    if (boton) {
      boton.disabled = false;
      boton.textContent = "🗑 Borrar notificaciones";
    }
  }
}

async function cargarHistorialNotificaciones() {
  const estado = $("estadoListaNotificaciones");

  if (!db) {
    if (estado) estado.textContent = "Firebase no está conectado.";
    return;
  }

  if (estado) estado.textContent = "Actualizando notificaciones...";

  try {
    const snapshot = await db
      .collection("fratello_historial_notificaciones")
      .orderBy("fechaISO", "desc")
      .limit(50)
      .get();

    notificacionesHistorial = snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    }));

    renderHistorialNotificaciones();
  } catch (error) {
    console.error("Error cargando historial:", error);
    if (estado) {
      estado.textContent = "No se pudieron cargar las notificaciones.";
    }
  }
}

let idsNotificacionesConocidas = new Set();

async function mostrarNotificacionHistorialEnDispositivo(notificacion) {
  if (!notificacion || !("Notification" in window) || Notification.permission !== "granted") return;

  try {
    const registro = await navigator.serviceWorker.ready;
    await registro.showNotification(
      notificacion.titulo || "Nueva notificación de Fratello",
      {
        body: notificacion.mensaje || notificacion.cuerpo || "Tenés un nuevo aviso.",
        icon: "./icon-192.png",
        badge: "./icon-192.png",
        tag: `historial-${notificacion.id}`,
        data: { url: "./index.html#seccionNotificaciones" }
      }
    );
  } catch (error) {
    console.error("No se pudo mostrar la notificación del historial:", error);
  }
}

function escucharHistorialNotificaciones() {
  if (!db || unsubscribeHistorialNotificaciones) return;

  unsubscribeHistorialNotificaciones = db
    .collection("fratello_historial_notificaciones")
    .orderBy("fechaISO", "desc")
    .limit(50)
    .onSnapshot(snapshot => {
      const nuevas = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));

      nuevas.forEach(notificacion => {
        idsNotificacionesConocidas.add(notificacion.id);
      });

      // El historial solamente actualiza la campana y la lista interna.
      // Nunca genera avisos del sistema, para evitar notificar pedidos fijos
      // al recargar, borrar memoria o comenzar una jornada.
      notificacionesHistorial = nuevas;
      renderHistorialNotificaciones();
    }, error => {
      console.error("Error escuchando historial:", error);
    });
}

function marcarNotificacionesComoVistas() {
  ultimaNotificacionVista = new Date().toISOString();
  localStorage.setItem(
    "fratello_ultima_notificacion_vista",
    ultimaNotificacionVista
  );
  actualizarCampanaNotificaciones();
}

let pilaNavegacionFratello = [];
let seccionActualFratello = "inicio";

function mostrarSeccionFratelloSinApilar(idSeccion) {
  const inicio = document.getElementById("panelInicio");
  const contenido = document.getElementById("contenidoApp");
  const destino = document.getElementById(idSeccion);

  if (!destino) return;

  if (inicio) inicio.classList.add("hidden");
  if (contenido) contenido.classList.add("contenidoVisible");

  document.querySelectorAll(".appSection").forEach(seccion => {
    seccion.classList.toggle("seccionActiva", seccion.id === idSeccion);
  });

  seccionActualFratello = idSeccion;

  if (idSeccion === "seccionNotificaciones") {
    cargarHistorialNotificaciones();
    marcarNotificacionesComoVistas();
  }

  if (idSeccion === "seccionTickets") {
    renderTicketsPorDia();
  }

  if (idSeccion === "seccionAdministracion" && tieneRolAdministrador()) {
    const yaEstabaEnAdministracion = seccionActualFratello === "seccionAdministracion";
    const teniaSubvistaAbierta = $("panelAdministracionPrivado")?.classList.contains("adminSubvistaActiva");
    administracionPrivadaActiva = true;
    $("panelAdministracionLogin")?.classList.add("hidden");
    $("panelAdministracionPrivado")?.classList.remove("hidden");
    // v5.1.1: una resincronización nunca cambia la pantalla elegida por el usuario.
    if (vistaAdministracionActual) {
      restaurarVistaAdministracionActual();
    } else if (!yaEstabaEnAdministracion && !teniaSubvistaAbierta) {
      mostrarMenuAdministracion();
    }
    renderAdministracionFinanciera();
    renderSeguridadCompleta();
    registrarActividadAdministracion();
  }

  if (idSeccion === "seccionPedidos") {
    const fecha = $("fechaPedido")?.value || fechaISOManana();
    if ($("fechaPedido") && !$("fechaPedido").value) $("fechaPedido").value = fecha;
    asegurarPedidosFijosParaFecha(fecha, false);
    renderPedidosCargados();
    calcularDiferencias();
  }

  window.scrollTo({ top: 0, behavior: "smooth" });
}

function abrirSeccionFratello(idSeccion) {
  if (!idSeccion) return;

  if (seccionActualFratello !== idSeccion) {
    pilaNavegacionFratello.push(seccionActualFratello || "inicio");
  }

  mostrarSeccionFratelloSinApilar(idSeccion);
}

function volverAtrasFratello() {
  const anterior = pilaNavegacionFratello.pop();

  if (!anterior || anterior === "inicio") {
    mostrarInicioFratello(false);
    return;
  }

  mostrarSeccionFratelloSinApilar(anterior);
}

window.abrirSeccionFratello = abrirSeccionFratello;
window.volverAtrasFratello = volverAtrasFratello;
window.mostrarInicioFratello = mostrarInicioFratello;


function abrirDesdeNotificacion(datos = {}) {
  const fecha = datos.fecha || new URL(location.href).searchParams.get("fecha");
  const pedidoId = datos.pedidoId || new URL(location.href).searchParams.get("pedido");

  if (fecha && $("fechaPedido")) {
    $("fechaPedido").value = fecha;
  }

  abrirSeccionFratello("seccionPedidos");

  // Crear una entrada real en el historial para que el botón Atrás vuelva al inicio.
  if (!history.state || history.state.fratelloNotificacion !== true) {
    history.replaceState({ fratelloInicio: true }, "", `${location.pathname}${location.hash || ""}`);
    history.pushState(
      { fratelloNotificacion: true, seccion: "seccionPedidos", fecha, pedidoId },
      "",
      `${location.pathname}?abrir=pedidos${fecha ? `&fecha=${encodeURIComponent(fecha)}` : ""}${pedidoId ? `&pedido=${encodeURIComponent(pedidoId)}` : ""}`
    );
  }

  setTimeout(() => {
    renderPedidosCargados();
    if (pedidoId) {
      const tarjeta = document.querySelector(`[data-pedido-card-id="${pedidoId}"]`);
      tarjeta?.scrollIntoView({ behavior: "smooth", block: "center" });
      const detalle = tarjeta?.querySelector("details");
      if (detalle) detalle.open = true;
    }
  }, 120);
}

function procesarEntradaDesdeNotificacion() {
  const params = new URL(location.href).searchParams;
  if (params.get("abrir") !== "pedidos") return;

  abrirDesdeNotificacion({
    fecha: params.get("fecha"),
    pedidoId: params.get("pedido")
  });
}

window.addEventListener("message", event => {
  if (event.data?.type === "ABRIR_DESDE_NOTIFICACION") {
    abrirDesdeNotificacion(event.data);
  }
});

window.addEventListener("popstate", event => {
  if (event.state?.fratelloInicio || !event.state) {
    abrirSeccionFratello("seccionInicio");
    return;
  }

  if (event.state?.fratelloNotificacion) {
    abrirSeccionFratello(event.state.seccion || "seccionPedidos");
  }
});

function iniciarNavegacionFratello() {
  if ($("btnGuardarPedidoHoy")) {
    $("btnGuardarPedidoHoy").addEventListener("click", guardarPedidoHoyDesdeFormulario);
  }

  document.addEventListener("click", evento => {
    const botonSeccion = evento.target.closest("[data-seccion]");
    if (botonSeccion) {
      evento.preventDefault();
      const destino = botonSeccion.dataset.seccion;

      if (destino === "seccionAdministracion") {
        abrirAdministracionAutenticada();
        return;
      }

      abrirSeccionFratello(destino);
      return;
    }

    const botonVolver = evento.target.closest("[data-volver]");
    if (botonVolver) {
      evento.preventDefault();
      volverAtrasFratello();
    }
  });

  const btnInicio = document.getElementById("btnInicio");
  if (btnInicio) {
    btnInicio.addEventListener("click", evento => {
      evento.preventDefault();
      mostrarInicioFratello();
    });
  }

  const btnBorrarRapido = document.getElementById("btnBorrarRapido");
  if (btnBorrarRapido) {
    btnBorrarRapido.addEventListener("click", resetDatos);
  }

  mostrarInicioFratello();
}

let eventoInstalacion = null;
window.addEventListener("beforeinstallprompt", (evento) => {
  evento.preventDefault();
  eventoInstalacion = evento;
  const boton = document.getElementById("btnInstalarApp");
  if (boton) boton.classList.remove("hidden");
});
async function instalarFratello() {
  if (!eventoInstalacion) {
    alert("En iPhone usá Compartir y elegí Agregar a pantalla de inicio.");
    return;
  }
  eventoInstalacion.prompt();
  await eventoInstalacion.userChoice;
  eventoInstalacion = null;
  const boton = document.getElementById("btnInstalarApp");
  if (boton) boton.classList.add("hidden");
}

const productos = [
  {
    id: "CRIOLLOS",
    nombre: "Criollos",
    unidad: "unidad",
    formaVenta: "solo_unidad",
    sinonimos: ["criollo"],
    visible: true,
    activo: true,
    nuevo: false
  },
  { id: "CHIC", nombre: "Chicharrón", unidad: "unidad", visible: true, activo: true, nuevo: false },
  { id: "TREN", nombre: "Trenzas", unidad: "unidad", visible: true, activo: true, nuevo: false },
  { id: "RASP", nombre: "Raspaditas", unidad: "unidad", visible: true, activo: true, nuevo: false },
  { id: "CORD_S", nombre: "Corderos salados", unidad: "unidad", visible: true, activo: true, nuevo: false },
  { id: "CORD_D", nombre: "Corderos dulces", unidad: "unidad", visible: true, activo: true, nuevo: false },
  { id: "RASQ_G", nombre: "Rasquetas grasas", unidad: "unidad", visible: true, activo: true, nuevo: false },
  { id: "RASQ_M", nombre: "Rasquetas manteca", unidad: "unidad", visible: true, activo: true, nuevo: false },
  { id: "BIZ_H", nombre: "Bizcocho hojaldre", unidad: "kg", visible: true, activo: true, nuevo: false },
  { id: "LIB_MEM", nombre: "Librito membrillo", unidad: "kg", visible: true, activo: true, nuevo: false },
  { id: "BIZ_G", nombre: "Bizcochos de grasa", unidad: "kg", visible: true, activo: true, nuevo: false },
  { id: "FAC_SUR", nombre: "Facturas surtidas", unidad: "docena", visible: true, activo: true, nuevo: false },
  { id: "MED", nombre: "Medialunas", unidad: "docena", visible: true, activo: true, nuevo: false },
  { id: "PAN", nombre: "Pan", unidad: "kg", visible: true, activo: true, nuevo: false },
  { id: "CAS", nombre: "Caserito", unidad: "kg", visible: true, activo: true, nuevo: false },
  { id: "PAN_CAS", nombre: "Pan casero", unidad: "unidad", visible: true, activo: true, nuevo: false },
  { id: "PALM", nombre: "Palmeritas", unidad: "kg", visible: true, activo: true, nuevo: false },
  { id: "PAN_SAL", nombre: "Pan de salvado", unidad: "kg", visible: true, activo: true, nuevo: false },
  { id: "PREP", nombre: "Prepizzas", unidad: "unidad", visible: true, activo: true, nuevo: false },
  { id: "PAN_INT", nombre: "Pan integral", unidad: "unidad", visible: true, activo: true, nuevo: false },
  { id: "BUD", nombre: "Budín", unidad: "unidad", visible: true, activo: true, nuevo: false },
  { id: "TAP_MAI", nombre: "Tapitas maicena", unidad: "kg", visible: true, activo: true, nuevo: false },
  { id: "FROLA", nombre: "Frolas", unidad: "kg", visible: true, activo: true, nuevo: false },
  { id: "SCON", nombre: "Scon", unidad: "kg", visible: true, activo: true, nuevo: false },
  { id: "PEPAS", nombre: "Pepas", unidad: "kg", visible: true, activo: true, nuevo: false },
  { id: "CANON", nombre: "Cañoncitos", unidad: "kg", visible: true, activo: true, nuevo: false },
  { id: "PIZZ_KG", nombre: "Pizzetas x kg", unidad: "kg", visible: true, activo: true, nuevo: false },

  { id: "PAN_HAMB", nombre: "Pan hamburguesa", unidad: "unidad", visible: false, activo: true, nuevo: false },
  { id: "PAN_CHIPS", nombre: "Pan de chips", unidad: "unidad", visible: false, activo: true, nuevo: false },
  { id: "PAN_PANCHO", nombre: "Pan de pancho", unidad: "unidad", visible: false, activo: true, nuevo: false },
];

const dias = ["lunes_jueves", "viernes", "sabado", "domingo"];

const clientesIniciales = [
  "Fratello",
  "Pedernera y Colombia",
  "Giuliano",
  "Laura",
  "Cliente 4",
  "Cliente 5",
  "Cliente 6",
  "Cliente 7",
];

const diccionario = [
  ["rasquetas grasas", "RASQ_G"], ["rasqueta grasa", "RASQ_G"],
  ["rasquetas manteca", "RASQ_M"], ["rasqueta manteca", "RASQ_M"],
  ["bizcochos de grasa", "BIZ_G"], ["bizcocho de grasa", "BIZ_G"],
  ["bizcocho hojaldre", "BIZ_H"], ["librito membrillo", "LIB_MEM"],
  ["facturas surtidas", "FAC_SUR"], ["factura surtida", "FAC_SUR"],
  ["corderos salados", "CORD_S"], ["cordero salado", "CORD_S"],
  ["corderos dulces", "CORD_D"], ["cordero dulce", "CORD_D"],
  ["pan de salvado", "PAN_SAL"], ["pan integral", "PAN_INT"],
  ["pan casero", "PAN_CAS"], ["pan hamburguesa", "PAN_HAMB"],
  ["pan de hamburguesa", "PAN_HAMB"], ["pan de chips", "PAN_CHIPS"],
  ["pan chips", "PAN_CHIPS"], ["pan de pancho", "PAN_PANCHO"],
  ["pan pancho", "PAN_PANCHO"], ["criollos", "CRIOLLOS"], ["criollo", "CRIOLLOS"],
  ["chicharrón", "CHIC"], ["chicharron", "CHIC"],
  ["trenzas", "TREN"], ["raspaditas", "RASP"], ["medialunas", "MED"],
  ["caserito", "CAS"], ["palmeritas", "PALM"], ["prepizzas", "PREP"], ["prepizza", "PREP"],
  ["budín", "BUD"], ["budin", "BUD"], ["tapitas maicena", "TAP_MAI"],
  ["frolas", "FROLA"], ["scon", "SCON"], ["pepas", "PEPAS"], ["cañoncitos", "CANON"],
  ["canon", "CANON"], ["pizzetas", "PIZZ_KG"], ["pan", "PAN"],
].sort((a, b) => b[0].length - a[0].length);

function crearPredeterminadasIniciales() {
  const base = {};
  for (const d of dias) {
    base[d] = {};
    for (const p of productos) base[d][p.id] = 0;
  }
  return base;
}


// --- SINCRONIZACIÓN ONLINE FIREBASE ---
// Pegá acá el firebaseConfig de Firebase.

function leerJsonLocalSeguro(clave, valorPredeterminado = {}) {
  try {
    const valor = localStorage.getItem(clave);
    if (!valor) return valorPredeterminado;
    const resultado = JSON.parse(valor);
    return resultado ?? valorPredeterminado;
  } catch (error) {
    console.warn(`Dato local inválido en ${clave}. Se restaurará el valor predeterminado.`, error);
    try { localStorage.removeItem(clave); } catch (_) {}
    return valorPredeterminado;
  }
}

function registrarErrorFratello(tipo, error) {
  try {
    const clave = "fratello_registro_errores";
    const historial = leerJsonLocalSeguro(clave, []);
    const lista = Array.isArray(historial) ? historial : [];
    lista.push({
      tipo,
      mensaje: String(error?.message || error || "Error desconocido"),
      fecha: new Date().toISOString(),
      version: window.FRATELLO_VERSION || "desconocida"
    });
    localStorage.setItem(clave, JSON.stringify(lista.slice(-20)));
  } catch (_) {}
}

window.addEventListener("error", evento => {
  registrarErrorFratello("error", evento.error || evento.message);
});

window.addEventListener("unhandledrejection", evento => {
  registrarErrorFratello("promesa", evento.reason);
});

const firebaseConfig = {
  apiKey: "AIzaSyDPg7UWyqOKYxP5qEelgqjcfTjXD3BXYQY",
  authDomain: "fratello-c1765.firebaseapp.com",
  projectId: "fratello-c1765",
  storageBucket: "fratello-c1765.firebasestorage.app",
  messagingSenderId: "897400694131",
  appId: "1:897400694131:web:4262fca5934bcc56629106",
  measurementId: "G-DSFYHG7QFV"
};

const FIREBASE_ACTIVO = firebaseConfig.apiKey && !firebaseConfig.apiKey.includes("PEGAR");
let db = null;
let cargandoDesdeNube = false;

if (FIREBASE_ACTIVO && typeof firebase !== "undefined") {
  firebase.initializeApp(firebaseConfig);
  db = firebase.firestore();
}

let authFratello = null;
let usuarioAdministradorActual = null;
let rolUsuarioActual = null;

function obtenerRolUsuario(usuario) {
  if (!usuario) return null;
  // v3.9.5D.2: la cuenta autenticada recibe rol administrador.
  // Queda preparado para leer roles específicos desde Firestore en D.3.
  return "administrador";
}

function tieneRolAdministrador() {
  return Boolean(usuarioAdministradorActual && rolUsuarioActual === "administrador");
}

if (FIREBASE_ACTIVO && typeof firebase !== "undefined" && firebase.auth) {
  try {
    authFratello = firebase.auth();
    authFratello.setPersistence(firebase.auth.Auth.Persistence.LOCAL);
  } catch (error) {
    console.error("No se pudo iniciar Firebase Authentication:", error);
  }
}


const CLAVE_VAPID_NOTIFICACIONES = "BG6gYJciGDS2YKNz1pIUx_Y1qMauuao5J3PY5uinZ1zLLbG7rY5ZQyO_fXbJPoY4kaXECH7EunZPq4EeBmct2QU";
let messaging = null;
let tokenNotificaciones = localStorage.getItem("fratello_token_notificaciones") || "";

if (FIREBASE_ACTIVO && typeof firebase !== "undefined" && firebase.messaging) {
  try {
    messaging = firebase.messaging();
  } catch (error) {
    console.error("No se pudo iniciar Firebase Messaging:", error);
  }
}




function origenNotificacionPermitido(datos = {}) {
  const origen = String(
    datos.origen ||
    datos.tipoOrigen ||
    datos.tipo_pedido ||
    datos.tipoPedido ||
    ""
  ).toLowerCase().trim();

  return [
    "manual",
    "externo",
    "formulario_cliente",
    "pedido_manual",
    "pedido_externo"
  ].includes(origen);
}

if (messaging) {
  messaging.onMessage(async payload => {
    const datos = payload?.data || {};

    // Los push sin origen explícito se descartan.
    // Esto evita que pedidos fijos o avisos viejos reaparezcan al actualizar.
    if (!origenNotificacionPermitido(datos)) return;
    if (!configuracionNotificaciones.activas || !configuracionNotificaciones.banners) return;
    if (!clienteAceptaNotificaciones(datos.cliente || datos.nombreCliente || "")) return;

    const titulo = payload.notification?.title || "Fratello";
    const cuerpo = payload.notification?.body || "Tenés un nuevo pedido.";

    try {
      const registro = await obtenerRegistroServiceWorkerNotificaciones();
      await registro.showNotification(titulo, {
        body: cuerpo,
        icon: "./icon-192.png",
        badge: "./icon-192.png",
        tag: datos.tag || `fratello-pedido-${datos.pedidoId || Date.now()}`,
        renotify: false,
        silent: !configuracionNotificaciones.sonido,
        vibrate: configuracionNotificaciones.vibracion ? [180, 80, 180] : [],
        data: datos
      });
    } catch (error) {
      console.error("Error mostrando notificación recibida:", error);
    }
  });
}

function actualizarEstadoNotificaciones() {
  const estado = $("estadoNotificaciones");
  const btnActivar = $("btnActivarNotificaciones");
  const btnProbar = $("btnProbarNotificacion");

  if (!estado) return;

  if (!("Notification" in window)) {
    estado.textContent = "Este dispositivo no admite notificaciones web.";
    if (btnActivar) btnActivar.disabled = true;
    if (btnProbar) btnProbar.disabled = true;
    return;
  }

  if (Notification.permission === "denied") {
    estado.textContent = "Notificaciones bloqueadas. Habilitalas desde Ajustes del iPhone.";
    if (btnActivar) btnActivar.disabled = true;
    if (btnProbar) btnProbar.disabled = true;
    return;
  }

  if (Notification.permission === "granted" && tokenNotificaciones) {
    estado.textContent = "✅ Dispositivo registrado. Para recibir avisos con la app cerrada se necesita el envío push del servidor.";
    if (btnActivar) btnActivar.textContent = "Renovar registro";
    if (btnProbar) btnProbar.disabled = false;
    return;
  }

  if (Notification.permission === "granted") {
    estado.textContent = "Permiso concedido. Falta registrar el dispositivo.";
    if (btnProbar) btnProbar.disabled = true;
    return;
  }

  estado.textContent = "Todavía no están activadas.";
  if (btnProbar) btnProbar.disabled = true;
}

async function obtenerRegistroServiceWorkerNotificaciones() {
  if (!("serviceWorker" in navigator)) {
    throw new Error("El navegador no admite Service Worker.");
  }

  let registro = await navigator.serviceWorker.getRegistration("./");

  if (!registro) {
    registro = await navigator.serviceWorker.register("service-worker.js?v=501", {
      scope: "./",
      updateViaCache: "none"
    });
  }

  await navigator.serviceWorker.ready;
  return registro;
}

async function guardarTokenNotificaciones(token) {
  if (!db || !token) return;

  const idSeguro = token.replace(/[^a-zA-Z0-9_-]/g, "").slice(0, 120);
  const datos = {
    token,
    plataforma: navigator.userAgent,
    pwa: window.matchMedia("(display-mode: standalone)").matches || Boolean(navigator.standalone),
    activo: true,
    actualizado: new Date().toISOString(),
    jornadaEnviada: true
  };

  await db.collection("fratello_notificaciones").doc(idSeguro).set(datos, { merge: true });
}

async function activarNotificacionesFratello() {
  const boton = $("btnActivarNotificaciones");
  const estado = $("estadoNotificaciones");

  if (boton) {
    boton.disabled = true;
    boton.textContent = "Activando...";
  }
  if (estado) estado.textContent = "Solicitando permiso...";

  try {
    if (!messaging) {
      throw new Error("Firebase Messaging no está disponible.");
    }

    const permiso = await Notification.requestPermission();

    if (permiso !== "granted") {
      throw new Error("No se concedió permiso para notificaciones.");
    }

    const registro = await obtenerRegistroServiceWorkerNotificaciones();

    const token = await messaging.getToken({
      vapidKey: CLAVE_VAPID_NOTIFICACIONES,
      serviceWorkerRegistration: registro
    });

    if (!token) {
      throw new Error("Firebase no devolvió un token para este dispositivo.");
    }

    tokenNotificaciones = token;
    localStorage.setItem("fratello_token_notificaciones", token);
    await guardarTokenNotificaciones(token);
    await enviarPreferenciasNotificacionesAlServiceWorker();

    actualizarEstadoNotificaciones();

    if (estado) estado.textContent = "✅ Dispositivo registrado correctamente.";
    if (boton) boton.textContent = "Notificaciones activadas";
  } catch (error) {
    console.error("Error activando notificaciones:", error);
    if (estado) estado.textContent = "❌ " + (error.message || "No se pudieron activar.");
    if (boton) {
      boton.disabled = false;
      boton.textContent = "Reintentar activación";
    }
    return;
  }

  if (boton) boton.disabled = false;
}

async function probarNotificacionFratello() {
  const boton = $("btnProbarNotificacion");
  const estado = $("estadoNotificaciones");

  if (Notification.permission !== "granted") {
    alert("Primero activá las notificaciones.");
    return;
  }

  if (boton) {
    boton.disabled = true;
    boton.textContent = "Enviando prueba...";
  }

  try {
    const registro = await obtenerRegistroServiceWorkerNotificaciones();

    await registro.showNotification("Fratello", {
      body: "✅ Las notificaciones funcionan correctamente.",
      icon: "icon-192.png",
      badge: "icon-192.png",
      tag: "fratello-prueba",
      data: { url: "./index.html" }
    });

    if (estado) estado.textContent = "✅ Notificación de prueba enviada.";
  } catch (error) {
    console.error("Error mostrando notificación de prueba:", error);
    if (estado) estado.textContent = "❌ No se pudo mostrar la prueba.";
  } finally {
    if (boton) {
      boton.disabled = false;
      boton.textContent = "Enviar prueba";
    }
  }
}

let temporizadorEstadoSync = null;
let temporizadorMostrarSincronizando = null;
let ultimoEstadoSyncEstable = "Online";

function esEstadoSincronizando(texto) {
  return [
    "Sincronizando...",
    "Cargando online...",
    "Sincronizando Caja...",
    "Sincronizando Administración...",
    "Conexión recuperada — sincronizando..."
  ].includes(texto);
}

function esEstadoSyncEstable(texto) {
  return [
    "Online",
    "Online actualizado",
    "Guardado online",
    "Sin conexión — modo local",
    "Modo local — Firebase no inició",
    "Error de sincronización",
    "Error recibiendo Caja",
    "Error recibiendo Administración",
    "Error de sincronización de Caja",
    "Error de sincronización de Administración",
    "Error online — requiere revisión",
    "Online · guardado pendiente",
    "Sin conexión — cambios guardados localmente"
  ].includes(texto);
}

function setEstadoSync(texto) {
  const el = $("estadoSync");
  if (!el) return;

  clearTimeout(temporizadorEstadoSync);

  if (esEstadoSincronizando(texto)) {
    // No mostrar sincronizaciones muy breves. Antes cada escritura interna
    // hacía que la cabecera pareciera estar sincronizando permanentemente.
    clearTimeout(temporizadorMostrarSincronizando);
    temporizadorMostrarSincronizando = setTimeout(() => {
      if (el.textContent === ultimoEstadoSyncEstable || esEstadoSyncEstable(el.textContent)) {
        el.textContent = texto;
      }

      temporizadorEstadoSync = setTimeout(() => {
        if (esEstadoSincronizando(el.textContent)) {
          el.textContent = navigator.onLine
            ? "Sincronización demorada — reintentando"
            : "Sin conexión — modo local";
        }
      }, 12000);
    }, 1800);
    return;
  }

  clearTimeout(temporizadorMostrarSincronizando);

  if (esEstadoSyncEstable(texto)) {
    ultimoEstadoSyncEstable = texto;
  }

  el.textContent = texto;
}

function clavePedidoSync(pedido) {
  if (!pedido || typeof pedido !== "object") return "";
  return String(pedido.id || "");
}

function fechaCambioPedidoSync(pedido) {
  const valor = pedido?.actualizadoEn || pedido?.actualizado || pedido?.creado || pedido?.fechaCreacion || "";
  const tiempo = Date.parse(valor);
  return Number.isFinite(tiempo) ? tiempo : 0;
}

function claveSemanticaPedidoSync(pedido) {
  if (!pedido || typeof pedido !== "object") return "";

  // La firma semántica se usa únicamente para pedidos fijos regenerables.
  // Los pedidos manuales se identifican solo por ID para que una carga nueva
  // nunca sea ocultada por una prueba anterior borrada con el mismo contenido.
  if (!esPedidoFijoRobusto(pedido) && pedido.origen !== "pedido_fijo") return "";

  const fecha = fechaEntregaPedido(pedido) || pedido.fecha || "";
  const cliente = normalizarClienteReparacion(pedido.cliente || "");
  const fijo = pedido.pedidoFijoId ? `fijo:${pedido.pedidoFijoId}` : "";
  const programa = normalizarClienteReparacion(
    pedido.programacionNombre || pedido.nombreProgramacion || ""
  );
  return [fecha, cliente, "pedido_fijo", fijo, programa].join("|");
}

function clavePedidoEliminado(item) {
  if (!item) return "";
  return typeof item === "string" ? item : String(item.id || "");
}

function claveSemanticaEliminado(item) {
  if (!item || typeof item === "string") return "";
  return String(item.claveSemantica || "");
}

function fechaPedidoEliminado(item) {
  if (!item || typeof item === "string") return 0;
  const tiempo = Date.parse(item.eliminadoEn || "");
  return Number.isFinite(tiempo) ? tiempo : 0;
}

function fusionarPedidosEliminados(remotos = [], locales = []) {
  const mapa = new Map();

  [...(Array.isArray(remotos) ? remotos : []), ...(Array.isArray(locales) ? locales : [])]
    .forEach(item => {
      const id = clavePedidoEliminado(item);
      const semantica = claveSemanticaEliminado(item);
      const claveMapa = semantica ? `s:${semantica}` : `i:${id}`;
      if (!id && !semantica) return;

      const anterior = mapa.get(claveMapa);
      if (!anterior || fechaPedidoEliminado(item) >= fechaPedidoEliminado(anterior)) {
        mapa.set(claveMapa, typeof item === "string"
          ? { id, eliminadoEn: new Date(0).toISOString() }
          : item
        );
      }
    });

  return [...mapa.values()];
}

function pedidoEstaEliminadoSync(pedido, eliminados = pedidosEliminados) {
  const id = clavePedidoSync(pedido);
  const semantica = claveSemanticaPedidoSync(pedido);
  const esFijo = esPedidoFijoRobusto(pedido) || pedido.origen === "pedido_fijo";

  const marca = (Array.isArray(eliminados) ? eliminados : []).find(item => {
    const coincideId = id && clavePedidoEliminado(item) === id;
    const coincideSemantica =
      esFijo &&
      semantica &&
      claveSemanticaEliminado(item) &&
      claveSemanticaEliminado(item) === semantica;
    return coincideId || coincideSemantica;
  });

  if (!marca) return false;
  return fechaPedidoEliminado(marca) >= fechaCambioPedidoSync(pedido);
}

function fusionarPedidosSync(remotos = [], locales = [], eliminados = pedidosEliminados) {
  const mapa = new Map();

  [...(Array.isArray(remotos) ? remotos : []), ...(Array.isArray(locales) ? locales : [])]
    .forEach(pedido => {
      const id = clavePedidoSync(pedido);
      if (!id || pedidoEstaEliminadoSync(pedido, eliminados)) return;

      const anterior = mapa.get(id);
      if (!anterior || fechaCambioPedidoSync(pedido) >= fechaCambioPedidoSync(anterior)) {
        mapa.set(id, pedido);
      }
    });

  return [...mapa.values()];
}


let guardadoPedidosModuloEnCurso = false;
let guardadoPedidosModuloPendiente = false;
let temporizadorPedidosModulo = null;
let escuchandoPedidosModulo = false;

function datosPedidosModulo() {
  return {
    pedidos: Array.isArray(pedidos) ? pedidos : [],
    pedidosEliminados: Array.isArray(pedidosEliminados) ? pedidosEliminados : [],
    pedidosFijos: Array.isArray(pedidosFijos) ? pedidosFijos : [],
    exclusionesPedidosFijos: Array.isArray(exclusionesPedidosFijos) ? exclusionesPedidosFijos : [],
    pedidosConfirmados: Boolean(pedidosConfirmados)
  };
}

function guardarPedidosLocal() {
  localStorage.setItem("fratello_pedidos", JSON.stringify(pedidos));
  localStorage.setItem("fratello_pedidos_eliminados", JSON.stringify(pedidosEliminados));
  localStorage.setItem("fratello_pedidos_fijos", JSON.stringify(pedidosFijos));
  localStorage.setItem("fratello_exclusiones_pedidos_fijos", JSON.stringify(exclusionesPedidosFijos));
  localStorage.setItem("fratello_pedidos_confirmados", JSON.stringify(pedidosConfirmados));
}

function aplicarPedidosModuloRemoto(data = {}) {
  pedidosEliminados = fusionarPedidosEliminados(
    data.pedidosEliminados,
    pedidosEliminados
  );

  pedidos = fusionarPedidosSync(
    data.pedidos,
    pedidos,
    pedidosEliminados
  )
    .filter(pedido => !pedidoEstaEliminadoSync(pedido));

  // Si llega un pedido nuevo desde otro dispositivo, esa fecha debe quedar abierta.
  // Evita que una jornada cerrada localmente oculte pedidos cargados por Atención.
  [...new Set(
    pedidos
      .filter(pedido => !esPedidoFijoRobusto(pedido))
      .map(pedido => fechaEntregaPedido(pedido))
      .filter(Boolean)
  )].forEach(fecha => reabrirJornadaParaNuevoPedido(fecha));

  pedidosFijos = fusionarPedidosFijosSync(
    data.pedidosFijos,
    pedidosFijos
  );

  exclusionesPedidosFijos = fusionarExclusionesPedidosFijos(
    data.exclusionesPedidosFijos,
    exclusionesPedidosFijos
  );

  if (typeof data.pedidosConfirmados === "boolean") {
    pedidosConfirmados = data.pedidosConfirmados;
  }

  guardarPedidosLocal();
}

function guardarPedidosModuloEnNube() {
  if (!db || cargandoDesdeNube) return Promise.resolve(false);

  guardadoPedidosModuloPendiente = true;
  clearTimeout(temporizadorPedidosModulo);

  return new Promise(resolve => {
    temporizadorPedidosModulo = setTimeout(async () => {
      if (guardadoPedidosModuloEnCurso || !guardadoPedidosModuloPendiente || !db) {
        resolve(false);
        return;
      }

      guardadoPedidosModuloEnCurso = true;
      guardadoPedidosModuloPendiente = false;

      try {
        const ref = db.collection("fratello").doc("pedidos_estado");

        await db.runTransaction(async tx => {
          const snap = await tx.get(ref);
          const remoto = snap.exists ? snap.data() : {};

          pedidosEliminados = fusionarPedidosEliminados(
            remoto.pedidosEliminados,
            pedidosEliminados
          );
          pedidos = fusionarPedidosSync(
            remoto.pedidos,
            pedidos,
            pedidosEliminados
          );
          pedidosFijos = fusionarPedidosFijosSync(
            remoto.pedidosFijos,
            pedidosFijos
          );
          exclusionesPedidosFijos = fusionarExclusionesPedidosFijos(
            remoto.exclusionesPedidosFijos,
            exclusionesPedidosFijos
          );

          tx.set(ref, {
            ...datosPedidosModulo(),
            actualizado: new Date().toISOString()
          }, { merge: true });
        });

        guardarPedidosLocal();
        resolve(true);
      } catch (error) {
        console.error("Error sincronizando Pedidos dedicado:", error);
        // El guardado general sigue funcionando como respaldo.
        resolve(false);
      } finally {
        guardadoPedidosModuloEnCurso = false;
        if (guardadoPedidosModuloPendiente) guardarPedidosModuloEnNube();
      }
    }, 220);
  });
}

async function iniciarPedidosModuloNube() {
  if (!db) return;

  try {
    const ref = db.collection("fratello").doc("pedidos_estado");
    const snap = await ref.get();

    if (snap.exists) {
      cargandoDesdeNube = true;
      try {
        aplicarPedidosModuloRemoto(snap.data());
      } finally {
        cargandoDesdeNube = false;
      }
    }

    // Publica la fusión inicial para migrar pedidos que todavía estuvieran
    // solamente en el documento general o en almacenamiento local.
    await guardarPedidosModuloEnNube();

    if (!escuchandoPedidosModulo) {
      escuchandoPedidosModulo = true;
      ref.onSnapshot(doc => {
        if (!doc.exists) return;

        cargandoDesdeNube = true;
        try {
          aplicarPedidosModuloRemoto(doc.data());
          renderPedidosCargados();
          renderPedidosFuturos();
          renderHistorialPedidos();
          calcularDiferencias();
          actualizarEstadoConfirmacion();
          renderTicketsPorDia();
        } catch (error) {
          console.error("Error recibiendo Pedidos dedicado:", error);
        } finally {
          cargandoDesdeNube = false;
        }
      }, error => {
        console.error("Listener Pedidos dedicado:", error);
      });
    }
  } catch (error) {
    console.error("Error iniciando Pedidos dedicado:", error);
  }
}

function registrarPedidoEliminado(pedido) {
  const id = clavePedidoSync(pedido);
  const claveSemantica = claveSemanticaPedidoSync(pedido);
  if (!id && !claveSemantica) return;

  pedidosEliminados = fusionarPedidosEliminados(
    pedidosEliminados,
    [{
      id,
      claveSemantica,
      fecha: fechaEntregaPedido(pedido),
      cliente: pedido.cliente || "",
      eliminadoEn: new Date().toISOString()
    }]
  );
}

function limpiarMarcaPedidoEliminado(pedido) {
  const id = clavePedidoSync(pedido);
  const semantica = claveSemanticaPedidoSync(pedido);

  pedidosEliminados = pedidosEliminados.filter(item => {
    const mismoId = id && clavePedidoEliminado(item) === id;
    const mismaSemantica =
      semantica &&
      claveSemanticaEliminado(item) &&
      claveSemanticaEliminado(item) === semantica;
    return !mismoId && !mismaSemantica;
  });
}

function fusionarPedidosFijosSync(remotos = [], locales = []) {
  const mapa = new Map();
  [...(Array.isArray(remotos) ? remotos : []), ...(Array.isArray(locales) ? locales : [])]
    .forEach(fijo => {
      if (!fijo) return;
      const clave = String(fijo.id || `${fijo.cliente || ""}|${fijo.nombre || ""}`);
      const anterior = mapa.get(clave);
      const fechaActual = Date.parse(fijo.actualizado || fijo.creado || "") || 0;
      const fechaAnterior = Date.parse(anterior?.actualizado || anterior?.creado || "") || 0;
      if (!anterior || fechaActual >= fechaAnterior) mapa.set(clave, fijo);
    });
  return [...mapa.values()];
}

function fusionarExclusionesPedidosFijos(remotas = [], locales = []) {
  return [...new Set([
    ...(Array.isArray(remotas) ? remotas : []),
    ...(Array.isArray(locales) ? locales : [])
  ].filter(Boolean))];
}



function fechaCambioAdminSync(item) {
  const valor = item?.actualizadoEn || item?.actualizado || item?.creadoEn || item?.creado || "";
  const tiempo = Date.parse(valor);
  return Number.isFinite(tiempo) ? tiempo : 0;
}

function fusionarListaAdminSync(remota = [], local = []) {
  const mapa = new Map();
  [...(Array.isArray(remota) ? remota : []), ...(Array.isArray(local) ? local : [])]
    .forEach(item => {
      if (!item) return;
      const clave = String(item.id || "");
      if (!clave) return;
      const anterior = mapa.get(clave);
      if (!anterior || fechaCambioAdminSync(item) >= fechaCambioAdminSync(anterior)) {
        mapa.set(clave, item);
      }
    });
  return [...mapa.values()];
}

function fusionarAdministracionFinancieraSync(remota = {}, local = {}) {
  const clientesEliminados = [...new Set([
    ...(Array.isArray(remota.clientesExternosEliminados) ? remota.clientesExternosEliminados : []),
    ...(Array.isArray(local.clientesExternosEliminados) ? local.clientesExternosEliminados : [])
  ].map(x => String(x || "").trim()).filter(Boolean))];

  const clientes = fusionarListaAdminSync(remota.clientesExternos, local.clientesExternos)
    .filter(cliente => !clientesEliminados.some(nombre =>
      normalizarPedidoInteligente(nombre) === normalizarPedidoInteligente(cliente.nombre)
    ));

  return {
    ingresosExternos: fusionarListaAdminSync(remota.ingresosExternos, local.ingresosExternos),
    clientesExternos: clientes,
    clientesExternosEliminados: clientesEliminados,
    gastosManuales: fusionarListaAdminSync(remota.gastosManuales, local.gastosManuales),
    presupuestos: fusionarListaAdminSync(remota.presupuestos, local.presupuestos),
    plataRealManual: { ...(remota.plataRealManual || {}), ...(local.plataRealManual || {}) },
    transferenciasDinero: fusionarListaAdminSync(remota.transferenciasDinero, local.transferenciasDinero)
  };
}

function datosActuales() {
  return {
    produccion,
    pedidos,
    pedidosEliminados,
    pedidosFijos,
    historialPedidos,
    predeterminadas,
    clientes,
    datosClientesCompletos,
    listasPrecios,
    listasPrecioPersonalizadas,
    ticketsMemoria,
    pedidosHoy,
    productosExtra,
    catalogoProductos: productos,
    pedidosConfirmados,
    correspondePedido,
    memoriaUltimoEnvio,
    jornadasCerradas,
    exclusionesPedidosFijos,
    actualizado: new Date().toISOString()
  };
}


function claveCierreCajaSync(cierre) {
  if (!cierre || typeof cierre !== "object") return "";
  return String(cierre.id || `${cierre.fecha || ""}_${cierre.turno || ""}`);
}

function fechaCambioCierreCaja(cierre) {
  const valor = cierre?.actualizadoEn || cierre?.actualizado || cierre?.creado || "";
  const tiempo = Date.parse(valor);
  return Number.isFinite(tiempo) ? tiempo : 0;
}

function claveCierreCajaEliminado(item) {
  if (!item) return "";
  return typeof item === "string" ? item : String(item.id || "");
}

function fechaEliminacionCierreCaja(item) {
  if (!item || typeof item === "string") return 0;
  const tiempo = Date.parse(item.eliminadoEn || "");
  return Number.isFinite(tiempo) ? tiempo : 0;
}

function fusionarCierresCajaEliminados(remotos = [], locales = []) {
  const mapa = new Map();
  [...(Array.isArray(remotos) ? remotos : []), ...(Array.isArray(locales) ? locales : [])]
    .forEach(item => {
      const clave = claveCierreCajaEliminado(item);
      if (!clave) return;
      const anterior = mapa.get(clave);
      if (!anterior || fechaEliminacionCierreCaja(item) >= fechaEliminacionCierreCaja(anterior)) {
        mapa.set(clave, typeof item === "string"
          ? { id: clave, eliminadoEn: new Date(0).toISOString() }
          : item
        );
      }
    });
  return [...mapa.values()];
}

function cierreCajaEstaEliminado(cierre, eliminados = cierresCajaEliminados) {
  const clave = claveCierreCajaSync(cierre);
  const marca = (Array.isArray(eliminados) ? eliminados : [])
    .find(item => claveCierreCajaEliminado(item) === clave);
  if (!marca) return false;
  return fechaEliminacionCierreCaja(marca) >= fechaCambioCierreCaja(cierre);
}

function fusionarCierresCaja(remotos = [], locales = [], eliminados = cierresCajaEliminados) {
  const mapa = new Map();

  [...(Array.isArray(remotos) ? remotos : []), ...(Array.isArray(locales) ? locales : [])]
    .forEach(cierre => {
      const clave = claveCierreCajaSync(cierre);
      if (!clave || cierreCajaEstaEliminado(cierre, eliminados)) return;

      const anterior = mapa.get(clave);
      if (!anterior || fechaCambioCierreCaja(cierre) >= fechaCambioCierreCaja(anterior)) {
        mapa.set(clave, cierre);
      }
    });

  return [...mapa.values()].sort((a, b) => {
    const porFecha = String(a.fecha || "").localeCompare(String(b.fecha || ""));
    if (porFecha !== 0) return porFecha;
    return String(a.turno || "").localeCompare(String(b.turno || ""));
  });
}

function firmaCierresCaja(lista = cierresCaja) {
  return JSON.stringify(
    (Array.isArray(lista) ? lista : []).map(cierre => [
      claveCierreCajaSync(cierre),
      cierre?.actualizadoEn || cierre?.actualizado || cierre?.creado || "",
      cierre?.efectivo || 0,
      cierre?.transferencias || 0,
      Array.isArray(cierre?.gastos) ? cierre.gastos.length : 0
    ])
  );
}

let ultimaFirmaCajaRenderizada = "";

function aplicarCierresCajaDesdeNube(listaRemota, eliminadosRemotos = [], auditoriaRemota = []) {
  cierresCajaEliminados = fusionarCierresCajaEliminados(
    eliminadosRemotos,
    cierresCajaEliminados
  );
  auditoriaCaja = fusionarAuditoriaCaja(auditoriaRemota, auditoriaCaja);
  const fusionados = fusionarCierresCaja(
    listaRemota,
    cierresCaja,
    cierresCajaEliminados
  );
  const nuevaFirma = firmaCierresCaja(fusionados);

  if (nuevaFirma === ultimaFirmaCajaRenderizada) return false;

  cierresCaja = fusionados;
  ultimaFirmaCajaRenderizada = nuevaFirma;
  guardarCajaLocal();
  cargarCierreSeleccionadoCaja();
  renderCajaAdmin();
  renderDashboardCaja();
  renderAdministracionFinanciera();
  return true;
}

let temporizadorGuardadoNube = null;
let guardadoNubeEnCurso = false;
let guardadoNubePendiente = false;
let intentosGuardadoNube = 0;
const MAX_REINTENTOS_GUARDADO_NUBE = 3;

function errorFirebaseReintentable(error) {
  const codigo = String(error?.code || "").toLowerCase();
  if (!codigo) return true;

  const permanentes = [
    "permission-denied",
    "invalid-argument",
    "failed-precondition",
    "resource-exhausted",
    "unauthenticated"
  ];
  return !permanentes.some(valor => codigo.includes(valor));
}

function guardarEnNube(esReintento = false) {
  if (!db || cargandoDesdeNube) return Promise.resolve(false);

  // Pedidos se guarda además en un documento pequeño e independiente.
  // Así un fallo/lentitud del documento general no impide verlo en otros dispositivos.
  guardarPedidosModuloEnNube().catch(() => {});

  if (!esReintento) intentosGuardadoNube = 0;
  guardadoNubePendiente = true;
  clearTimeout(temporizadorGuardadoNube);

  return new Promise(resolve => {
    temporizadorGuardadoNube = setTimeout(async () => {
      if (guardadoNubeEnCurso || !guardadoNubePendiente || !db || cargandoDesdeNube) {
        resolve(false);
        return;
      }

      guardadoNubeEnCurso = true;
      guardadoNubePendiente = false;
      setEstadoSync("Sincronizando...");

      try {
        const referencia = db.collection("fratello").doc("estado");

        await db.runTransaction(async transaccion => {
          const snapshot = await transaccion.get(referencia);
          const remoto = snapshot.exists ? snapshot.data() : {};

          pedidosEliminados = fusionarPedidosEliminados(
            remoto.pedidosEliminados,
            pedidosEliminados
          );
          pedidos = fusionarPedidosSync(
            remoto.pedidos,
            pedidos,
            pedidosEliminados
          );
          pedidosFijos = fusionarPedidosFijosSync(
            remoto.pedidosFijos,
            pedidosFijos
          );
          exclusionesPedidosFijos = fusionarExclusionesPedidosFijos(
            remoto.exclusionesPedidosFijos,
            exclusionesPedidosFijos
          );

          transaccion.set(
            referencia,
            {
              ...datosActuales(),
              pedidos,
              pedidosEliminados,
              pedidosFijos,
              exclusionesPedidosFijos,
              actualizado: new Date().toISOString()
            },
            { merge: true }
          );
        });

        intentosGuardadoNube = 0;
        setEstadoSync("Guardado online");
        setTimeout(() => setEstadoSync("Online actualizado"), 900);
        resolve(true);
      } catch (error) {
        console.error("Error guardando en Firebase:", error);

        intentosGuardadoNube += 1;
        const reintentable = errorFirebaseReintentable(error);
        const puedeReintentar =
          navigator.onLine &&
          reintentable &&
          intentosGuardadoNube < MAX_REINTENTOS_GUARDADO_NUBE;

        if (puedeReintentar) {
          guardadoNubePendiente = true;
          const demora = [2500, 7000, 15000][Math.max(0, intentosGuardadoNube - 1)] || 15000;
          setEstadoSync(`Error temporal · reintento ${intentosGuardadoNube}/${MAX_REINTENTOS_GUARDADO_NUBE}`);
          setTimeout(() => guardarEnNube(true), demora);
        } else {
          guardadoNubePendiente = false;
          if (!navigator.onLine) {
            setEstadoSync("Sin conexión — cambios guardados localmente");
          } else if (!reintentable) {
            setEstadoSync("Error online — requiere revisión");
          } else {
            setEstadoSync("Online · guardado pendiente");
          }
        }

        resolve(false);
      } finally {
        guardadoNubeEnCurso = false;
      }
    }, 350);
  });
}
async function cargarDesdeNube() {
  if (!db) {
    console.error("Firebase no se inicializó. Revisar scripts o conexión.");
    setEstadoSync("Modo local — Firebase no inició");
    return;
  }

  try {
    setEstadoSync("Cargando online...");
    const doc = await db.collection("fratello").doc("estado").get();

    if (doc.exists) {
      const data = doc.data();

      produccion = data.produccion || produccion;
      pedidosEliminados = fusionarPedidosEliminados(
        data.pedidosEliminados,
        pedidosEliminados
      );
      pedidos = fusionarPedidosSync(data.pedidos, pedidos, pedidosEliminados);
      pedidos = pedidos.filter(pedido => !jornadaEstaCerrada(fechaEntregaPedido(pedido)));
      pedidosFijos = fusionarPedidosFijosSync(data.pedidosFijos, pedidosFijos);
      historialPedidos = Array.isArray(data.historialPedidos)
        ? data.historialPedidos
        : historialPedidos;
      exclusionesPedidosFijos = fusionarExclusionesPedidosFijos(
        data.exclusionesPedidosFijos,
        exclusionesPedidosFijos
      );

      cierresCajaEliminados = fusionarCierresCajaEliminados(
        data.cierresCajaEliminados,
        cierresCajaEliminados
      );
      auditoriaCaja = fusionarAuditoriaCaja(data.auditoriaCaja, auditoriaCaja);
      cierresCaja = fusionarCierresCaja(
        data.cierresCaja,
        cierresCaja,
        cierresCajaEliminados
      );
      ultimaFirmaCajaRenderizada = firmaCierresCaja(cierresCaja);
      personasCaja = Array.isArray(data.personasCaja) && data.personasCaja.length
        ? data.personasCaja
        : personasCaja;
      configuracionCaja = data.configuracionCaja && typeof data.configuracionCaja === "object"
        ? { ...configuracionCaja, ...data.configuracionCaja }
        : configuracionCaja;
      guardarCajaLocal();

      if (data.administracionFinanciera && typeof data.administracionFinanciera === "object") {
        administracionFinanciera = fusionarAdministracionFinancieraSync(
          data.administracionFinanciera,
          administracionFinanciera
        );
        guardarAdministracionLocal();
        renderAdministracionFinanciera();
      }

      predeterminadas = data.predeterminadas || predeterminadas;
      clientes = Array.isArray(data.clientes) && data.clientes.length
        ? data.clientes
        : clientes;

      datosClientesCompletos =
        data.datosClientesCompletos || datosClientesCompletos;
      listasPrecios = data.listasPrecios || listasPrecios;
    listasPrecioPersonalizadas = Array.isArray(data.listasPrecioPersonalizadas)
      ? data.listasPrecioPersonalizadas
      : listasPrecioPersonalizadas;
    ticketsMemoria = Array.isArray(data.ticketsMemoria)
      ? data.ticketsMemoria
      : ticketsMemoria;
    pedidosHoy = Array.isArray(data.pedidosHoy)
      ? data.pedidosHoy
      : pedidosHoy;
      listasPrecioPersonalizadas = Array.isArray(data.listasPrecioPersonalizadas)
        ? data.listasPrecioPersonalizadas
        : listasPrecioPersonalizadas;
      productosExtra = Array.isArray(data.productosExtra)
        ? data.productosExtra
        : productosExtra;

      // Nunca vaciar el catálogo si Firebase no trae uno válido.
      if (Array.isArray(data.catalogoProductos) && data.catalogoProductos.length) {
        productos.splice(0, productos.length, ...data.catalogoProductos);
        asegurarProductoCriollosCatalogo();
      }

      productosExtra.forEach(productoExtra => {
        if (!productos.find(producto => producto.id === productoExtra.id)) {
          productos.push(productoExtra);
        }
      });

      pedidosConfirmados = Boolean(data.pedidosConfirmados);
      correspondePedido = data.correspondePedido || correspondePedido;
      memoriaUltimoEnvio = data.memoriaUltimoEnvio || memoriaUltimoEnvio;
      jornadasCerradas = Array.isArray(data.jornadasCerradas) ? data.jornadasCerradas : jornadasCerradas;
      exclusionesPedidosFijos = fusionarExclusionesPedidosFijos(
        data.exclusionesPedidosFijos,
        exclusionesPedidosFijos
      );

      validarClientes();

      localStorage.setItem("fratello_produccion", JSON.stringify(produccion));
      localStorage.setItem("fratello_pedidos", JSON.stringify(pedidos));
      localStorage.setItem("fratello_pedidos_eliminados", JSON.stringify(pedidosEliminados));
  localStorage.setItem("fratello_pedidos_eliminados", JSON.stringify(pedidosEliminados));
      localStorage.setItem("fratello_pedidos_fijos", JSON.stringify(pedidosFijos));
      localStorage.setItem("fratello_historial_pedidos", JSON.stringify(historialPedidos));
      localStorage.setItem("fratello_exclusiones_pedidos_fijos", JSON.stringify(exclusionesPedidosFijos));
  localStorage.setItem("fratello_pedidos_fijos", JSON.stringify(pedidosFijos));
  localStorage.setItem("fratello_historial_pedidos", JSON.stringify(historialPedidos));
      localStorage.setItem("fratello_predeterminadas", JSON.stringify(predeterminadas));
      localStorage.setItem("fratello_clientes", JSON.stringify(clientes));
      localStorage.setItem("fratello_clientes_completos", JSON.stringify(datosClientesCompletos));
    localStorage.setItem("fratello_listas_precios", JSON.stringify(listasPrecios));
  localStorage.setItem(
    "fratello_listas_precio_personalizadas",
    JSON.stringify(listasPrecioPersonalizadas)
  );
      localStorage.setItem("fratello_listas_precios", JSON.stringify(listasPrecios));
      localStorage.setItem(
        "fratello_listas_precio_personalizadas",
        JSON.stringify(listasPrecioPersonalizadas)
      );
      localStorage.setItem("fratello_tickets_memoria", JSON.stringify(ticketsMemoria));
      localStorage.setItem("fratello_pedidos_hoy", JSON.stringify(pedidosHoy));
      localStorage.setItem("fratello_productos_extra", JSON.stringify(productosExtra));
      localStorage.setItem("fratello_catalogo_productos", JSON.stringify(productos));
      localStorage.setItem("fratello_pedidos_confirmados", JSON.stringify(pedidosConfirmados));
      localStorage.setItem("fratello_memoria_envio", JSON.stringify(memoriaUltimoEnvio));
      localStorage.setItem("fratello_jornadas_cerradas", JSON.stringify(jornadasCerradas));
      localStorage.setItem("fratello_exclusiones_pedidos_fijos", JSON.stringify(exclusionesPedidosFijos));
}

    setEstadoSync("Online");
  } catch (error) {
    console.error("Error cargando Firebase:", error);
    setEstadoSync("Error online / usando local");
  }
}

async function actualizarDatosManual(evento = null) {
  const botonGlobal = $("btnActualizarGlobal");
  const botonPrincipal = $("btnActualizarDatos");
  const botones = [botonGlobal, botonPrincipal].filter(Boolean);
  const estado = $("estadoActualizacionManual");

  botones.forEach(boton => {
    boton.disabled = true;
    boton.classList.add("actualizando");
  });

  if (botonGlobal) botonGlobal.textContent = "⏳";
  if (estado) estado.textContent = "Consultando Firebase...";

  try {
    if (!db) throw new Error("Firebase no está conectado.");

    const doc = await db.collection("fratello").doc("estado").get();
    if (!doc.exists) throw new Error("No hay datos guardados en Firebase.");

    const data = doc.data();
    cargandoDesdeNube = true;

    produccion = data.produccion || produccion;
    jornadasCerradas = Array.isArray(data.jornadasCerradas)
      ? data.jornadasCerradas
      : jornadasCerradas;
    exclusionesPedidosFijos = fusionarExclusionesPedidosFijos(
      data.exclusionesPedidosFijos,
      exclusionesPedidosFijos
    );

    pedidosEliminados = fusionarPedidosEliminados(
      data.pedidosEliminados,
      pedidosEliminados
    );
    pedidos = fusionarPedidosSync(data.pedidos, pedidos, pedidosEliminados)
      .filter(pedido => !jornadaEstaCerrada(fechaEntregaPedido(pedido)));
    pedidosFijos = fusionarPedidosFijosSync(data.pedidosFijos, pedidosFijos);

    predeterminadas = data.predeterminadas || predeterminadas;
    clientes = Array.isArray(data.clientes) && data.clientes.length ? data.clientes : clientes;
    datosClientesCompletos = data.datosClientesCompletos || datosClientesCompletos;
    listasPrecios = data.listasPrecios || listasPrecios;
    listasPrecioPersonalizadas = Array.isArray(data.listasPrecioPersonalizadas)
      ? data.listasPrecioPersonalizadas
      : listasPrecioPersonalizadas;
    ticketsMemoria = Array.isArray(data.ticketsMemoria)
      ? data.ticketsMemoria
      : ticketsMemoria;
    pedidosHoy = Array.isArray(data.pedidosHoy)
      ? data.pedidosHoy
      : pedidosHoy;
    productosExtra = data.productosExtra || productosExtra;
    pedidosConfirmados = Boolean(data.pedidosConfirmados);
    correspondePedido = data.correspondePedido || correspondePedido;
    memoriaUltimoEnvio = data.memoriaUltimoEnvio || memoriaUltimoEnvio;

    if (Array.isArray(data.catalogoProductos) && data.catalogoProductos.length) {
      productos.splice(0, productos.length, ...data.catalogoProductos);
      asegurarProductoCriollosCatalogo();
    }

    validarClientes();
    productosExtra.forEach(producto => {
      if (!productos.find(item => item.id === producto.id)) productos.push(producto);
    });

    localStorage.setItem("fratello_produccion", JSON.stringify(produccion));
    localStorage.setItem("fratello_pedidos", JSON.stringify(pedidos));
      localStorage.setItem("fratello_pedidos_eliminados", JSON.stringify(pedidosEliminados));
    localStorage.setItem("fratello_predeterminadas", JSON.stringify(predeterminadas));
    localStorage.setItem("fratello_clientes", JSON.stringify(clientes));
    localStorage.setItem("fratello_clientes_completos", JSON.stringify(datosClientesCompletos));
    localStorage.setItem("fratello_listas_precios", JSON.stringify(listasPrecios));
    localStorage.setItem(
      "fratello_listas_precio_personalizadas",
      JSON.stringify(listasPrecioPersonalizadas)
    );
    localStorage.setItem("fratello_productos_extra", JSON.stringify(productosExtra));
    localStorage.setItem("fratello_catalogo_productos", JSON.stringify(productos));
    localStorage.setItem("fratello_pedidos_confirmados", JSON.stringify(pedidosConfirmados));
    localStorage.setItem("fratello_memoria_envio", JSON.stringify(memoriaUltimoEnvio));
    localStorage.setItem("fratello_jornadas_cerradas", JSON.stringify(jornadasCerradas));
      localStorage.setItem("fratello_exclusiones_pedidos_fijos", JSON.stringify(exclusionesPedidosFijos));

    renderClientes();
    renderListaClientesCompleta();
    renderProduccion();
    renderPedidosCargados();
    renderPedidosFuturos();
    renderPedidosRecibidosFormulario();
    renderHistorialPedidos();
    calcularDiferencias();
    actualizarPanelMemoriaEnvio();
    actualizarTarjetaDiaPedidos();
    actualizarCampanaNotificaciones();
    await cargarHistorialNotificaciones();

    const hora = new Date().toLocaleTimeString("es-AR", {
      hour: "2-digit",
      minute: "2-digit"
    });

    if (estado) estado.textContent = `✅ Datos actualizados a las ${hora}`;
    if (botonGlobal) botonGlobal.textContent = "✅";
    setEstadoSync("Online actualizado");

    setTimeout(() => {
      if (botonGlobal) botonGlobal.textContent = "🔄";
    }, 1200);
  } catch (error) {
    console.error("Error actualizando datos:", error);
    if (estado) estado.textContent = "❌ No se pudieron actualizar los datos";
    if (botonGlobal) botonGlobal.textContent = "⚠️";

    setTimeout(() => {
      if (botonGlobal) botonGlobal.textContent = "🔄";
    }, 1600);
  } finally {
    cargandoDesdeNube = false;
    botones.forEach(boton => {
      boton.disabled = false;
      boton.classList.remove("actualizando");
    });
  }
}


let guardandoInterpretacionFormulario = false;

function interpretarPedidosFormularioPendientes(listaPedidos) {
  let huboCambios = false;

  const interpretados = (Array.isArray(listaPedidos) ? listaPedidos : []).map(pedido => {
    const esFormulario = pedido?.origen === "formulario_cliente";
    const necesitaInterpretacion =
      pedido?.pendienteInterpretacion === true ||
      (esFormulario && pedido?.textoOriginal && (!Array.isArray(pedido.items) || pedido.items.length === 0));

    if (!necesitaInterpretacion) return pedido;

    const items = procesarTextoPedido(
      pedido.textoOriginal || "",
      pedido.cliente || "",
      pedido.fecha || hoyISO()
    );

    huboCambios = true;

    return {
      ...pedido,
      items,
      pendienteInterpretacion: false,
      versionInterpretador: "motor_central_v101",
      interpretadoEn: new Date().toISOString()
    };
  });

  return { pedidos: interpretados, huboCambios };
}

async function guardarInterpretacionFormularioEnNube() {
  if (!db || guardandoInterpretacionFormulario) return;
  guardandoInterpretacionFormulario = true;

  try {
    await db.collection("fratello").doc("estado").set({
      pedidos,
      productosExtra,
      catalogoProductos: productos,
      pedidosConfirmados: false,
      actualizado: new Date().toISOString()
    }, { merge: true });
  } catch (error) {
    console.error("No se pudo guardar la interpretación del formulario:", error);
  } finally {
    guardandoInterpretacionFormulario = false;
  }
}

function reprocesarPedidoFormulario(pedidoId) {
  const pedido = pedidos.find(p => Number(p.id) === Number(pedidoId));
  if (!pedido || !pedido.textoOriginal) {
    alert("Este pedido no tiene el texto original para volver a interpretarlo.");
    return;
  }

  pedido.items = procesarTextoPedido(
    pedido.textoOriginal,
    pedido.cliente || "",
    pedido.fecha || hoyISO()
  );
  pedido.pendienteInterpretacion = false;
  pedido.versionInterpretador = "parser_v311_decimales";
  pedido.interpretadoEn = new Date().toISOString();
  pedidosConfirmados = false;

  guardarTodo();
  renderPedidosCargados();
  renderUltimoProcesado();
  calcularDiferencias();
  actualizarAvisoUnidadesAmbiguas();
  actualizarEstadoConfirmacion();

  alert("Pedido reinterpretado con el motor inteligente.");
}

let idsPedidosFormularioConocidos = new Set();
let primeraSincronizacionPedidosCompletada = false;

function inicializarIdsPedidosFormularioConocidos() {
  idsPedidosFormularioConocidos = new Set(
    (Array.isArray(pedidos) ? pedidos : [])
      .filter(pedido => pedido?.origen === "formulario_cliente")
      .map(pedido => String(pedido.id))
      .filter(Boolean)
  );
}

function pedidosFormularioRecibidos() {
  return pedidos
    .filter(pedido => pedido?.origen === "formulario_cliente")
    .sort((a, b) => Number(b.id || 0) - Number(a.id || 0));
}

function verPedidoFormularioEnFecha(idPedido) {
  const pedido = pedidos.find(item => Number(item.id) === Number(idPedido));
  if (!pedido) return;

  const fecha = fechaEntregaPedido(pedido);
  if ($("fechaPedido")) {
    $("fechaPedido").value = fecha;
    $("fechaPedido").dispatchEvent(new Event("change", { bubbles: true }));
  }

  abrirSeccionFratello("seccionPedidos");
  renderPedidosCargados();

  setTimeout(() => {
    document.querySelector(`[data-pedido-card-id="${pedido.id}"]`)
      ?.scrollIntoView({ behavior: "smooth", block: "center" });
  }, 150);
}

function renderPedidosRecibidosFormulario() {
  renderPanelPedidosSemana();
}


async function mostrarNotificacionLocalPedido(pedido) {
  if (!pedido || pedido.origen !== "formulario_cliente") return;
  if (!notificacionesPermitidasParaPedido(pedido)) return;
  if (!("Notification" in window) || Notification.permission !== "granted") return;

  colaNotificacionesPedidos.push(pedido);

  if (!configuracionNotificaciones.agrupar) {
    await vaciarColaNotificacionesPedidos();
    return;
  }

  clearTimeout(temporizadorGrupoNotificaciones);
  temporizadorGrupoNotificaciones = setTimeout(
    vaciarColaNotificacionesPedidos,
    1800
  );
}

async function vaciarColaNotificacionesPedidos() {
  if (!colaNotificacionesPedidos.length) return;

  const pedidosPendientes = [...colaNotificacionesPedidos];
  colaNotificacionesPedidos = [];

  try {
    const registro = await obtenerRegistroServiceWorkerNotificaciones();
    const cantidad = pedidosPendientes.length;
    const ultimo = pedidosPendientes[pedidosPendientes.length - 1];

    const titulo = cantidad === 1
      ? "Nuevo pedido recibido"
      : `${cantidad} pedidos nuevos`;

    const cuerpo = cantidad === 1
      ? `${ultimo.cliente || "Un cliente"} envió un pedido para ${new Date(fechaEntregaPedido(ultimo) + "T12:00:00").toLocaleDateString("es-AR")}.`
      : pedidosPendientes
          .map(pedido => pedido.cliente || "Cliente")
          .slice(0, 5)
          .join(" · ");

    await registro.showNotification(titulo, {
      body: cuerpo,
      icon: "./icon-192.png",
      badge: "./icon-192.png",
      tag: configuracionNotificaciones.agrupar
        ? "fratello-pedidos-nuevos"
        : `pedido-cliente-${ultimo.id}`,
      renotify: false,
      silent: !configuracionNotificaciones.sonido,
      vibrate: configuracionNotificaciones.vibracion ? [180, 80, 180] : [],
      data: {
        url: `./index.html?abrir=pedidos&fecha=${encodeURIComponent(fechaEntregaPedido(ultimo))}&pedido=${encodeURIComponent(ultimo.id)}`,
        cliente: ultimo.cliente || "",
        pedidoId: ultimo.id
      }
    });
  } catch (error) {
    console.error("No se pudo mostrar la notificación local:", error);
  }
}
function pedidoDebeNotificar(pedido) {
  return Boolean(pedido && pedido.origen === "formulario_cliente");
}

function detectarPedidosNotificablesNuevos(listaNueva) {
  const nuevosExternos = (Array.isArray(listaNueva) ? listaNueva : []).filter(pedido => {
    if (!pedido || pedido.origen !== "formulario_cliente") return false;

    const id = String(pedido.id || "");
    if (!id || idsPedidosFormularioConocidos.has(id)) return false;

    return true;
  });

  nuevosExternos.forEach(pedido => {
    idsPedidosFormularioConocidos.add(String(pedido.id));
    mostrarNotificacionLocalPedido(pedido);
  });

  return nuevosExternos;
}


function escucharCambiosNube() {
  if (!db) return;

  db.collection("fratello").doc("estado").onSnapshot((doc) => {
    if (!doc.exists) return;

    cargandoDesdeNube = true;

    try {
      const data = doc.data();

      produccion = data.produccion || produccion;

      pedidosEliminados = fusionarPedidosEliminados(
        data.pedidosEliminados,
        pedidosEliminados
      );
      const pedidosFusionados = fusionarPedidosSync(
        data.pedidos,
        pedidos,
        pedidosEliminados
      );
      const resultadoInterpretacion = interpretarPedidosFormularioPendientes(pedidosFusionados);
      pedidos = resultadoInterpretacion.pedidos
        .filter(pedido => !pedidoEstaEliminadoSync(pedido))
        .filter(pedido => !jornadaEstaCerrada(fechaEntregaPedido(pedido)));

      pedidosFijos = fusionarPedidosFijosSync(data.pedidosFijos, pedidosFijos);
      exclusionesPedidosFijos = fusionarExclusionesPedidosFijos(
        data.exclusionesPedidosFijos,
        exclusionesPedidosFijos
      );

      // En la primera sincronización de cada carga de página se registra
      // el estado existente, pero no se muestra ninguna notificación.
      // Solo cambios posteriores pueden avisar pedidos externos nuevos.
      if (!primeraSincronizacionPedidosCompletada) {
        idsPedidosFormularioConocidos = new Set(
          pedidos
            .filter(pedido => pedido?.origen === "formulario_cliente")
            .map(pedido => String(pedido.id || ""))
            .filter(Boolean)
        );
        primeraSincronizacionPedidosCompletada = true;
      } else {
        detectarPedidosNotificablesNuevos(pedidos);
      }

      predeterminadas = data.predeterminadas || predeterminadas;
      clientes = Array.isArray(data.clientes) && data.clientes.length
        ? data.clientes
        : clientes;
      datosClientesCompletos = data.datosClientesCompletos || datosClientesCompletos;
      listasPrecios = data.listasPrecios || listasPrecios;
      productosExtra = data.productosExtra || productosExtra;
      pedidosConfirmados = Boolean(data.pedidosConfirmados);
      correspondePedido = data.correspondePedido || correspondePedido;
      memoriaUltimoEnvio = data.memoriaUltimoEnvio || memoriaUltimoEnvio;
      jornadasCerradas = Array.isArray(data.jornadasCerradas) ? data.jornadasCerradas : jornadasCerradas;

      // Caja y Administración se sincronizan en documentos dedicados
      // desde v5.2.8. El documento legacy "estado" queda solo para módulos históricos.

      validarClientes();

      productosExtra.forEach(p => {
        if (!productos.find(x => x.id === p.id)) productos.push(p);
      });

      localStorage.setItem("fratello_produccion", JSON.stringify(produccion));
      localStorage.setItem("fratello_pedidos", JSON.stringify(pedidos));
      localStorage.setItem("fratello_pedidos_eliminados", JSON.stringify(pedidosEliminados));
      localStorage.setItem("fratello_predeterminadas", JSON.stringify(predeterminadas));
      localStorage.setItem("fratello_clientes", JSON.stringify(clientes));
      localStorage.setItem("fratello_clientes_completos", JSON.stringify(datosClientesCompletos));
      localStorage.setItem("fratello_productos_extra", JSON.stringify(productosExtra));
      localStorage.setItem("fratello_pedidos_confirmados", JSON.stringify(pedidosConfirmados));
      localStorage.setItem("fratello_memoria_envio", JSON.stringify(memoriaUltimoEnvio));
      localStorage.setItem("fratello_jornadas_cerradas", JSON.stringify(jornadasCerradas));

      renderClientes();
      renderListaClientesCompleta();
      renderProduccion();
      renderPedidosCargados();
      calcularDiferencias();
      actualizarPanelMemoriaEnvio();
      actualizarTarjetaDiaPedidos();

      if (resultadoInterpretacion.huboCambios) {
        guardarInterpretacionFormularioEnNube();
      }

      const estado = $("estadoActualizacionManual");
      if (estado) {
        estado.textContent = "Actualizado " + new Date().toLocaleTimeString("es-AR", {
          hour: "2-digit",
          minute: "2-digit"
        });
      }

      setEstadoSync("Online actualizado");
    } catch (error) {
      console.error("Error procesando actualización en tiempo real:", error);
      setEstadoSync("Error al actualizar");
    } finally {
      cargandoDesdeNube = false;
    }
  }, (error) => {
    console.error("Error escuchando Firebase:", error);
    setEstadoSync("Error de sincronización");
  });
}

function guardarTodo() {
  localStorage.setItem("fratello_produccion", JSON.stringify(produccion));
  localStorage.setItem("fratello_pedidos", JSON.stringify(pedidos));
      localStorage.setItem("fratello_pedidos_eliminados", JSON.stringify(pedidosEliminados));
  localStorage.setItem("fratello_pedidos_fijos", JSON.stringify(pedidosFijos));
  localStorage.setItem("fratello_historial_pedidos", JSON.stringify(historialPedidos));
  localStorage.setItem("fratello_predeterminadas", JSON.stringify(predeterminadas));
  localStorage.setItem("fratello_clientes", JSON.stringify(clientes));
  localStorage.setItem("fratello_clientes_completos", JSON.stringify(datosClientesCompletos));
  localStorage.setItem("fratello_productos_extra", JSON.stringify(productosExtra));
  localStorage.setItem("fratello_pedidos_confirmados", JSON.stringify(pedidosConfirmados));
  localStorage.setItem("fratello_memoria_envio", JSON.stringify(memoriaUltimoEnvio));
      localStorage.setItem("fratello_jornadas_cerradas", JSON.stringify(jornadasCerradas));
  localStorage.setItem("fratello_exclusiones_pedidos_fijos", JSON.stringify(exclusionesPedidosFijos));
  guardarEnNube();
}


let produccion = JSON.parse(localStorage.getItem("fratello_produccion") || "{}");
let pedidos = JSON.parse(localStorage.getItem("fratello_pedidos") || "[]");
let pedidosEliminados = JSON.parse(localStorage.getItem("fratello_pedidos_eliminados") || "[]");
// Migración v5.2.2: descartar firmas semánticas antiguas de pedidos manuales.
pedidosEliminados = pedidosEliminados.filter(item => {
  const clave = String(item?.claveSemantica || "");
  if (!clave) return true;
  return clave.includes("|pedido_fijo|") || clave.includes("|fijo:");
});
localStorage.setItem("fratello_pedidos_eliminados", JSON.stringify(pedidosEliminados));

let pedidosFijos = JSON.parse(localStorage.getItem("fratello_pedidos_fijos") || "[]");
let historialPedidos = JSON.parse(localStorage.getItem("fratello_historial_pedidos") || "[]");
let predeterminadas = JSON.parse(localStorage.getItem("fratello_predeterminadas") || "null") || crearPredeterminadasIniciales();
let clientes = JSON.parse(localStorage.getItem("fratello_clientes") || "null") || [...clientesIniciales];
let datosClientesCompletos = JSON.parse(localStorage.getItem("fratello_clientes_completos") || "{}");
let listasPrecios = JSON.parse(localStorage.getItem("fratello_listas_precios") || "{}");
let productosExtra = JSON.parse(localStorage.getItem("fratello_productos_extra") || "[]");
productosExtra.forEach(p => { if (!productos.find(x => x.id === p.id)) productos.push(p); });

function formaVentaPredeterminada(unidad) {
  const u = String(unidad || "unidad").toLowerCase();
  if (u === "docena") return "unidad_docena";
  if (u === "kg") return "unidad_kg";
  return "solo_unidad";
}

productos.forEach(producto => {
  if (!producto.formaVenta) producto.formaVenta = formaVentaPredeterminada(producto.unidad);
  if (!Array.isArray(producto.sinonimos)) producto.sinonimos = [];
  if (!producto.precios || typeof producto.precios !== "object") producto.precios = {};
  ["unidad","docena","kg","paquete","bolsa","bandeja"].forEach(u => {
    producto.precios[u] = Number(producto.precios[u] || 0);
  });
});

function asegurarProductoCriollosCatalogo() {
  let criollos = productos.find(producto => producto.id === "CRIOLLOS");

  if (!criollos) {
    criollos = {
      id: "CRIOLLOS",
      nombre: "Criollos",
      unidad: "unidad",
      formaVenta: "solo_unidad",
      sinonimos: ["criollo"],
      precios: { unidad: 0, docena: 0, kg: 0, paquete: 0, bolsa: 0, bandeja: 0 },
      visible: true,
      activo: true,
      nuevo: false
    };
    productos.unshift(criollos);
  } else {
    criollos.nombre = "Criollos";
    criollos.sinonimos = [...new Set([...(criollos.sinonimos || []), "criollo"])];
    criollos.visible = true;
    criollos.activo = true;
  }

  const chicharron = productos.find(producto => producto.id === "CHIC");
  if (chicharron && Array.isArray(chicharron.sinonimos)) {
    chicharron.sinonimos = chicharron.sinonimos.filter(sinonimo =>
      !["criollo", "criollos"].includes(normalizarPedidoInteligente(sinonimo))
    );
  }

  try {
    localStorage.setItem("fratello_catalogo_productos", JSON.stringify(productos));
  } catch (error) {
    console.warn("No se pudo actualizar el catálogo local de Criollos:", error);
  }
}

const catalogoProductosGuardado = JSON.parse(localStorage.getItem("fratello_catalogo_productos") || "null");
if (Array.isArray(catalogoProductosGuardado) && catalogoProductosGuardado.length) {
  productos.splice(0, productos.length, ...catalogoProductosGuardado.map((p, indice) => ({
    id: String(p.id || `PRODUCTO_${indice + 1}`),
    nombre: String(p.nombre || "Producto"),
    unidad: String(p.unidad || "unidad"),
    formaVenta: String(p.formaVenta || formaVentaPredeterminada(p.unidad)),
    sinonimos: Array.isArray(p.sinonimos) ? p.sinonimos : [],
    precios: {
      unidad: Number(p.precios?.unidad || 0),
      docena: Number(p.precios?.docena || 0),
      kg: Number(p.precios?.kg || 0),
      paquete: Number(p.precios?.paquete || 0),
      bolsa: Number(p.precios?.bolsa || 0),
      bandeja: Number(p.precios?.bandeja || 0)
    },
    visible: p.visible !== false,
    activo: p.activo !== false,
    nuevo: Boolean(p.nuevo),
  })));
}
productos.forEach(producto => {
  dias.forEach(dia => {
    if (!predeterminadas[dia]) predeterminadas[dia] = {};
    if (predeterminadas[dia][producto.id] === undefined) predeterminadas[dia][producto.id] = 0;
  });
});
let correspondePedido = JSON.parse(localStorage.getItem("fratello_corresponde") || "{}");
let modoEdicionPredeterminada = false;
let pedidosConfirmados = JSON.parse(localStorage.getItem("fratello_pedidos_confirmados") || "false");
let memoriaUltimoEnvio = JSON.parse(localStorage.getItem("fratello_memoria_envio") || "null");
let jornadasCerradas = JSON.parse(localStorage.getItem("fratello_jornadas_cerradas") || "[]");
let exclusionesPedidosFijos = JSON.parse(localStorage.getItem("fratello_exclusiones_pedidos_fijos") || "[]");
let pedidosHoy = JSON.parse(localStorage.getItem("fratello_pedidos_hoy") || "[]");
let pedidoHoyEditandoId = null;
let produccionDesbloqueada = false;

const $ = (id) => document.getElementById(id);


asegurarProductoCriollosCatalogo();

function hoyISO() {
  return new Date().toISOString().slice(0, 10);
}

function normalizar(texto) {
  return String(texto).toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/\s+/g, " ").trim();
}

function productoPorId(id) {
  return productos.find(p => p.id === id);
}

function buscarProducto(lineaNormalizada) {
  for (const [palabra, id] of diccionario) {
    if (lineaNormalizada.includes(normalizar(palabra))) return id;
  }
  return null;
}

function extraerCantidad(lineaNormalizada) {
  const match = lineaNormalizada.match(/(\d+(?:[.,]\d+)?)/);
  if (!match) return 0;
  const n = Number(match[1].replace(",", "."));
  return Number.isFinite(n) ? n : 0;
}

function diaActual() {
  return $("diaProduccion").value || "lunes_jueves";
}

function nombreDiaActual() {
  const mapa = {
    lunes_jueves: "lunes a jueves",
    viernes: "viernes",
    sabado: "sábado",
    domingo: "domingo",
  };
  return mapa[diaActual()] || diaActual();
}

function claveProduccion(id) {
  return `${diaActual()}_${id}`;
}

function valorProduccion(id) {
  const key = claveProduccion(id);
  if (produccion[key] !== undefined) return produccion[key];
  return predeterminadas[diaActual()]?.[id] || 0;
}

function renderProduccion() {
  const visibles = productos.filter(p => p.visible && p.activo !== false);
  const dia = diaActual();

  let html = "<table><thead><tr><th>Producto</th><th>Cantidad</th><th>Unidad</th></tr></thead><tbody>";

  for (const p of visibles) {
    const valor = modoEdicionPredeterminada
      ? (predeterminadas[dia]?.[p.id] || "")
      : (valorProduccion(p.id) || "");

    const bloqueado = !produccionDesbloqueada ? "disabled" : "";
    html += `<tr>
      <td>${p.nombre}</td>
      <td><input type="number" step="0.001" data-prod="${p.id}" value="${valor}" placeholder="0" ${bloqueado}></td>
      <td>${p.unidad}</td>
    </tr>`;
  }

  html += "</tbody></table>";
  $("produccionLista").innerHTML = html;
  renderProduccionExtra();
  actualizarTextoModo();
}

function renderProduccionExtra() {
  const bloqueado = !produccionDesbloqueada ? "disabled" : "";
  let html = "<table><thead><tr><th>Producto extra</th><th>Cantidad</th><th>Unidad</th></tr></thead><tbody>";

  for (let i = 0; i < 6; i++) {
    html += `<tr>
      <td><input data-extra-nombre="${i}" placeholder="Ej: Pan hamburguesa" ${bloqueado}></td>
      <td><input data-extra-cantidad="${i}" type="number" step="0.001" placeholder="0" ${bloqueado}></td>
      <td>
        <select data-extra-unidad="${i}" ${bloqueado}>
          <option>unidad</option>
          <option>kg</option>
          <option>docena</option>
        </select>
      </td>
    </tr>`;
  }

  html += "</tbody></table>";
  $("produccionExtra").innerHTML = html;
}

function actualizarTextoModo() {
  $("modoProduccion").textContent = modoEdicionPredeterminada
    ? "Modo actual: cambiando la producción base"
    : (produccionDesbloqueada ? "Modo actual: producción desbloqueada" : "Modo actual: producción bloqueada");

  $("estadoBase").textContent = modoEdicionPredeterminada
    ? "editando base para " + nombreDiaActual()
    : "cargada automáticamente para " + nombreDiaActual();

  if ($("btnDesbloquearProduccion")) {
    $("btnDesbloquearProduccion").classList.toggle("hidden", produccionDesbloqueada);
    $("btnBloquearProduccion").classList.toggle("hidden", !produccionDesbloqueada);
    $("btnGuardarProduccion").disabled = !produccionDesbloqueada;
    $("btnEditarPredeterminada").disabled = !produccionDesbloqueada;
  }
}

function actualizarBloqueo() {
  renderProduccion();
}

function actualizarBloqueoProduccion() {
  renderProduccion();
}

function desbloquearProduccion() {
  const clave = window.prompt("Clave para desbloquear producción:");
  const claveLimpia = clave ? clave.trim().toLowerCase() : "";

  if (claveLimpia !== "fratello") {
    alert("Clave incorrecta.");
    return;
  }

  produccionDesbloqueada = true;
  renderProduccion();
}

function bloquearProduccion() {
  produccionDesbloqueada = false;
  if (modoEdicionPredeterminada) cancelarEdicionPredeterminada();
  renderProduccion();
}

function guardarProduccion() {
  if (!produccionDesbloqueada) {
    alert("Producción bloqueada. Primero desbloqueá.");
    return;
  }
  if (modoEdicionPredeterminada) {
    alert("Estás cambiando la producción base. Tocá Guardar nueva base o Cancelar.");
    return;
  }

  document.querySelectorAll("#produccionLista input").forEach(input => {
    produccion[claveProduccion(input.dataset.prod)] = Number(input.value || 0);
  });

  document.querySelectorAll("[data-extra-nombre]").forEach(input => {
    const i = input.dataset.extraNombre;
    const nombre = input.value.trim();
    const cantidad = Number(document.querySelector(`[data-extra-cantidad="${i}"]`).value || 0);
    const unidad = document.querySelector(`[data-extra-unidad="${i}"]`).value;

    if (!nombre || cantidad === 0) return;

    const normal = normalizar(nombre);
    const prodId = buscarProducto(normal) || `EXTRA_${normal.replace(/[^a-z0-9]/g, "_")}`;
    const productoExistente = productoPorId(prodId);

    if (!productoExistente && !productos.find(p => p.id === prodId)) {
      productos.push({ id: prodId, nombre, unidad, visible: false });
    }

    produccion[claveProduccion(prodId)] = cantidad;
  });

  guardarTodo();
  alert("Producción estibada/realizada guardada.");
  calcularDiferencias();
  actualizarEstadoConfirmacion();
}

function activarEdicionPredeterminada() {
  if (!produccionDesbloqueada) {
    const clave = window.prompt("Clave para editar la producción base:");
    const claveLimpia = clave ? clave.trim().toLowerCase() : "";

    if (claveLimpia !== "fratello") {
      alert("Clave incorrecta.");
      return;
    }

    produccionDesbloqueada = true;
  }

  modoEdicionPredeterminada = true;

  $("btnGuardarPredeterminada").classList.remove("hidden");
  $("btnCancelarPredeterminada").classList.remove("hidden");
  $("btnEditarPredeterminada").classList.add("hidden");

  renderProduccion();
}

function guardarPredeterminada() {
  const dia = diaActual();
  if (!predeterminadas[dia]) predeterminadas[dia] = {};

  document.querySelectorAll("#produccionLista input").forEach(input => {
    predeterminadas[dia][input.dataset.prod] = Number(input.value || 0);
  });

  guardarTodo();

  document.querySelectorAll("#produccionLista input").forEach(input => {
    produccion[claveProduccion(input.dataset.prod)] = Number(input.value || 0);
  });
  guardarTodo();

  modoEdicionPredeterminada = false;
  produccionDesbloqueada = false;
  $("btnGuardarPredeterminada").classList.add("hidden");
  $("btnCancelarPredeterminada").classList.add("hidden");
  $("btnEditarPredeterminada").classList.remove("hidden");

  alert("Producción base guardada para " + nombreDiaActual() + ".");
  renderProduccion();
  calcularDiferencias();
}

function cancelarEdicionPredeterminada() {
  modoEdicionPredeterminada = false;
  produccionDesbloqueada = false;

  $("btnGuardarPredeterminada").classList.add("hidden");
  $("btnCancelarPredeterminada").classList.add("hidden");
  $("btnEditarPredeterminada").classList.remove("hidden");

  renderProduccion();
}



function escaparHtmlCatalogo(valor) {
  return String(valor ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;")
    .replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
}
function crearIdProductoCatalogo(nombre) {
  const base = normalizar(nombre).replace(/[^a-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "").toUpperCase() || "PRODUCTO";
  let id = base;
  let numero = 2;
  while (productos.some(p => p.id === id)) id = `${base}_${numero++}`;
  return id;
}
function guardarCatalogoProductos() {
  localStorage.setItem("fratello_catalogo_productos", JSON.stringify(productos));
  localStorage.setItem("fratello_predeterminadas", JSON.stringify(predeterminadas));
  localStorage.setItem("fratello_productos_extra", JSON.stringify(productosExtra));
  guardarEnNube();
}
function productoEstaEnProduccionPredeterminada(productoId) {
  return dias.some(dia => Number(predeterminadas?.[dia]?.[productoId] || 0) > 0);
}

function resumenProduccionPredeterminadaProducto(productoId) {
  const etiquetas = {
    lunes_jueves: "Lun–Jue",
    viernes: "Vie",
    sabado: "Sáb",
    domingo: "Dom"
  };

  const partes = dias
    .map(dia => {
      const cantidad = Number(predeterminadas?.[dia]?.[productoId] || 0);
      return cantidad > 0 ? `${etiquetas[dia]}: ${fmt(cantidad)}` : "";
    })
    .filter(Boolean);

  return partes.length ? partes.join(" · ") : "No agregado a la producción predeterminada";
}

function renderAdministradorProductos() {
  const contenedor = $("listaAdministradorProductos");
  if (!contenedor) return;

  contenedor.innerHTML = productos.map(producto => {
    const visible = producto.visible !== false;
    const activo = producto.activo !== false;
    const enPredeterminada = productoEstaEnProduccionPredeterminada(producto.id);

    return `<details class="catalogProductAccordion ${enPredeterminada ? "inDefaultProduction" : ""}" data-catalog-id="${escaparHtmlCatalogo(producto.id)}">
      <summary>
        <div>
          <strong>${escaparHtmlCatalogo(producto.nombre)}</strong>
          <span>${escaparHtmlCatalogo(resumenProduccionPredeterminadaProducto(producto.id))}</span>
        </div>
        <div class="catalogSummaryBadges">
          <span>${escaparHtmlCatalogo(producto.unidad || "unidad")}</span>
          ${enPredeterminada ? '<b>✓ Producción base</b>' : '<b class="pendingDefault">Sólo por encargo</b>'}
        </div>
      </summary>

      <div class="catalogProductRow">
        <div class="catalogProductFields">
          <label>Nombre
            <input type="text" data-catalog-nombre value="${escaparHtmlCatalogo(producto.nombre)}">
          </label>

          <label>Unidad principal
            <select data-catalog-unidad>
              ${["unidad","kg","docena","bandeja","bolsa"].map(unidad =>
                `<option value="${unidad}" ${producto.unidad === unidad ? "selected" : ""}>${unidad}</option>`
              ).join("")}
            </select>
          </label>

          <label>Forma de venta
            <select data-catalog-forma-venta title="Cómo interpretar números sin unidad">
              ${[
                ["solo_unidad","Sólo unidad"],
                ["solo_docena","Sólo docena"],
                ["solo_kg","Sólo kg"],
                ["unidad_docena","Unidad y docena"],
                ["unidad_kg","Unidad y kg"],
                ["kg_paquete","Kg y paquete"],
                ["revisar_siempre","Revisar siempre"]
              ].map(([valor, etiqueta]) =>
                `<option value="${valor}" ${(producto.formaVenta || formaVentaPredeterminada(producto.unidad)) === valor ? "selected" : ""}>${etiqueta}</option>`
              ).join("")}
            </select>
          </label>

          <label class="catalogSynonymsLabel">Sinónimos
            <textarea data-catalog-sinonimos rows="2" placeholder="Separados por coma">${escaparHtmlCatalogo((producto.sinonimos || []).join(", "))}</textarea>
          </label>

          <label class="catalogCheck"><input type="checkbox" data-catalog-visible ${visible ? "checked" : ""}> Mostrar en producción</label>
          <label class="catalogCheck"><input type="checkbox" data-catalog-activo ${activo ? "checked" : ""}> Producto activo</label>
        </div>

        <div class="catalogPriceFields">
          <label>Precio unidad<input type="number" min="0" step="0.01" data-precio-unidad value="${Number(producto.precios?.unidad || 0)}"></label>
          <label>Precio docena<input type="number" min="0" step="0.01" data-precio-docena value="${Number(producto.precios?.docena || 0)}"></label>
          <label>Precio kg<input type="number" min="0" step="0.01" data-precio-kg value="${Number(producto.precios?.kg || 0)}"></label>
          <label>Precio paquete<input type="number" min="0" step="0.01" data-precio-paquete value="${Number(producto.precios?.paquete || 0)}"></label>
        </div>

        <div class="catalogProductActions">
          <button type="button" class="primary addDefaultProductionBtn" data-catalog-predeterminada="${escaparHtmlCatalogo(producto.id)}">
            ➕ Agregar artículo a producción predeterminada
          </button>
          <button type="button" data-catalog-guardar="${escaparHtmlCatalogo(producto.id)}">💾 Guardar edición</button>
          <button type="button" class="dangerBtn" data-catalog-eliminar="${escaparHtmlCatalogo(producto.id)}">🗑 Eliminar</button>
        </div>
      </div>
    </details>`;
  }).join("");
}

function agregarProductoCatalogo() {
  const nombre = $("nuevoProductoNombre")?.value.trim();
  const unidad = $("nuevoProductoUnidad")?.value || "unidad";
  const formaVenta = $("nuevoProductoFormaVenta")?.value || formaVentaPredeterminada(unidad);
  const sinonimos = [];
  if (!nombre) return alert("Escribí el nombre del producto.");
  if (productos.some(p => normalizar(p.nombre) === normalizar(nombre))) {
    return alert("Ya existe un producto con ese nombre.");
  }
  const nuevo = {
    id: crearIdProductoCatalogo(nombre),
    nombre,
    unidad,
    formaVenta,
    sinonimos,
    precios: { unidad: 0, docena: 0, kg: 0, paquete: 0, bolsa: 0, bandeja: 0 },
    visible: true,
    activo: true,
    nuevo: true
  };
  productos.push(nuevo);
  productosExtra.push(nuevo);
  dias.forEach(dia => {
    if (!predeterminadas[dia]) predeterminadas[dia] = {};
    predeterminadas[dia][nuevo.id] = 0;
  });
  guardarCatalogoProductos();
  $("nuevoProductoNombre").value = "";
  renderAdministradorProductos();
  renderProduccion();
  alert(`Producto "${nombre}" agregado. Abrí su pestaña y tocá “Agregar artículo a producción predeterminada” para definir las cantidades habituales.`);
}
function guardarProductoCatalogo(id) {
  const fila = document.querySelector(`[data-catalog-id="${CSS.escape(id)}"]`);
  const producto = productos.find(p => p.id === id);
  if (!fila || !producto) return;
  const nombre = fila.querySelector("[data-catalog-nombre]").value.trim();
  if (!nombre) return alert("El nombre no puede quedar vacío.");
  if (productos.some(p => p.id !== id && normalizar(p.nombre) === normalizar(nombre))) {
    return alert("Ya existe otro producto con ese nombre.");
  }
  producto.nombre = nombre;
  producto.unidad = fila.querySelector("[data-catalog-unidad]").value;
  producto.formaVenta = fila.querySelector("[data-catalog-forma-venta]").value;
  producto.sinonimos = fila.querySelector("[data-catalog-sinonimos]").value
    .split(",")
    .map(s => s.trim())
    .filter(Boolean);
  producto.precios = {
    ...(producto.precios || {}),
    unidad: Number(fila.querySelector("[data-precio-unidad]")?.value || 0),
    docena: Number(fila.querySelector("[data-precio-docena]")?.value || 0),
    kg: Number(fila.querySelector("[data-precio-kg]")?.value || 0),
    paquete: Number(fila.querySelector("[data-precio-paquete]")?.value || 0)
  };
  producto.visible = fila.querySelector("[data-catalog-visible]").checked;
  producto.activo = fila.querySelector("[data-catalog-activo]").checked;
  const extra = productosExtra.find(p => p.id === id);
  if (extra) Object.assign(extra, producto);
  guardarCatalogoProductos();
  renderAdministradorProductos();
  renderProduccion();
  calcularDiferencias();
  alert(`Producto "${nombre}" actualizado.`);
}
function agregarProductoAPredeterminada(id) {
  const producto = productos.find(p => p.id === id);
  if (!producto) return;

  const etiquetas = {
    lunes_jueves: "Lunes a jueves",
    viernes: "Viernes",
    sabado: "Sábado",
    domingo: "Domingo"
  };

  const nuevosValores = {};

  for (const dia of dias) {
    const actual = Number(predeterminadas?.[dia]?.[id] || 0);
    const respuesta = prompt(
      `${producto.nombre}\n\nCantidad habitual para ${etiquetas[dia]}:\nIngresá 0 si no se produce ese día.`,
      String(actual)
    );

    if (respuesta === null) return;

    const cantidad = Number(String(respuesta).replace(",", "."));
    if (Number.isNaN(cantidad) || cantidad < 0) {
      alert("Ingresá una cantidad válida, igual o mayor que 0.");
      return;
    }

    nuevosValores[dia] = cantidad;
  }

  dias.forEach(dia => {
    if (!predeterminadas[dia]) predeterminadas[dia] = {};
    predeterminadas[dia][id] = nuevosValores[dia];
  });

  producto.visible = true;
  producto.activo = true;

  const extra = productosExtra.find(p => p.id === id);
  if (extra) Object.assign(extra, producto);

  guardarTodo();
  renderAdministradorProductos();
  renderProduccion();
  calcularDiferencias();

  const tieneCantidad = Object.values(nuevosValores).some(valor => Number(valor) > 0);

  alert(
    tieneCantidad
      ? `"${producto.nombre}" fue agregado a la producción predeterminada.`
      : `"${producto.nombre}" quedó disponible, pero todas las cantidades están en 0.`
  );
}

function eliminarProductoCatalogo(id) {
  const producto = productos.find(p => p.id === id);
  if (!producto) return;
  if (!confirm(`¿Eliminar "${producto.nombre}" de la producción predeterminada?\n\nLos pedidos históricos no se borrarán.`)) return;
  productos.splice(productos.findIndex(p => p.id === id), 1);
  productosExtra = productosExtra.filter(p => p.id !== id);
  dias.forEach(dia => {
    if (predeterminadas[dia]) delete predeterminadas[dia][id];
    delete produccion[`${dia}_${id}`];
  });
  guardarTodo();
  renderAdministradorProductos();
  renderProduccion();
  calcularDiferencias();
  alert(`Producto "${producto.nombre}" eliminado.`);
}
function manejarClicksAdministradorProductos(evento) {
  const predeterminada = evento.target.closest("[data-catalog-predeterminada]");
  if (predeterminada) {
    return agregarProductoAPredeterminada(predeterminada.dataset.catalogPredeterminada);
  }

  const guardar = evento.target.closest("[data-catalog-guardar]");
  if (guardar) return guardarProductoCatalogo(guardar.dataset.catalogGuardar);

  const eliminar = evento.target.closest("[data-catalog-eliminar]");
  if (eliminar) eliminarProductoCatalogo(eliminar.dataset.catalogEliminar);
}


function normalizarPedidoInteligente(texto) {
  let t = String(texto || "").toLowerCase();

  t = t
    .replace(/(\d)\s*k\b/g, "$1 kg")
    .replace(/(\d)\s*kg\b/g, "$1 kg")
    .replace(/(\d)\s*gr\b/g, "$1 gramos")
    .replace(/(\d)\s*g\b/g, "$1 gramos")
    .replace(/\bc\s*\/\s*/g, " con ")
    .replace(/\bs\s*\/\s*/g, " sin ")
    .replace(/\bdd l\b/g, " dulce de leche ")
    .replace(/\bddl\b/g, " dulce de leche ")
    .replace(/\bdulces\b/g, " dulce ")
    .replace(/\bdoc\b/g, " docena ")
    .replace(/\bdocs\b/g, " docenas ")
    .replace(/\bunid\b/g, " unidad ")
    .replace(/\bu\b/g, " unidad ")
    .replace(/[.,;:()[\]{}]/g, " ")
    .replace(/\s+/g, " ")
    .trim();

  return t;
}

function singularizarPalabra(palabra) {
  const p = String(palabra || "");
  if (p.length <= 3) return p;
  if (p.endsWith("ces")) return p.slice(0, -3) + "z";
  if (p.endsWith("es") && p.length > 5) return p.slice(0, -2);
  if (p.endsWith("s") && p.length > 4) return p.slice(0, -1);
  return p;
}

function tokensProducto(texto) {
  const ignorar = new Set([
    "de","del","la","las","el","los","con","sin","para","por","y",
    "kg","kilo","kilos","gramo","gramos","docena","docenas",
    "unidad","unidades","paquete","paquetes","bolsa","bolsas",
    "bandeja","bandejas"
  ]);

  return normalizarPedidoInteligente(texto)
    .split(/\s+/)
    .map(singularizarPalabra)
    .filter(token => token && !ignorar.has(token) && !/^\d+(?:[.,]\d+)?$/.test(token));
}

function similitudTokens(a, b) {
  const aa = new Set(tokensProducto(a));
  const bb = new Set(tokensProducto(b));

  if (!aa.size || !bb.size) return 0;

  let inter = 0;
  aa.forEach(token => {
    if (bb.has(token)) inter += 1;
  });

  const precision = inter / aa.size;
  const cobertura = inter / bb.size;
  return (precision * 0.55) + (cobertura * 0.45);
}

function variantesProducto(producto) {
  const variantes = [producto.nombre];
  if (Array.isArray(producto.sinonimos)) variantes.push(...producto.sinonimos);
  return variantes.filter(Boolean);
}

function puntuarProductoTexto(textoLinea, producto) {
  const textoNormalizado = normalizarPedidoInteligente(textoLinea);
  let mejor = 0;
  let varianteGanadora = producto.nombre;

  for (const variante of variantesProducto(producto)) {
    const varianteNormalizada = normalizarPedidoInteligente(variante);
    let puntaje = similitudTokens(textoNormalizado, varianteNormalizada);

    const tokensVariante = tokensProducto(varianteNormalizada);
    const tokensTexto = new Set(tokensProducto(textoNormalizado));
    const todosPresentes = tokensVariante.length > 0 && tokensVariante.every(t => tokensTexto.has(t));

    if (todosPresentes) {
      // Una coincidencia específica de varias palabras gana frente a una genérica.
      const bonoEspecificidad = Math.min(0.09, Math.max(0, tokensVariante.length - 1) * 0.035);
      puntaje = Math.max(puntaje, 0.91 + bonoEspecificidad);
    }

    if (textoNormalizado === varianteNormalizada) {
      puntaje = 1;
    }

    if (puntaje > mejor) {
      mejor = puntaje;
      varianteGanadora = variante;
    }
  }

  return { producto, puntaje: mejor, variante: varianteGanadora };
}

function buscarCoincidenciasProducto(textoLinea) {
  return productos
    .filter(p => p.activo !== false)
    .map(p => puntuarProductoTexto(textoLinea, p))
    .sort((a, b) => b.puntaje - a.puntaje);
}

function resolverProductoInteligente(textoLinea) {
  const textoProducto = extraerCantidadYUnidadInteligente(textoLinea).textoLimpio;
  const exacto = buscarProductoExactoPedido(textoProducto);

  if (exacto) {
    return {
      producto: exacto,
      confianza: 1,
      revisar: false,
      sugerencias: [{ producto: exacto, id: exacto.id, nombre: exacto.nombre, puntaje: 1 }]
    };
  }

  const coincidencias = buscarCoincidenciasProducto(textoLinea);
  const mejor = coincidencias[0];
  const segundo = coincidencias[1];

  if (!mejor || mejor.puntaje < 0.48) {
    return {
      producto: null,
      confianza: mejor?.puntaje || 0,
      revisar: true,
      sugerencias: coincidencias.slice(0, 3)
    };
  }

  const diferencia = mejor.puntaje - (segundo?.puntaje || 0);
  const revisar = mejor.puntaje < 0.72 || diferencia < 0.10;

  return {
    producto: mejor.producto,
    confianza: mejor.puntaje,
    revisar,
    sugerencias: coincidencias.slice(0, 3)
  };
}

function extraerCantidadYUnidadInteligente(original) {
  const texto = normalizarPedidoInteligente(original);
  const match = texto.match(/(\d+(?:[.,]\d+)?)\s*(kg|kilo|kilos|gramos|gramo|docena|docenas|unidad|unidades|paquete|paquetes|bolsa|bolsas|bandeja|bandejas)?/);

  if (!match) {
    return { cantidad: 0, unidadExplicita: "", textoLimpio: texto };
  }

  let cantidad = Number(match[1].replace(",", "."));
  let unidadExplicita = match[2] || "";

  if (unidadExplicita === "gramo" || unidadExplicita === "gramos") {
    cantidad = cantidad / 1000;
    unidadExplicita = "kg";
  } else if (unidadExplicita === "kilo" || unidadExplicita === "kilos") {
    unidadExplicita = "kg";
  } else if (unidadExplicita === "docenas") {
    unidadExplicita = "docena";
  } else if (unidadExplicita === "unidades") {
    unidadExplicita = "unidad";
  } else if (unidadExplicita === "paquetes") {
    unidadExplicita = "paquete";
  } else if (unidadExplicita === "bolsas") {
    unidadExplicita = "bolsa";
  } else if (unidadExplicita === "bandejas") {
    unidadExplicita = "bandeja";
  }

  const textoLimpio = texto.replace(match[0], " ").replace(/\s+/g, " ").trim();
  return { cantidad, unidadExplicita, textoLimpio };
}

function detectarUnidadExplicita(texto) {
  const t = ` ${normalizar(texto)} `;
  if (/\b(kg|kilo|kilos)\b/.test(t)) return "kg";
  if (/\b(doc|docena|docenas)\b/.test(t)) return "docena";
  if (/\b(unid|unidad|unidades|u)\b/.test(t)) return "unidad";
  if (/\b(paquete|paquetes|paq)\b/.test(t)) return "paquete";
  if (/\b(bolsa|bolsas)\b/.test(t)) return "bolsa";
  if (/\b(bandeja|bandejas)\b/.test(t)) return "bandeja";
  return "";
}

function detectarUnidad(texto, unidadDefault = "unidad") {
  return detectarUnidadExplicita(texto) || unidadDefault || "unidad";
}

function opcionesUnidadPorFormaVenta(formaVenta, unidadProducto) {
  switch (formaVenta) {
    case "solo_docena": return ["docena"];
    case "solo_kg": return ["kg"];
    case "unidad_docena": return ["unidad", "docena"];
    case "unidad_kg": return ["unidad", "kg"];
    case "kg_paquete": return ["kg", "paquete"];
    case "revisar_siempre":
      return [...new Set(["unidad", unidadProducto || "unidad"])];
    case "solo_unidad":
    default:
      return ["unidad"];
  }
}

function interpretarUnidadProducto(original, producto) {
  const explicita = detectarUnidadExplicita(original);
  if (explicita) {
    return {
      unidad: explicita,
      ambiguo: false,
      opciones: [explicita],
      razon: ""
    };
  }

  const formaVenta = producto.formaVenta || formaVentaPredeterminada(producto.unidad);
  const opciones = opcionesUnidadPorFormaVenta(formaVenta, producto.unidad);

  if (opciones.length === 1 && formaVenta !== "revisar_siempre") {
    return {
      unidad: opciones[0],
      ambiguo: false,
      opciones,
      razon: ""
    };
  }

  return {
    unidad: producto.unidad || opciones[0] || "unidad",
    ambiguo: true,
    opciones,
    razon: "El cliente escribió una cantidad sin aclarar la unidad."
  };
}

function nombreProductoDesdeLinea(original) {
  return original
    .replace(/\d+([.,]\d+)?/g, "")
    .replace(/\bkg\b/gi, "")
    .replace(/\bkilos?\b/gi, "")
    .replace(/\bunidad(es)?\b/gi, "")
    .replace(/\bunid\b/gi, "")
    .replace(/\bu\b/gi, "")
    .replace(/\bdoc(ena|enas)?\b/gi, "")
    .replace(/\s+/g, " ")
    .trim();
}

function crearProductoExtra(nombre, unidad) {
  const id = "EXTRA_" + normalizar(nombre).replace(/[^a-z0-9]/g, "_").replace(/_+/g, "_").replace(/^_|_$/g, "").toUpperCase();
  let existente = productos.find(p => p.id === id || normalizar(p.nombre.replace("*","")) === normalizar(nombre));
  if (existente) return existente;

  const nuevo = {
    id,
    nombre: nombre + " *",
    unidad,
    formaVenta: formaVentaPredeterminada(unidad),
    sinonimos: [],
    precios: { unidad: 0, docena: 0, kg: 0, paquete: 0, bolsa: 0, bandeja: 0 },
    visible: false,
    activo: false,
    nuevo: true
  };
  productos.push(nuevo);
  productosExtra.push(nuevo);

  if (typeof dias !== "undefined") {
    dias.forEach(d => {
      if (!predeterminadas[d]) predeterminadas[d] = {};
      if (predeterminadas[d][id] === undefined) predeterminadas[d][id] = 0;
    });
  }

  guardarTodo();
  return nuevo;
}

function esProductoGenericoPan(lineaNormalizada, prodId) {
  return prodId === "PAN" && lineaNormalizada !== "pan";
}

function normalizarNombreProductoPedido(texto) {
  const palabrasIgnoradas = new Set(["de", "del", "la", "las", "el", "los", "con"]);

  return normalizarPedidoInteligente(texto)
    .split(/\s+/)
    .filter(Boolean)
    .filter(palabra => !palabrasIgnoradas.has(palabra))
    .map(palabra => singularizarPalabra(palabra))
    .join(" ")
    .trim();
}

function variantesNormalizadasProducto(producto) {
  return [producto.nombre, ...(producto.sinonimos || [])]
    .map(variante => normalizarNombreProductoPedido(String(variante || "").replace("*", "")))
    .filter(Boolean);
}

function buscarProductoExactoPedido(textoProducto) {
  const buscado = normalizarNombreProductoPedido(textoProducto);
  if (!buscado) return null;

  const exactos = productos.filter(producto =>
    variantesNormalizadasProducto(producto).includes(buscado)
  );

  if (exactos.length === 1) return exactos[0];

  // Segunda pasada: permite variantes como "bizcocho de grasa" /
  // "bizcochos de grasa", sin confundir productos distintos.
  const contenidos = productos
    .map(producto => ({
      producto,
      variantes: variantesNormalizadasProducto(producto)
    }))
    .filter(item =>
      item.variantes.some(variante =>
        variante === buscado ||
        (variante.length >= 5 && buscado.length >= 5 &&
          (variante.includes(buscado) || buscado.includes(variante)))
      )
    )
    .sort((a, b) => {
      const mejorA = Math.max(...a.variantes.map(v => Math.min(v.length, buscado.length)));
      const mejorB = Math.max(...b.variantes.map(v => Math.min(v.length, buscado.length)));
      return mejorB - mejorA;
    });

  return contenidos.length === 1 ? contenidos[0].producto : null;
}

function dividirPedidoEnLineas(texto) {
  return String(texto || "")
    .replace(/\r/g, "")
    .split(/\n|;|\|/)
    .map(linea => linea.trim())
    .filter(Boolean);
}

function extraerDatosLineaPedido(original) {
  // IMPORTANTE: acá no usamos normalizarPedidoInteligente porque esa función
  // elimina comas y puntos. Eso convertía 0,5 en "0 5" y el pedido quedaba en 0.
  const textoOriginal = String(original || "").trim();
  const textoBusqueda = textoOriginal
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");

  const coincidencia = textoBusqueda.match(
    /(\d+(?:[.,]\d+)?)\s*(kg|kilo|kilos|g|gr|gramo|gramos|doc|docena|docenas|unid|unidad|unidades|u|paquete|paquetes|bolsa|bolsas|bandeja|bandejas)?\b/i
  );

  if (!coincidencia) {
    return {
      cantidad: 0,
      unidad: "",
      productoTexto: normalizarPedidoInteligente(textoOriginal),
      tieneCantidad: false
    };
  }

  let cantidad = Number(String(coincidencia[1]).replace(",", "."));
  let unidad = String(coincidencia[2] || "").toLowerCase();

  if (["g", "gr", "gramo", "gramos"].includes(unidad)) {
    cantidad = cantidad / 1000;
    unidad = "kg";
  } else if (["kilo", "kilos"].includes(unidad)) {
    unidad = "kg";
  } else if (["doc", "docenas"].includes(unidad)) {
    unidad = "docena";
  } else if (["unid", "u", "unidades"].includes(unidad)) {
    unidad = "unidad";
  } else if (unidad === "paquetes") {
    unidad = "paquete";
  } else if (unidad === "bolsas") {
    unidad = "bolsa";
  } else if (unidad === "bandejas") {
    unidad = "bandeja";
  }

  const inicio = coincidencia.index || 0;
  const fin = inicio + coincidencia[0].length;

  const productoTexto = normalizarPedidoInteligente(
    textoOriginal.slice(0, inicio) + " " + textoOriginal.slice(fin)
  );

  return {
    cantidad,
    unidad,
    productoTexto,
    tieneCantidad: Number.isFinite(cantidad) && cantidad > 0
  };
}


function procesarLineaPedidoRobusta(original, cliente, fecha) {
  const normal = normalizarPedidoInteligente(original);

  if (!normal || normal.match(/^\s*pedido\b/) || normal.match(/\d{1,2}\/\d{1,2}\/\d{2,4}/)) {
    return null;
  }

  const lectura = extraerDatosLineaPedido(original);
  if (!lectura.tieneCantidad || lectura.cantidad <= 0) return null;

  const nombreProductoNormalizado = normalizarNombreProductoPedido(lectura.productoTexto);
  let producto = ["criollo", "criollos"].includes(nombreProductoNormalizado)
    ? productoPorId("CRIOLLOS")
    : buscarProductoExactoPedido(lectura.productoTexto);

  // Defensa ante catálogos antiguos recibidos desde Firebase.
  if (["criollo", "criollos"].includes(nombreProductoNormalizado) && !producto) {
    asegurarProductoCriollosCatalogo();
    producto = productoPorId("CRIOLLOS");
  }

  let reconocimiento = {
    producto,
    confianza: producto ? 1 : 0,
    revisar: false,
    sugerencias: []
  };

  if (!producto) {
    reconocimiento = resolverProductoInteligente(lectura.productoTexto);
    producto = reconocimiento.producto;
  }

  let productoNoReconocido = false;

  if (!producto) {
    const nombreNuevo = lectura.productoTexto || nombreProductoDesdeLinea(original);
    producto = crearProductoExtra(
      nombreNuevo,
      lectura.unidad || detectarUnidad(original, "unidad")
    );
    productoNoReconocido = true;
  }

  const unidadInterpretada = lectura.unidad || producto.unidad || "unidad";
  const unidadAmbigua = !lectura.unidad &&
    opcionesUnidadPorFormaVenta(
      producto.formaVenta || formaVentaPredeterminada(producto.unidad),
      producto.unidad
    ).length > 1;

  const estado = productoNoReconocido || reconocimiento.revisar
    ? "REVISAR PRODUCTO"
    : (unidadAmbigua ? "REVISAR UNIDAD" : "OK");

  return {
    itemId: `${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    fecha,
    cliente,
    productoId: producto.id,
    producto: producto.nombre,
    cantidad: lectura.cantidad,
    unidad: unidadInterpretada,
    unidadAmbigua,
    opcionesUnidad: unidadAmbigua
      ? opcionesUnidadPorFormaVenta(
          producto.formaVenta || formaVentaPredeterminada(producto.unidad),
          producto.unidad
        )
      : [unidadInterpretada],
    productoAmbiguo: productoNoReconocido || reconocimiento.revisar,
    confianzaProducto: productoNoReconocido ? 0 : reconocimiento.confianza,
    sugerenciasProducto: (reconocimiento.sugerencias || []).map(s => ({
      id: s.producto.id,
      nombre: s.producto.nombre,
      puntaje: s.puntaje
    })),
    estado,
    observacion: productoNoReconocido
      ? "Producto no reconocido."
      : (reconocimiento.revisar
          ? "Revisar coincidencia del producto."
          : (unidadAmbigua ? "Falta confirmar la unidad." : "")),
    original
  };
}

function procesarTextoPedido(texto, cliente, fecha) {
  return dividirPedidoEnLineas(texto)
    .map(linea => procesarLineaPedidoRobusta(linea, cliente, fecha))
    .filter(Boolean);
}

function procesarTextoPedidoLineas(texto, cliente, fecha) {
  return procesarTextoPedido(texto, cliente, fecha);
}


function pedidosConProductoAmbiguo() {
  const fechaActual = $("fechaPedido")?.value || hoyISO();
  return pedidos
    .filter(pedido => fechaEntregaPedido(pedido) === fechaActual)
    .flatMap(pedido =>
      (pedido.items || [])
        .filter(item => item.productoAmbiguo || item.estado === "REVISAR PRODUCTO")
        .map(item => ({ pedido, item }))
    );
}

function resolverProductoPedido(pedidoId, itemId, productoId) {
  const pedido = pedidos.find(p => Number(p.id) === Number(pedidoId));
  if (!pedido) return;

  const item = (pedido.items || []).find(i => String(i.itemId) === String(itemId));
  const producto = productoPorId(productoId);
  if (!item || !producto) return;

  const textoOriginal = item.original || "";
  const alias = normalizarPedidoInteligente(
    extraerCantidadYUnidadInteligente(textoOriginal).textoLimpio
  );

  item.productoId = producto.id;
  item.producto = producto.nombre;
  item.productoNombreManual = producto.nombre;
  item.productoCorregidoManualmente = true;
  item.productoAmbiguo = false;
  item.confianzaProducto = 1;
  item.sugerenciasProducto = [];
  item.estado = item.unidadAmbigua ? "REVISAR UNIDAD" : "OK";
  item.observacion = item.unidadAmbigua
    ? "Producto confirmado. Falta confirmar la unidad."
    : "Producto confirmado manualmente.";

  if (alias && !variantesProducto(producto).some(v => normalizarPedidoInteligente(v) === alias)) {
    producto.sinonimos = Array.isArray(producto.sinonimos) ? producto.sinonimos : [];
    producto.sinonimos.push(alias);

    const extra = productosExtra.find(p => p.id === producto.id);
    if (extra) extra.sinonimos = [...producto.sinonimos];

    guardarCatalogoProductos();
  }

  pedido.actualizado = new Date().toISOString();
  pedido.tieneCorreccionManualProducto = true;
  pedidosConfirmados = false;
  guardarTodo();
  renderPedidosCargados();
  renderUltimoProcesado();
  calcularDiferencias();
  actualizarAvisoUnidadesAmbiguas();
  actualizarEstadoConfirmacion();
}

function botonesResolverProducto(pedidoId, item) {
  if (!(item.productoAmbiguo || item.estado === "REVISAR PRODUCTO")) return "";

  const sugerencias = Array.isArray(item.sugerenciasProducto)
    ? item.sugerenciasProducto.filter(s => s && s.id)
    : [];

  if (!sugerencias.length) {
    return `<div class="productResolution">
      <span>⚠️ Producto no reconocido. Revisalo en el administrador.</span>
    </div>`;
  }

  return `<div class="productResolution">
    <span>⚠️ ¿Qué producto es?</span>
    ${sugerencias.slice(0, 3).map(s =>
      `<button type="button" onclick="resolverProductoPedido(${pedidoId}, '${item.itemId}', '${s.id}')">
        ${s.nombre} ${s.puntaje ? `(${Math.round(s.puntaje * 100)}%)` : ""}
      </button>`
    ).join("")}
  </div>`;
}

function pedidosConUnidadAmbigua() {
  const fechaActual = $("fechaPedido")?.value || hoyISO();
  return pedidos
    .filter(pedido => fechaEntregaPedido(pedido) === fechaActual)
    .flatMap(pedido =>
      (pedido.items || [])
        .filter(item => item.unidadAmbigua || item.estado === "REVISAR UNIDAD")
        .map(item => ({ pedido, item }))
    );
}

function actualizarAvisoUnidadesAmbiguas() {
  const aviso = $("avisoUnidadesAmbiguas");
  const check = $("checkPedidoCompleto");
  if (!aviso) return;

  const ambiguosUnidad = pedidosConUnidadAmbigua();
  const ambiguosProducto = pedidosConProductoAmbiguo();
  const totalAmbiguos = ambiguosUnidad.length + ambiguosProducto.length;

  if (!totalAmbiguos) {
    aviso.classList.add("hidden");
    aviso.innerHTML = "";
    if (check) check.disabled = false;
    return;
  }

  aviso.classList.remove("hidden");
  const partes = [];
  if (ambiguosProducto.length) partes.push(`${ambiguosProducto.length} producto(s) sin reconocer`);
  if (ambiguosUnidad.length) partes.push(`${ambiguosUnidad.length} unidad(es) sin confirmar`);
  aviso.innerHTML = `⚠️ Hay <strong>${totalAmbiguos}</strong> revisión(es) pendiente(s): ${partes.join(" y ")}.`;
  if (check) {
    check.checked = false;
    check.disabled = true;
  }
}

function resolverUnidadPedido(pedidoId, itemId, unidad) {
  const pedido = pedidos.find(p => Number(p.id) === Number(pedidoId));
  if (!pedido) return;

  const item = (pedido.items || []).find(i => String(i.itemId) === String(itemId));
  if (!item) return;

  item.unidad = unidad;
  item.unidadAmbigua = false;
  item.estado = "OK";
  item.observacion = `Unidad confirmada manualmente: ${unidad}`;

  pedidosConfirmados = false;
  guardarTodo();
  renderPedidosCargados();
  renderUltimoProcesado();
  calcularDiferencias();
  actualizarAvisoUnidadesAmbiguas();
  actualizarEstadoConfirmacion();
}

function botonesResolverUnidad(pedidoId, item) {
  if (!(item.unidadAmbigua || item.estado === "REVISAR UNIDAD")) return "";

  const opciones = Array.isArray(item.opcionesUnidad) && item.opcionesUnidad.length
    ? item.opcionesUnidad
    : ["unidad", item.unidad || "unidad"];

  return `<div class="unitResolution">
    <span>⚠️ Elegir unidad:</span>
    ${[...new Set(opciones)].map(unidad =>
      `<button type="button" onclick="resolverUnidadPedido(${pedidoId}, '${item.itemId}', '${unidad}')">${fmt(item.cantidad)} ${unidad}</button>`
    ).join("")}
  </div>`;
}

function mostrarMensajePedido(texto) {
  let aviso = $("mensajePedido");
  if (!aviso) {
    aviso = document.createElement("div");
    aviso.id = "mensajePedido";
    aviso.className = "mensajePedido";
    const btn = $("btnProcesar");
    btn.parentNode.insertBefore(aviso, btn.nextSibling);
  }

  aviso.textContent = texto;
  aviso.style.display = "block";

  setTimeout(() => {
    aviso.style.display = "none";
  }, 2500);
}

function validarClientes() {
  if (!Array.isArray(clientes) || clientes.length === 0) {
    clientes = [...clientesIniciales];
  }

  clientes = clientes
    .filter(c => c && String(c).trim())
    .map(c => String(c).trim());

  if (clientes.length === 0) {
    clientes = [...clientesIniciales];
  }
}


function guardarClientes() {
  guardarTodo();
}

function renderClientes(clienteSeleccionado = null) {
  validarClientes();

  const select = $("cliente");
  if (!select) return;

  const actual = clienteSeleccionado || select.value || clientes[0] || "";
  select.innerHTML = "";

  clientes.forEach(nombre => {
    const option = document.createElement("option");
    option.value = nombre;
    option.textContent = nombre;
    select.appendChild(option);
  });

  if (clientes.includes(actual)) {
    select.value = actual;
  } else if (clientes.length > 0) {
    select.value = clientes[0];
  }
}

function limpiarPedidoCrudo() {
  const pedido = $("pedidoCrudo");
  if (pedido) pedido.value = "";
}

function agregarCliente() {
  validarClientes();

  const nombre = prompt("Nombre del nuevo cliente:");
  if (!nombre) return;

  const limpio = nombre.trim();
  if (!limpio) return;

  const existe = clientes.some(c => normalizar(c) === normalizar(limpio));
  if (existe) {
    alert("Ese cliente ya existe.");
    return;
  }

  clientes.push(limpio);
  guardarTodo();
  renderClientes(limpio);
  limpiarPedidoCrudo();
  alert("Cliente agregado.");
}

function modificarCliente() {
  validarClientes();

  const select = $("cliente");
  const actual = select ? select.value : "";
  if (!actual) {
    alert("No hay cliente seleccionado.");
    return;
  }

  const nuevo = prompt("Modificar nombre del cliente:", actual);
  if (!nuevo) return;

  const limpio = nuevo.trim();
  if (!limpio) return;

  const existe = clientes.some(c => normalizar(c) === normalizar(limpio) && c !== actual);
  if (existe) {
    alert("Ya existe otro cliente con ese nombre.");
    return;
  }

  clientes = clientes.map(c => c === actual ? limpio : c);
  guardarTodo();
  renderClientes(limpio);
  limpiarPedidoCrudo();
  alert("Cliente modificado.");
}



function fechaEntregaPredeterminada() {
  const base = new Date(fechaOperativaActual() + "T12:00:00");
  base.setDate(base.getDate() + 1);
  return [
    base.getFullYear(),
    String(base.getMonth() + 1).padStart(2, "0"),
    String(base.getDate()).padStart(2, "0")
  ].join("-");
}

function actualizarSelectorPedidoFuturo(forzarFecha = "") {
  const check = $("checkPedidoFuturo");
  const contenedor = $("selectorFechaPedidoFuturo");
  const input = $("fechaPedido");
  const texto = $("fechaEntregaAutomatica");
  const predeterminada = fechaEntregaPredeterminada();

  if (!check || !contenedor || !input) return;

  if (forzarFecha) {
    input.value = forzarFecha;
    check.checked = forzarFecha > predeterminada;
  }

  contenedor.classList.toggle("hidden", !check.checked);

  if (!check.checked) {
    input.value = predeterminada;
  } else {
    input.min = predeterminada;
    if (!input.value || input.value <= predeterminada) {
      const siguiente = new Date(predeterminada + "T12:00:00");
      siguiente.setDate(siguiente.getDate() + 1);
      input.value = [
        siguiente.getFullYear(),
        String(siguiente.getMonth() + 1).padStart(2, "0"),
        String(siguiente.getDate()).padStart(2, "0")
      ].join("-");
    }
  }

  if (texto) {
    const legible = new Date(predeterminada + "T12:00:00").toLocaleDateString("es-AR", {
      weekday: "long",
      day: "2-digit",
      month: "2-digit"
    });
    texto.textContent = check.checked
      ? "Elegí la fecha especial de entrega."
      : `Entrega automática: ${legible}.`;
  }
}

function fechaEntregaNuevoPedido() {
  const esFuturo = Boolean($("checkPedidoFuturo")?.checked);
  if (!esFuturo) return fechaEntregaPredeterminada();

  const fecha = $("fechaPedido")?.value || "";
  if (!/^\d{4}-\d{2}-\d{2}$/.test(fecha)) return "";
  return fecha;
}

function fechaISOManana() {
  return fechaEntregaPredeterminada();
}

function fechaEntregaPedido(pedido) {
  return pedido.fechaEntrega || pedido.fecha || hoyISO();
}

function registrarPedidoEnHistorial(pedido) {
  if (!pedido || !pedido.id) return;
  const copia = JSON.parse(JSON.stringify({
    ...pedido,
    fechaEntrega: fechaEntregaPedido(pedido),
    guardadoHistorial: new Date().toISOString()
  }));
  historialPedidos = historialPedidos.filter(item => Number(item.id) !== Number(pedido.id));
  historialPedidos.unshift(copia);
  historialPedidos = historialPedidos.slice(0, 250);
}

function detectarProximoDiaEnTexto(texto, fechaBase = new Date()) {
  const normal = normalizarPedidoInteligente(texto || "");
  const dias = [
    ["domingo",0],["lunes",1],["martes",2],["miercoles",3],
    ["jueves",4],["viernes",5],["sabado",6]
  ];
  const encontrado = dias.find(([nombre]) => normal.includes(nombre));
  if (!encontrado) return "";
  const objetivo = encontrado[1];
  const fecha = new Date(fechaBase);
  let diferencia = (objetivo - fecha.getDay() + 7) % 7;
  if (diferencia === 0) diferencia = 7;
  fecha.setDate(fecha.getDate() + diferencia);
  return fecha.toISOString().slice(0,10);
}

function aplicarFechaDetectadaAlPedido(texto) {
  const input = $("fechaPedido");
  if (!input) return;
  const detectada = detectarProximoDiaEnTexto(texto);
  if (!detectada) return;
  if (input.value !== detectada) {
    const legible = new Date(detectada+"T12:00:00").toLocaleDateString("es-AR");
    if (confirm(`El pedido parece ser para el ${legible}. ¿Usar esa fecha de entrega?`)) {
      actualizarSelectorPedidoFuturo(detectada);
    }
  }
}


function normalizarProgramacionPedidoFijo(fijo) {
  return {
    ...fijo,
    nombre: fijo.nombre || "Pedido fijo",
    activo: fijo.activo !== false,
    dias: Array.isArray(fijo.dias) ? fijo.dias.map(Number) : []
  };
}

function programacionesAplicablesParaFecha(fecha) {
  const diaSemana = new Date(fecha + "T12:00:00").getDay();
  const vistos = new Set();

  return (pedidosFijos || [])
    .map(normalizarProgramacionPedidoFijo)
    .filter(fijo => {
      if (!fijo.activo || !fijo.dias.includes(diaSemana)) return false;
      const clave = String(fijo.id || `${fijo.cliente}-${fijo.nombre}-${fijo.texto}`);
      if (vistos.has(clave)) return false;
      vistos.add(clave);
      return true;
    });
}

function claveExclusionPedidoFijo(pedidoFijoId, fecha) {
  return `${Number(pedidoFijoId)}|${fecha}`;
}

function pedidoFijoExcluido(pedidoFijoId, fecha) {
  return exclusionesPedidosFijos.includes(claveExclusionPedidoFijo(pedidoFijoId, fecha));
}

function excluirPedidoFijoEnFecha(pedido) {
  if (!esPedidoFijoRobusto(pedido) || !pedido.pedidoFijoId) return;
  const clave = claveExclusionPedidoFijo(pedido.pedidoFijoId, fechaEntregaPedido(pedido));
  if (!exclusionesPedidosFijos.includes(clave)) exclusionesPedidosFijos.push(clave);
}



function asegurarPedidosFijosParaFecha(fecha, mostrarAviso = false) {
  if (!fecha || !Array.isArray(pedidosFijos)) return 0;

  // v4.2.1: evita que una programación fija ya duplicada vuelva a multiplicarse.
  repararDuplicadosPedidosFijos(fecha, false);

  const jornadaYaEnviada =
    jornadaEstaCerrada(fecha) ||
    (
      memoriaUltimoEnvio?.jornadaEnviada === true &&
      memoriaUltimoEnvio?.fecha === fecha
    );

  if (jornadaYaEnviada) {
    if (mostrarAviso) {
      alert("La jornada ya fue enviada. Para volver a cargar los pedidos fijos, usá “Nueva jornada / borrar memoria”.");
    }
    return 0;
  }

  const aplicables = programacionesAplicablesParaFecha(fecha);
  let agregados = 0;
  let reparados = 0;

  aplicables.forEach(fijo => {
    if (pedidoFijoExcluido(fijo.id, fecha)) return;

    let pedido = pedidos.find(item =>
      item.origen === "pedido_fijo" &&
      fechaEntregaPedido(item) === fecha &&
      (
        Number(item.pedidoFijoId) === Number(fijo.id) ||
        normalizarClienteReparacion(item.cliente) === normalizarClienteReparacion(fijo.cliente)
      )
    );

    const itemsCorrectos = procesarTextoPedido(fijo.texto || "", fijo.cliente, fecha);

    if (pedido) {
      // Reinterpreta automáticamente pedidos fijos creados por versiones anteriores.
      // No toca entregas que el usuario modificó manualmente.
      if (!pedido.modificadoDesdeFijo && !pedido.tieneCorreccionManualProducto) {
        const firmaAnterior = JSON.stringify(
          (pedido.items || []).map(item => [
            item.productoId,
            Number(item.cantidad || 0),
            item.unidad
          ])
        );
        const firmaNueva = JSON.stringify(
          itemsCorrectos.map(item => [
            item.productoId,
            Number(item.cantidad || 0),
            item.unidad
          ])
        );

        if (
          pedido.textoOriginal !== (fijo.texto || "") ||
          firmaAnterior !== firmaNueva
        ) {
          pedido.textoOriginal = fijo.texto || "";
          pedido.textoFijoOriginal = fijo.texto || "";
          pedido.items = itemsCorrectos;
          pedido.programacionNombre = fijo.nombre || "Pedido fijo";
          reparados += 1;
        }
      }
      return;
    }

    pedido = {
      id: Date.now() + agregados,
      cliente: fijo.cliente,
      fecha,
      fechaEntrega: fecha,
      textoOriginal: fijo.texto,
      textoFijoOriginal: fijo.texto,
      origen: "pedido_fijo",
      pedidoFijoId: fijo.id,
      programacionNombre: fijo.nombre || "Pedido fijo",
      modificadoDesdeFijo: false,
      confirmado: false,
      items: itemsCorrectos
    };

    // Si fue borrado para esta fecha, no volver a generarlo aunque cambie el ID.
    if (pedidoEstaEliminadoSync(pedido)) return;

    limpiarMarcaPedidoEliminado(pedido);
    pedidos.push(pedido);
    registrarPedidoEnHistorial(pedido);
    agregados += 1;
  });

  if (agregados > 0 || reparados > 0) {
    pedidosConfirmados = false;
    guardarTodo();
  }

  if (mostrarAviso) {
    alert(
      agregados || reparados
        ? `${agregados} pedido(s) cargado(s) y ${reparados} pedido(s) reparado(s).`
        : "Los pedidos de esa fecha ya estaban cargados o no hay pedidos fijos activos."
    );
  }

  return agregados;
}

function actualizarPedidoFijoDesdePedido(idPedido) {
  const pedido = pedidos.find(p => Number(p.id) === Number(idPedido));
  if (!pedido || pedido.origen !== "pedido_fijo") return;

  const fijo = pedidosFijos.find(f => Number(f.id) === Number(pedido.pedidoFijoId));
  if (!fijo) {
    alert("No se encontró el pedido fijo original.");
    return;
  }

  if (!confirm(
    `¿Actualizar el pedido fijo de ${pedido.cliente} con el contenido de este pedido?\n\n` +
    "El cambio se aplicará a las próximas fechas, pero no modificará pedidos anteriores."
  )) return;

  fijo.texto = pedido.textoOriginal || "";
  fijo.actualizado = new Date().toISOString();
  pedido.programacionNombre = fijo.nombre || "Pedido fijo";
  pedido.programacionPrioridad = Number(fijo.prioridad || 1);
  pedido.textoFijoOriginal = fijo.texto;
  pedido.modificadoDesdeFijo = false;

  guardarTodo();
  renderPedidosFijos();
  renderPedidosCargados();
  alert("Pedido fijo actualizado para las próximas entregas.");
}

function manejarCambioFechaPedidos() {
  const inputFecha = $("fechaPedido");
  const fechaElegida = inputFecha?.value;
  if (!fechaElegida) return;

  sincronizarProduccionConFechaPedido();

  // Algunas actualizaciones internas pueden redibujar el panel.
  // Restauramos la fecha elegida para que nunca vuelva sola a la fecha actual.
  if (inputFecha) inputFecha.value = fechaElegida;
  if ($("fechaCargarPedidosFijos")) $("fechaCargarPedidosFijos").value = fechaElegida;

  asegurarPedidosFijosParaFecha(fechaElegida, false);
  renderPedidosCargados();

  if (inputFecha) inputFecha.value = fechaElegida;
  calcularDiferencias();
  actualizarEstadoConfirmacion();
}

function editarPedidoCargado(id) {
  const pedido = pedidos.find(p => Number(p.id) === Number(id));
  if (!pedido) return;

  const modalExistente = $("modalEditarPedidoDiario");
  if (modalExistente) modalExistente.remove();

  const overlay = document.createElement("div");
  overlay.id = "modalEditarPedidoDiario";
  overlay.className = "dailyOrderEditOverlay";
  overlay.innerHTML = `
    <div class="dailyOrderEditModal">
      <h3>Editar pedido de ${escaparHtmlCatalogo(pedido.cliente)}</h3>
      <label>Fecha de entrega
        <input id="editarPedidoFecha" type="date" value="${fechaEntregaPedido(pedido)}">
      </label>
      <label>Productos y cantidades
        <textarea id="editarPedidoTexto" rows="10">${escaparHtmlCatalogo(pedido.textoOriginal || "")}</textarea>
      </label>
      <p class="hint">Podés escribir un producto por línea. También se reconocen varios productos seguidos.</p>
      <div class="toolbar">
        <button id="btnConfirmarEdicionPedido" class="primary" type="button">💾 Guardar cambios</button>
        <button id="btnCancelarEdicionPedido" type="button">Cancelar</button>
      </div>
    </div>`;

  document.body.appendChild(overlay);

  $("btnCancelarEdicionPedido").onclick = () => overlay.remove();
  $("btnConfirmarEdicionPedido").onclick = () => {
    const textoNuevo = $("editarPedidoTexto")?.value.trim() || "";
    const fechaNueva = $("editarPedidoFecha")?.value || "";

    if (!textoNuevo) return alert("El pedido no puede quedar vacío.");
    if (!/^\d{4}-\d{2}-\d{2}$/.test(fechaNueva)) {
      return alert("Elegí una fecha válida.");
    }

    const textoAnterior = pedido.textoOriginal || "";
    pedido.textoOriginal = textoNuevo;
    pedido.fecha = fechaNueva;
    pedido.fechaEntrega = fechaNueva;
    reabrirJornadaParaNuevoPedido(fechaNueva);
    pedido.items = procesarTextoPedido(textoNuevo, pedido.cliente, fechaNueva);
    pedido.editadoEn = new Date().toISOString();

    if (pedido.origen === "pedido_fijo") {
      if (!pedido.textoFijoOriginal) pedido.textoFijoOriginal = textoAnterior;
      pedido.modificadoDesdeFijo =
        textoNuevo.trim() !== String(pedido.textoFijoOriginal || "").trim();
    }

    pedidosConfirmados = false;
    registrarPedidoEnHistorial(pedido);
    guardarTodo();

    overlay.remove();
    renderPedidosCargados();
    renderPedidosFuturos();
    renderHistorialPedidos();
    calcularDiferencias();
    actualizarAvisoUnidadesAmbiguas();
    alert("Pedido actualizado correctamente.");
  };

  $("editarPedidoTexto")?.focus();
}

function repetirPedidoHistorial(id) {
  const anterior = historialPedidos.find(p => Number(p.id) === Number(id));
  if (!anterior) return;
  const fecha = prompt("Fecha de entrega para repetirlo (AAAA-MM-DD):", fechaISOManana());
  if (!fecha) return;
  const nuevo = {
    id: Date.now(),
    cliente: anterior.cliente,
    fecha,
    fechaEntrega: fecha,
    textoOriginal: anterior.textoOriginal,
    origen: "pedido_repetido",
    items: procesarTextoPedido(anterior.textoOriginal || "", anterior.cliente, fecha)
  };
  reabrirJornadaParaNuevoPedido(fecha);
  pedidos.push(nuevo);
  registrarPedidoEnHistorial(nuevo);
  pedidosConfirmados = false;
  guardarTodo();
  renderPedidosCargados();
  renderPedidosFuturos();
  renderHistorialPedidos();
  calcularDiferencias();
  alert("Pedido repetido correctamente.");
}

function renderHistorialPedidos() {
  const cont = $("listaHistorialPedidos");
  if (!cont) return;
  if (!historialPedidos.length) {
    cont.innerHTML = "<p>No hay pedidos en el historial todavía.</p>";
    return;
  }
  cont.innerHTML = historialPedidos.slice(0,80).map(p => `
    <div class="historyOrderCard">
      <div><strong>${escaparHtmlCatalogo(p.cliente || "Sin cliente")}</strong>
      <span>Entrega: ${new Date(fechaEntregaPedido(p)+"T12:00:00").toLocaleDateString("es-AR")}</span></div>
      <pre>${escaparHtmlCatalogo(p.textoOriginal || "")}</pre>
      <button type="button" onclick="repetirPedidoHistorial(${p.id})">📋 Repetir pedido</button>
    </div>`).join("");
}

function cantidadPedidosFuturos() {
  const entregaNormal = fechaEntregaPredeterminada();
  return pedidos.filter(pedido => fechaEntregaPedido(pedido) > entregaNormal).length;
}

function actualizarBadgePedidosFuturos() {
  const badge = $("badgePedidosFuturos");
  if (!badge) return;
  const cantidad = cantidadPedidosFuturos();
  badge.textContent = String(cantidad);
  badge.classList.toggle("empty", cantidad === 0);
}

function verPedidoFuturo(id) {
  const pedido = pedidos.find(p => Number(p.id) === Number(id));
  if (!pedido) {
    alert("No se encontró el pedido.");
    return;
  }

  const items = (pedido.items || []).filter(item => item.estado !== "NO PEDIDO");
  const detalle = items.length
    ? items.map(item => `
        <div class="futureViewItem">
          <span>${escaparHtmlCatalogo(item.producto || "Producto")}</span>
          <strong>${fmt(item.cantidad)} ${escaparHtmlCatalogo(item.unidad || "")}</strong>
        </div>
      `).join("")
    : '<p>No se detectaron productos cargados.</p>';

  const modalAnterior = $("modalVerPedidoFuturo");
  if (modalAnterior) modalAnterior.remove();

  const overlay = document.createElement("div");
  overlay.id = "modalVerPedidoFuturo";
  overlay.className = "modal";
  overlay.innerHTML = `
    <div class="modalContent futureViewModal">
      <button type="button" class="modalClose" id="cerrarVerPedidoFuturo">×</button>
      <h3>${escaparHtmlCatalogo(pedido.cliente || "Cliente")}</h3>
      <p><strong>Entrega:</strong> ${new Date(fechaEntregaPedido(pedido) + "T12:00:00").toLocaleDateString("es-AR")}</p>
      <p><strong>Origen:</strong> ${etiquetaOrigenPedido(pedido)}</p>
      <div class="futureViewItems">${detalle}</div>
    </div>
  `;

  document.body.appendChild(overlay);
  document.body.classList.add("modal-open");

  const cerrar = () => {
    overlay.remove();
    document.body.classList.remove("modal-open");
  };
  $("cerrarVerPedidoFuturo")?.addEventListener("click", cerrar);
  overlay.addEventListener("click", evento => {
    if (evento.target === overlay) cerrar();
  });
}

function htmlFilaPedidoFuturo(pedido) {
  return `<div class="futureOrderRow">
    <strong>${escaparHtmlCatalogo(pedido.cliente)}</strong>
    <span>${(pedido.items || []).filter(i => i.estado !== "NO PEDIDO").length} ítems</span>
    <div class="futureOrderActions">
      <button type="button" onclick="verPedidoFuturo(${pedido.id})">👁 Ver</button>
      <button type="button" onclick="editarPedidoCargado(${pedido.id})">✏️ Editar</button>
      <button type="button" class="dangerBtn" onclick="borrarPedido(${pedido.id})">🗑 Eliminar</button>
    </div>
  </div>`;
}

function renderPedidosFuturos() {
  actualizarBadgePedidosFuturos();
  const cont = $("listaPedidosFuturos");
  if (!cont) return;

  const entregaNormal = fechaEntregaPredeterminada();
  const futuros = pedidos
    .filter(p => fechaEntregaPedido(p) > entregaNormal)
    .sort((a, b) => fechaEntregaPedido(a).localeCompare(fechaEntregaPedido(b)));

  if (!futuros.length) {
    cont.innerHTML = "<p>No hay pedidos para fechas posteriores.</p>";
    return;
  }

  const grupos = {};
  futuros.forEach(p => {
    const fecha = fechaEntregaPedido(p);
    (grupos[fecha] ||= []).push(p);
  });

  cont.innerHTML = Object.entries(grupos).map(([fecha, lista]) => {
    const pedidosEspeciales = lista.filter(p => !esPedidoFijoRobusto(p));
    const pedidosFijosFecha = lista.filter(esPedidoFijoRobusto);

    return `<div class="futureDateGroup">
      <h3>📅 ${new Date(fecha + "T12:00:00").toLocaleDateString("es-AR", {
        weekday: "long", day: "2-digit", month: "2-digit"
      })}</h3>

      <div class="futureSpecialOrders">
        ${pedidosEspeciales.length
          ? pedidosEspeciales.map(htmlFilaPedidoFuturo).join("")
          : '<p class="weeklyEmpty">No hay pedidos especiales cargados.</p>'}
      </div>

      ${pedidosFijosFecha.length ? `
        <details class="futureFixedOrders">
          <summary>🔁 Pedidos fijos <span>${pedidosFijosFecha.length}</span></summary>
          <div class="futureFixedOrdersBody">
            ${pedidosFijosFecha.map(htmlFilaPedidoFuturo).join("")}
          </div>
        </details>
      ` : ""}
    </div>`;
  }).join("");
}

function migrarPedidosFijosV301() {
  if (!Array.isArray(pedidosFijos)) pedidosFijos = [];

  pedidosFijos = pedidosFijos
    .filter(fijo => fijo && fijo.cliente)
    .map((fijo, indice) => ({
      ...fijo,
      id: Number(fijo.id) || (Date.now() + indice),
      cliente: String(fijo.cliente || "").trim(),
      nombre: String(fijo.nombre || `Pedido ${indice + 1}`).trim(),
      texto: String(fijo.texto || fijo.textoOriginal || "").trim(),
      dias: Array.isArray(fijo.dias) ? fijo.dias.map(Number).filter(d => d >= 0 && d <= 6) : [],
      activo: fijo.activo !== false
    }));

  guardarTodo();
}

function siguienteNumeroPedidoCliente(cliente) {
  return pedidosFijos.filter(f => normalizar(f.cliente) === normalizar(cliente)).length + 1;
}

function limpiarFormularioPedidoFijo() {
  if ($("pedidoFijoTexto")) $("pedidoFijoTexto").value = "";
  if ($("btnGuardarPedidoFijo")) $("btnGuardarPedidoFijo").dataset.editando = "";
}

function crearPedidoFijoCliente(cliente = "") {
  const seleccionado = cliente || $("pedidoFijoCliente")?.value || clientes[0] || "";
  if (!seleccionado) {
    alert("Primero agregá o seleccioná un cliente.");
    return;
  }

  const numero = siguienteNumeroPedidoCliente(seleccionado);
  const nuevo = {
    id: Date.now(),
    cliente: seleccionado,
    nombre: `Pedido ${numero}`,
    texto: "",
    dias: [],
    activo: true,
    creado: new Date().toISOString()
  };

  pedidosFijos.push(nuevo);
  guardarTodo();
  renderPedidosFijos();

  setTimeout(() => {
    const tarjeta = document.querySelector(`[data-fixed-order-id="${nuevo.id}"]`);
    if (tarjeta) {
      tarjeta.open = true;
      tarjeta.scrollIntoView({ behavior: "smooth", block: "center" });
      tarjeta.querySelector("[data-fixed-texto]")?.focus();
    }
  }, 80);
}

function diasPedidoFijoDesdeTarjeta(tarjeta) {
  return [...tarjeta.querySelectorAll("[data-fixed-dia]:checked")]
    .map(input => Number(input.value));
}

function validarDiasSinSuperposicion(id, cliente, dias) {
  const conflicto = pedidosFijos.find(fijo =>
    Number(fijo.id) !== Number(id) &&
    fijo.activo !== false &&
    normalizar(fijo.cliente) === normalizar(cliente) &&
    (fijo.dias || []).some(dia => dias.includes(Number(dia)))
  );

  if (!conflicto) return true;

  const nombres = ["Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado"];
  const repetidos = (conflicto.dias || [])
    .filter(dia => dias.includes(Number(dia)))
    .map(dia => nombres[Number(dia)])
    .join(", ");

  alert(
    `${cliente} ya tiene "${conflicto.nombre || "otro pedido"}" asignado para: ${repetidos}.\n\n` +
    "Quitá esos días de uno de los dos pedidos para evitar que se mezclen."
  );
  return false;
}

function guardarPedidoFijoTarjeta(id) {
  const tarjeta = document.querySelector(`[data-fixed-order-id="${CSS.escape(String(id))}"]`);
  const fijo = pedidosFijos.find(p => Number(p.id) === Number(id));
  if (!tarjeta || !fijo) return;

  const nombre = tarjeta.querySelector("[data-fixed-nombre]")?.value.trim() || fijo.nombre || "Pedido";
  const texto = tarjeta.querySelector("[data-fixed-texto]")?.value.trim() || "";
  const dias = diasPedidoFijoDesdeTarjeta(tarjeta);

  if (!texto) {
    alert("Escribí los productos y cantidades del pedido.");
    return;
  }

  if (!dias.length) {
    alert("Marcá al menos un día para este pedido.");
    return;
  }

  if (!validarDiasSinSuperposicion(id, fijo.cliente, dias)) return;

  fijo.nombre = nombre;
  fijo.texto = texto;
  fijo.dias = dias;
  fijo.activo = tarjeta.querySelector("[data-fixed-activo]")?.checked !== false;
  fijo.actualizado = new Date().toISOString();

  guardarTodo();
  renderPedidosFijos();

  // Reprocesa los pedidos diarios ya creados de esta programación que todavía tienen 0 ítems.
  pedidos
    .filter(p => p.origen === "pedido_fijo" && Number(p.pedidoFijoId) === Number(id))
    .forEach(p => {
      if (!(p.items || []).length) {
        p.textoOriginal = texto;
        p.textoFijoOriginal = texto;
        p.items = procesarTextoPedido(texto, fijo.cliente, fechaEntregaPedido(p));
      }
    });

  guardarTodo();
  renderPedidosCargados();
  calcularDiferencias();
  alert(`${nombre} guardado correctamente.`);
}

function editarPedidoFijo(id) {
  const tarjeta = document.querySelector(`[data-fixed-order-id="${CSS.escape(String(id))}"]`);
  if (!tarjeta) return;
  tarjeta.open = true;
  tarjeta.scrollIntoView({ behavior: "smooth", block: "center" });
  tarjeta.querySelector("[data-fixed-texto]")?.focus();
}

function duplicarPedidoFijo(id) {
  const fijo = pedidosFijos.find(p => Number(p.id) === Number(id));
  if (!fijo) return;

  const nuevo = {
    ...fijo,
    id: Date.now(),
    nombre: `Pedido ${siguienteNumeroPedidoCliente(fijo.cliente)}`,
    dias: [],
    creado: new Date().toISOString(),
    actualizado: undefined
  };

  pedidosFijos.push(nuevo);
  guardarTodo();
  renderPedidosFijos();

  setTimeout(() => {
    const tarjeta = document.querySelector(`[data-fixed-order-id="${nuevo.id}"]`);
    if (tarjeta) {
      tarjeta.open = true;
      tarjeta.scrollIntoView({ behavior: "smooth", block: "center" });
    }
  }, 80);
}

function alternarPedidoFijo(id) {
  const fijo = pedidosFijos.find(p => Number(p.id) === Number(id));
  if (!fijo) return;
  fijo.activo = fijo.activo === false;
  guardarTodo();
  renderPedidosFijos();
}

function eliminarPedidoFijo(id) {
  const fijo = pedidosFijos.find(p => Number(p.id) === Number(id));
  if (!fijo) return;
  if (!confirm(`¿Eliminar "${fijo.nombre || "este pedido"}" de ${fijo.cliente}?`)) return;

  pedidosFijos = pedidosFijos.filter(p => Number(p.id) !== Number(id));
  guardarTodo();
  renderPedidosFijos();
}

function renderPedidosFijos() {
  const cont = $("listaPedidosFijos");
  if (!cont) return;

  const nombresDias = [
    ["1", "Lun"], ["2", "Mar"], ["3", "Mié"], ["4", "Jue"],
    ["5", "Vie"], ["6", "Sáb"], ["0", "Dom"]
  ];

  const grupos = {};
  clientes.forEach(cliente => grupos[cliente] = []);

  pedidosFijos
    .map(normalizarProgramacionPedidoFijo)
    .sort((a, b) =>
      String(a.cliente).localeCompare(String(b.cliente), "es") ||
      Number(a.id) - Number(b.id)
    )
    .forEach(fijo => {
      if (!grupos[fijo.cliente]) grupos[fijo.cliente] = [];
      grupos[fijo.cliente].push(fijo);
    });

  cont.innerHTML = Object.entries(grupos).map(([cliente, fijos]) => `
    <section class="fixedClientBlock">
      <div class="fixedClientBlockHeader">
        <div>
          <strong>${escaparHtmlCatalogo(cliente)}</strong>
          <span>${fijos.length} pedido(s) fijo(s)</span>
        </div>
        <button type="button" class="primary" onclick="crearPedidoFijoCliente('${escaparHtmlCatalogo(cliente)}')">
          ➕ Agregar pedido fijo
        </button>
      </div>

      <div class="fixedClientOrders">
        ${fijos.length ? fijos.map((fijo, indice) => `
          <details class="fixedOrderEditor ${fijo.activo ? "" : "paused"}"
                   data-fixed-order-id="${fijo.id}">
            <summary>
              <div>
                <strong>${escaparHtmlCatalogo(fijo.nombre || `Pedido ${indice + 1}`)}</strong>
                <span>${fijo.dias.length
                  ? fijo.dias.map(d => nombresDias.find(([v]) => Number(v) === Number(d))?.[1]).filter(Boolean).join(" · ")
                  : "Sin días configurados"}</span>
              </div>
              <b>${fijo.activo ? "Activo" : "Pausado"}</b>
            </summary>

            <div class="fixedOrderEditorBody">
              <label>Nombre
                <input data-fixed-nombre type="text"
                       value="${escaparHtmlCatalogo(fijo.nombre || `Pedido ${indice + 1}`)}">
              </label>

              <label>Productos y cantidades
                <textarea data-fixed-texto rows="7"
                  placeholder="Escribí un producto por línea. Ej:&#10;Marineras 0,3 kg&#10;Bizcocho de grasa 0,5 kg">${escaparHtmlCatalogo(fijo.texto || "")}</textarea>
              </label>

              <fieldset class="weekdaySelector">
                <legend>Días de este pedido</legend>
                <div class="weekdayGrid">
                  ${nombresDias.map(([valor, etiqueta]) => `
                    <label>
                      <input data-fixed-dia type="checkbox" value="${valor}"
                             ${(fijo.dias || []).includes(Number(valor)) ? "checked" : ""}>
                      <span>${etiqueta}</span>
                    </label>
                  `).join("")}
                </div>
              </fieldset>

              <label class="fixedActiveCheck">
                <input data-fixed-activo type="checkbox" ${fijo.activo ? "checked" : ""}>
                Pedido activo
              </label>

              <div class="toolbar">
                <button type="button" class="primary" onclick="guardarPedidoFijoTarjeta(${fijo.id})">
                  💾 Guardar este pedido
                </button>
                <button type="button" onclick="duplicarPedidoFijo(${fijo.id})">
                  📋 Duplicar como otro pedido
                </button>
                <button type="button" class="dangerBtn" onclick="eliminarPedidoFijo(${fijo.id})">
                  🗑 Eliminar
                </button>
              </div>
            </div>
          </details>
        `).join("") : '<p class="emptyFixedClient">Este cliente todavía no tiene pedidos fijos.</p>'}
      </div>
    </section>
  `).join("");
}

function cargarPedidosFijosParaFecha(){
  const fecha = $("fechaCargarPedidosFijos")?.value;
  if (!fecha) {
    alert("Elegí una fecha.");
    return;
  }

  asegurarPedidosFijosParaFecha(fecha, true);

  if ($("fechaPedido")) $("fechaPedido").value = fecha;
  renderPedidosCargados();
  renderPedidosFuturos();
  renderHistorialPedidos();
  calcularDiferencias();
}

function renderSelectorClientesPedidoFijo(){
  const s=$("pedidoFijoCliente");if(!s)return;
  const actual=s.value;s.innerHTML=clientes.map(c=>`<option value="${escaparHtmlCatalogo(c)}">${escaparHtmlCatalogo(c)}</option>`).join("");
  if(clientes.includes(actual))s.value=actual;
}

function procesarPedidoActual() {
  const cliente = $("cliente").value;
  const texto = $("pedidoCrudo").value;
  aplicarFechaDetectadaAlPedido(texto);
  const fecha = fechaEntregaNuevoPedido();

  if (!texto.trim()) {
    alert("Pegá un pedido primero.");
    return;
  }

  if (!fecha) {
    alert("Elegí una fecha válida para el pedido futuro.");
    return;
  }

  const procesado = procesarTextoPedido(texto, cliente, fecha);
  const ahoraPedido = new Date().toISOString();
  const nuevoPedido = {
    id: Date.now(),
    fecha,
    fechaEntrega: fecha,
    cliente,
    textoOriginal: texto,
    origen: "manual",
    confirmado: false,
    creado: ahoraPedido,
    actualizado: ahoraPedido,
    items: procesado
  };
  reabrirJornadaParaNuevoPedido(fecha);

  // Una carga manual nueva nunca hereda la eliminación semántica de una prueba anterior.
  pedidosEliminados = pedidosEliminados.filter(
    item => clavePedidoEliminado(item) !== String(nuevoPedido.id)
  );
  pedidos.push(nuevoPedido);
  registrarPedidoEnHistorial(nuevoPedido);
  emitirNotificacionPedidoSiCorresponde(nuevoPedido);

  pedidosConfirmados = false;
  guardarTodo();

  renderUltimoProcesado(procesado);
  renderPedidosCargados();
  renderPedidosFuturos();
  renderHistorialPedidos();
  calcularDiferencias();
  actualizarEstadoConfirmacion();

  $("pedidoCrudo").value = "";
  if ($("checkPedidoFuturo")) $("checkPedidoFuturo").checked = false;
  actualizarSelectorPedidoFuturo();
  mostrarMensajePedido("Pedido cargado correctamente");
}

function renderUltimoProcesado() {
  const filas = pedidos.flatMap(pedido =>
    (pedido.items || []).map(item => ({ pedidoId: pedido.id, ...item, cliente: pedido.cliente }))
  );

  if (!filas.length) {
    $("ultimoProcesado").innerHTML = "<p>No se detectaron productos.</p>";
    actualizarAvisoUnidadesAmbiguas();
    return;
  }

  let html = "<table><thead><tr><th>Producto</th><th>Cantidad</th><th>Unidad</th><th>Cliente</th><th>Estado</th><th>Texto leído</th></tr></thead><tbody>";

  for (const it of filas) {
    const clase = (it.unidadAmbigua || it.estado === "REVISAR UNIDAD") ? "ambiguousRow" : "";
    html += `<tr class="${clase}">
      <td>${it.producto}${botonesResolverProducto(it.pedidoId, it)}${botonesResolverUnidad(it.pedidoId, it)}</td>
      <td>${fmt(it.cantidad)}</td>
      <td>${it.unidad}</td>
      <td>${it.cliente}</td>
      <td>${it.estado}</td>
      <td>${it.original}</td>
    </tr>`;
  }

  $("ultimoProcesado").innerHTML = html + "</tbody></table>";
  actualizarAvisoUnidadesAmbiguas();
}

let pestanaPedidosActiva = "dia";

function cambiarPestanaPedidos(tipo) {
  pestanaPedidosActiva = tipo === "fijos" ? "fijos" : "dia";

  $("tabPedidosDia")?.classList.toggle("active", pestanaPedidosActiva === "dia");
  $("tabPedidosFijos")?.classList.toggle("active", pestanaPedidosActiva === "fijos");

  const ayuda = $("ayudaPestanaPedidos");
  if (ayuda) {
    ayuda.textContent = pestanaPedidosActiva === "fijos"
      ? "Estos pedidos vienen de la programación fija. Confirmá únicamente los que realmente se entregarán hoy."
      : "Acá se muestran los pedidos manuales y enviados desde el enlace del cliente.";
  }

  renderPedidosCargados();
}

function pedidoEstaConfirmado(pedido) {
  return pedido?.confirmado === true;
}

function alternarConfirmacionPedido(idPedido, confirmado) {
  const pedido = pedidos.find(item => Number(item.id) === Number(idPedido));
  if (!pedido) return;

  pedido.confirmado = Boolean(confirmado);
  pedidosConfirmados = pedidos
    .filter(item => fechaEntregaPedido(item) === ($("fechaPedido")?.value || hoyISO()))
    .some(item => item.confirmado === true);

  // Actualizar solamente la tarjeta marcada. No reconstruir el panel:
  // así el cliente, el grupo y el día permanecen abiertos.
  const tarjeta = document.querySelector(`[data-pedido-card-id="${idPedido}"]`);
  if (tarjeta) {
    tarjeta.classList.toggle("isConfirmed", Boolean(confirmado));

    const etiqueta = tarjeta.querySelector(".compactConfirm");
    if (etiqueta) {
      etiqueta.classList.toggle("confirmed", Boolean(confirmado));
      const texto = etiqueta.querySelector("span");
      if (texto) texto.textContent = confirmado ? "Confirmado" : "Confirmar";
    }
  }

  sincronizarConfirmacionDiaDesdePedidos();
  guardarTodo();
  calcularDiferencias();
  actualizarEstadoConfirmacion();
}

function pedidosConfirmadosParaFecha(fecha) {
  return pedidos.filter(pedido =>
    fechaEntregaPedido(pedido) === fecha &&
    pedidoEstaConfirmado(pedido)
  );
}

function renderPedidosCargados() {
  renderPanelPedidosSemana();
  actualizarAvisoUnidadesAmbiguas();
  renderTicketsPorDia();
}


function borrarPedido(id) {
  const pedido = pedidos.find(p => Number(p.id) === Number(id));
  if (!pedido) return;
  if (!confirm("¿Seguro que querés borrar este pedido?")) return;

  excluirPedidoFijoEnFecha(pedido);
  registrarPedidoEliminado(pedido);
  localStorage.setItem("fratello_pedidos_eliminados", JSON.stringify(pedidosEliminados));
  pedidos = pedidos.filter(p => Number(p.id) !== Number(id));
  pedidosConfirmados = false;
  guardarTodo();

  renderPedidosCargados();
  renderPedidosFuturos();
  renderHistorialPedidos();
  calcularDiferencias();
  actualizarEstadoConfirmacion();

  const vista = $("vistaPedidosInline");
  if (vista) vista.innerHTML = "";
}

function borrarPedidosSeleccionados() {
  const seleccionados = Array.from(document.querySelectorAll(".checkPedidoEliminar:checked"))
    .map(c => Number(c.value));

  if (!seleccionados.length) {
    alert("Seleccioná al menos un pedido para borrar.");
    return;
  }

  if (!confirm(`¿Seguro que querés borrar ${seleccionados.length} pedido(s)?`)) return;

  pedidos
    .filter(p => seleccionados.includes(Number(p.id)))
    .forEach(pedido => {
      excluirPedidoFijoEnFecha(pedido);
      registrarPedidoEliminado(pedido);
    });
  localStorage.setItem("fratello_pedidos_eliminados", JSON.stringify(pedidosEliminados));

  pedidos = pedidos.filter(p => !seleccionados.includes(Number(p.id)));
  pedidosConfirmados = false;
  guardarTodo();

  renderPedidosCargados();
  calcularDiferencias();
  actualizarEstadoConfirmacion();

  const vista = $("vistaPedidosInline");
  if (vista) vista.innerHTML = "";
}

function productoAdmiteUnidadDocena(producto) {
  const forma = producto?.formaVenta || "";
  return forma === "unidad_docena" ||
    producto?.unidad === "docena" ||
    producto?.unidad === "unidad";
}

function cantidadAUnidadBase(cantidad, unidad, producto) {
  const valor = Number(cantidad || 0);
  const u = String(unidad || producto?.unidad || "unidad").toLowerCase();

  if (productoAdmiteUnidadDocena(producto)) {
    if (u === "docena" || u === "docenas") return valor * 12;
    if (u === "unidad" || u === "unidades" || u === "unid") return valor;
  }

  return valor;
}

function formatearCantidadResumen(cantidadBase, producto) {
  const valor = Number(cantidadBase || 0);

  if (productoAdmiteUnidadDocena(producto)) {
    const signo = valor < 0 ? "-" : "";
    const absoluto = Math.abs(valor);
    const docenas = Math.floor(absoluto / 12);
    const unidades = Math.round((absoluto - docenas * 12) * 1000) / 1000;
    const partes = [];

    if (docenas > 0) partes.push(`${fmt(docenas)} doc`);
    if (unidades > 0 || !partes.length) partes.push(`${fmt(unidades)} unid`);

    return signo + partes.join(" + ");
  }

  return `${fmt(valor)} ${producto?.unidad || "unidad"}`;
}

function calcularDiferencias() {
  const totalesPedido = {};

  const fechaTrabajo = $("fechaPedido")?.value || hoyISO();
  for (const pedido of pedidosConfirmadosParaFecha(fechaTrabajo)) {
    for (const it of pedido.items || []) {
      if (it.estado === "NO PEDIDO") continue;

      const producto = productoPorId(it.productoId);
      if (!producto) continue;

      const cantidadBase = cantidadAUnidadBase(it.cantidad, it.unidad, producto);
      totalesPedido[it.productoId] =
        (totalesPedido[it.productoId] || 0) + cantidadBase;
    }
  }

  const filas = [];

  for (const p of productos) {
    const produccionCargada = Number(produccion[claveProduccion(p.id)] || 0);
    const prodBase = cantidadAUnidadBase(produccionCargada, p.unidad, p);
    const pedBase = Number(totalesPedido[p.id] || 0);

    if ((p.activo === false || p.nuevo) && prodBase === 0 && pedBase === 0) continue;
    if (prodBase === 0 && pedBase === 0) continue;

    const difBase = prodBase - pedBase;
    let estado = "JUSTO";
    let accion = "No hacer nada";

    if (difBase > 0) {
      estado = "SOBRA";
      accion = `Sobran ${formatearCantidadResumen(difBase, p)}`;
    }

    if (difBase < 0) {
      estado = "FALTA";
      accion = `HACER ${formatearCantidadResumen(Math.abs(difBase), p)}`;
    }

    filas.push({
      producto: p.nombre,
      unidad: p.unidad,
      productoConfig: p,
      prod: prodBase,
      ped: pedBase,
      dif: difBase,
      prodTexto: formatearCantidadResumen(prodBase, p),
      pedTexto: formatearCantidadResumen(pedBase, p),
      difTexto: formatearCantidadResumen(Math.abs(difBase), p),
      estado,
      accion
    });
  }

  renderComparador(filas);
  renderResumenPanadero(filas);
}

function renderComparador(filas) {
  if (!filas.length) {
    $("comparador").innerHTML = "<p>Todavía no hay datos para comparar.</p>";
    return;
  }

  let html = "<table><thead><tr><th>Producto</th><th>Producido</th><th>Pedido total</th><th>Estado</th><th>Acción</th></tr></thead><tbody>";

  for (const f of filas) {
    const cls = f.estado === "FALTA" ? "estado-falta" : f.estado === "SOBRA" ? "estado-sobra" : "estado-justo";
    html += `<tr><td>${f.producto}</td><td>${f.prodTexto}</td><td>${f.pedTexto}</td><td class="${cls}">${f.estado}</td><td>${f.accion}</td></tr>`;
  }

  $("comparador").innerHTML = html + "</tbody></table>";
}

function renderResumenPanadero(filas) {
  const faltas = filas.filter(f => f.estado === "FALTA");
  const sobras = filas.filter(f => f.estado === "SOBRA");

  let txt = "FRATELLO - RESUMEN PARA PANADERO\n--------------------------------\n\n🔴 FALTANTES A PRODUCIR\n";
  txt += faltas.length ? faltas.map(f => `- ${f.producto}: HACER ${f.difTexto}`).join("\n") : "No falta producir nada.";

  txt += "\n\n🟢 SOBRANTES / NO HACER MÁS\n";
  txt += sobras.length ? sobras.map(f => `- ${f.producto}: sobran ${f.difTexto}`).join("\n") : "No hay sobrantes.";

  $("resumenPanadero").textContent = txt;
}

function fmt(n) {
  return String(Math.round((Number(n) + Number.EPSILON) * 1000) / 1000).replace(".", ",");
}

function copiarResumen() {
  const acciones = $("resumenPanadero")?.textContent || "";
  const clientes = textoPedidosClientes();
  const mensaje = `${acciones}

--------------------
${clientes}`;

  navigator.clipboard.writeText(mensaje)
    .then(() => alert("Resumen y pedidos copiados. Las acciones aparecen primero."))
    .catch(() => alert("No se pudo copiar automáticamente. Copiá el texto manualmente."));
}



function textoPedidosClientes() {
  const lista = pedidosConfirmadosParaFecha(fechaJornadaActual());
  if (!lista.length) return "No hay pedidos confirmados.";
  let texto = "FRATELLO - Pedidos clientes confirmados\n\n";
  lista.forEach(p => {
    texto += `${p.cliente}:\n`;
    p.items.filter(i => i.estado !== "NO PEDIDO").forEach(i => {
      texto += `- ${fmt(i.cantidad)} ${i.unidad} ${i.producto}\n`;
    });
    texto += "\n";
  });
  return texto;
}

let scrollAntesModalTicket = 0;

function liberarScrollTicket() {
  document.body.classList.remove("modalAbierto", "modalOpen");
  document.documentElement.classList.remove("modalAbierto", "modalOpen");
  document.body.style.removeProperty("overflow");
  document.body.style.removeProperty("position");
  document.body.style.removeProperty("top");
  document.body.style.removeProperty("width");
  document.documentElement.style.removeProperty("overflow");
}

function abrirModalImpresion() {
  scrollAntesModalTicket = window.scrollY || document.documentElement.scrollTop || 0;
  $("modalImpresion")?.classList.remove("hidden");
  document.body.classList.add("modalAbierto");
}

function cerrarModalImpresion() {
  const modal = $("modalImpresion");
  if (modal) modal.classList.add("hidden");

  liberarScrollTicket();

  requestAnimationFrame(() => {
    window.scrollTo({ top: scrollAntesModalTicket, behavior: "auto" });
  });
}
function dibujarPunteada(ctx,x1,y1,x2,y2){
  ctx.save();ctx.setLineDash([8,7]);ctx.strokeStyle="#777";ctx.lineWidth=1.4;
  ctx.beginPath();ctx.moveTo(x1,y1);ctx.lineTo(x2,y2);ctx.stroke();ctx.restore();
}
function cargarImagen(src){
  return new Promise((ok,fail)=>{const img=new Image();img.onload=()=>ok(img);img.onerror=fail;img.src=src;});
}


const LISTAS_PRECIO_BASE = [
  { id: "cliente", nombre: "Clientes", fija: true },
  { id: "giuliano", nombre: "Giuliano", fija: true },
  { id: "bailone_libano", nombre: "Bailone / Líbano", fija: true },
  { id: "fratello", nombre: "Fratello", fija: true }
];

let listasPrecioPersonalizadas = JSON.parse(
  localStorage.getItem("fratello_listas_precio_personalizadas") || "[]"
);

function todasLasListasPrecio() {
  const personalizadas = Array.isArray(listasPrecioPersonalizadas)
    ? listasPrecioPersonalizadas
    : [];

  return [
    ...LISTAS_PRECIO_BASE,
    ...personalizadas.filter(lista =>
      lista &&
      lista.id &&
      lista.nombre &&
      !LISTAS_PRECIO_BASE.some(base => base.id === lista.id)
    )
  ];
}
function etiquetaListaPrecio(id) {
  return todasLasListasPrecio().find(lista => lista.id === id)?.nombre || "Cliente";
}

function buscarListaPorNombreCliente(nombreCliente) {
  const nombreNormalizado = normalizar(nombreCliente || "").trim();
  if (!nombreNormalizado) return null;

  return todasLasListasPrecio().find(lista => {
    const nombreLista = normalizar(lista?.nombre || "").trim();
    const idLista = normalizar(lista?.id || "").trim();
    return nombreLista === nombreNormalizado || idLista === nombreNormalizado;
  }) || null;
}

function listaPrecioAutomatica(nombreCliente) {
  const coincidenciaExacta = buscarListaPorNombreCliente(nombreCliente);
  if (coincidenciaExacta) return coincidenciaExacta.id;

  const nombre = normalizar(nombreCliente || "");

  // Alias históricos de clientes que comparten una misma columna.
  if (nombre.includes("libano") || nombre.includes("bailone")) {
    return "bailone_libano";
  }
  if (nombre.includes("giuliano")) {
    return "giuliano";
  }
  if (nombre.includes("fratello")) {
    return "fratello";
  }

  return "cliente";
}

function datosClientePorNombreFlexible(nombreCliente) {
  if (datosClientesCompletos?.[nombreCliente]) {
    return datosClientesCompletos[nombreCliente];
  }

  const buscado = normalizar(nombreCliente || "");
  const clave = Object.keys(datosClientesCompletos || {}).find(
    nombre => normalizar(nombre) === buscado
  );

  return clave ? datosClientesCompletos[clave] : null;
}

function listaPrecioCliente(nombreCliente) {
  const datosCliente = datosClientePorNombreFlexible(nombreCliente);
  const asignada = datosCliente?.listaPrecio || "auto";
  const listasValidas = todasLasListasPrecio();

  if (asignada !== "auto") {
    const asignadaNormalizada = normalizar(asignada);
    const listaAsignada = listasValidas.find(lista =>
      lista.id === asignada ||
      normalizar(lista.id) === asignadaNormalizada ||
      normalizar(lista.nombre) === asignadaNormalizada
    );

    if (listaAsignada) return listaAsignada.id;
  }

  return listaPrecioAutomatica(nombreCliente);
}
function unidadesPrecioProducto(p){const f=p.formaVenta||formaVentaPredeterminada(p.unidad);const m={solo_unidad:["unidad"],solo_docena:["docena"],solo_kg:["kg"],unidad_docena:["unidad","docena"],unidad_kg:["unidad","kg"],kg_paquete:["kg","paquete"],revisar_siempre:[p.unidad||"unidad"]};return[...new Set(m[f]||[p.unidad||"unidad"])];}
function clavePrecio(id,u){return`${id}__${normalizarUnidadPrecio(u)}`;}
function precioLista(id, unidad, lista) {
  const u = normalizarUnidadPrecio(unidad);
  const listaValida = todasLasListasPrecio().some(item => item.id === lista)
    ? lista
    : "cliente";

  const precioExacto = Number(
    listasPrecios?.[clavePrecio(id, u)]?.[listaValida] || 0
  );
  if (precioExacto > 0) return precioExacto;

  const precioUnidad = Number(
    listasPrecios?.[clavePrecio(id, "unidad")]?.[listaValida] || 0
  );
  const precioDocena = Number(
    listasPrecios?.[clavePrecio(id, "docena")]?.[listaValida] || 0
  );

  if (u === "docena" && precioUnidad > 0) return precioUnidad * 12;
  if (u === "unidad" && precioDocena > 0) return precioDocena / 12;

  // Si el producto fue cargado con otra unidad comercial, busca el valor
  // disponible para el mismo ID y la misma lista antes de caer al precio base.
  const prefijo = `${id}__`;
  const preciosMismoProducto = Object.entries(listasPrecios || {})
    .filter(([clave]) => clave.startsWith(prefijo))
    .map(([, valores]) => Number(valores?.[listaValida] || 0))
    .filter(valor => valor > 0);

  if (preciosMismoProducto.length === 1) {
    console.info(
      `[Fratello] Precio de ${id} tomado de la unidad comercial disponible en la lista ${listaValida}.`
    );
    return preciosMismoProducto[0];
  }

  const precioCliente = Number(
    listasPrecios?.[clavePrecio(id, u)]?.cliente || 0
  );
  if (precioCliente > 0) {
    console.warn(
      `[Fratello] No se encontró precio para ${id} en ${listaValida}; se usa la columna cliente.`
    );
    return precioCliente;
  }

  return Number(productoPorId(id)?.precios?.[u] || 0);
}
function renderSelectorListasCliente(valorSeleccionado = null) {
  const select = $("nuevoClienteListaPrecio");
  if (!select) return;

  const valorActual = valorSeleccionado ?? select.value ?? "auto";
  select.innerHTML =
    '<option value="auto">Automática según el nombre</option>' +
    todasLasListasPrecio()
      .map(lista => `<option value="${escaparHtmlCatalogo(lista.id)}">${escaparHtmlCatalogo(lista.nombre)}</option>`)
      .join("");

  const existe = [...select.options].some(option => option.value === valorActual);
  select.value = existe ? valorActual : "auto";
}

function crearIdListaPrecio(nombre) {
  const base = normalizar(nombre)
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "") || "lista_especial";

  let id = base;
  let numero = 2;

  while (todasLasListasPrecio().some(lista => lista.id === id)) {
    id = `${base}_${numero}`;
    numero += 1;
  }

  return id;
}

function agregarListaPrecioPersonalizada() {
  const nombre = prompt(
    "Nombre del cliente o de la nueva lista de precios:",
    ""
  );

  if (!nombre || !nombre.trim()) return;

  const limpio = nombre.trim();
  const repetida = todasLasListasPrecio().some(
    lista => normalizar(lista.nombre) === normalizar(limpio)
  );

  if (repetida) {
    alert("Ya existe una lista con ese nombre.");
    return;
  }

  const nueva = {
    id: crearIdListaPrecio(limpio),
    nombre: limpio,
    fija: false
  };

  listasPrecioPersonalizadas.push(nueva);
  localStorage.setItem(
    "fratello_listas_precio_personalizadas",
    JSON.stringify(listasPrecioPersonalizadas)
  );

  renderListasPrecios();
  renderSelectorListasCliente();
  renderSelectorListasCliente(nueva.id);
  guardarEnNube();

  alert(`Lista "${limpio}" agregada correctamente.`);
}

function eliminarListaPrecioPersonalizada(id) {
  const lista = listasPrecioPersonalizadas.find(item => item.id === id);
  if (!lista) return;

  if (!confirm(`¿Eliminar la lista de precios "${lista.nombre}"?`)) return;

  listasPrecioPersonalizadas = listasPrecioPersonalizadas.filter(
    item => item.id !== id
  );

  Object.values(datosClientesCompletos || {}).forEach(cliente => {
    if (cliente?.listaPrecio === id) cliente.listaPrecio = "auto";
  });

  Object.keys(listasPrecios || {}).forEach(clave => {
    if (listasPrecios[clave] && typeof listasPrecios[clave] === "object") {
      delete listasPrecios[clave][id];
    }
  });

  localStorage.setItem(
    "fratello_listas_precio_personalizadas",
    JSON.stringify(listasPrecioPersonalizadas)
  );

  guardarTodo();
  renderListasPrecios();
  renderSelectorListasCliente("auto");
  renderListaClientesCompleta();

  alert(`Lista "${lista.nombre}" eliminada.`);
}

function etiquetaUnidadPrecio(unidad) {
  const etiquetas = {
    unidad: "Unidad",
    docena: "Docena",
    kg: "Kg",
    paquete: "Paquete",
    bolsa: "Bolsa",
    bandeja: "Bandeja"
  };
  return etiquetas[normalizarUnidadPrecio(unidad)] || unidad;
}

function renderListasPrecios(){
  const c = $("tablaListasPrecios");
  if (!c) return;

  const listas = todasLasListasPrecio();
  const productosActivos = productos.filter(producto => producto.activo !== false);

  let h = `<table class="priceMatrix unifiedPriceMatrix">
    <thead>
      <tr>
        <th>Producto</th>
        <th>Forma de venta</th>
        ${listas.map(lista => `
          <th>
            <div class="priceColumnHeader">
              <span>${escaparHtmlCatalogo(lista.nombre)}</span>
              ${lista.fija ? "" : `<button type="button" class="priceDeleteColumn" onclick="eliminarListaPrecioPersonalizada('${escaparHtmlCatalogo(lista.id)}')" title="Eliminar esta lista">×</button>`}
            </div>
          </th>`).join("")}
      </tr>
    </thead>
    <tbody>`;

  productosActivos.forEach(producto => {
    const unidades = unidadesPrecioProducto(producto);

    h += `<tr class="unifiedProductPriceRow" data-product-price-id="${escaparHtmlCatalogo(producto.id)}">
      <td class="unifiedProductName">
        <strong>${escaparHtmlCatalogo(producto.nombre)}</strong>
        <small>${escaparHtmlCatalogo((producto.sinonimos || []).join(", "))}</small>
      </td>
      <td>
        <div class="unitBadges">
          ${unidades.map(unidad => `<span>${escaparHtmlCatalogo(etiquetaUnidadPrecio(unidad))}</span>`).join("")}
        </div>
      </td>
      ${listas.map(lista => `
        <td class="unifiedPriceCell">
          ${unidades.map(unidad => {
            const clave = clavePrecio(producto.id, unidad);
            return `<label class="priceUnitInput">
              <span>${escaparHtmlCatalogo(etiquetaUnidadPrecio(unidad))}</span>
              <input
                type="number"
                min="0"
                step="0.01"
                data-price-key="${escaparHtmlCatalogo(clave)}"
                data-price-list="${escaparHtmlCatalogo(lista.id)}"
                value="${Number(listasPrecios?.[clave]?.[lista.id] || 0)}"
                placeholder="0">
            </label>`;
          }).join("")}
        </td>`).join("")}
    </tr>`;
  });

  c.innerHTML = h + "</tbody></table>";
}

function guardarListasPrecios(){
  document.querySelectorAll("[data-price-key][data-price-list]").forEach(input => {
    const clave = input.dataset.priceKey;
    const lista = input.dataset.priceList;
    listasPrecios[clave] = listasPrecios[clave] || {};
    listasPrecios[clave][lista] = Number(input.value || 0);
  });

  localStorage.setItem("fratello_listas_precios", JSON.stringify(listasPrecios));
  guardarEnNube();

  const mensaje = $("mensajeListasPrecios");
  if (mensaje) {
    mensaje.textContent = "✅ Precios guardados correctamente.";
    mensaje.style.display = "block";
  }
}

function normalizarUnidadPrecio(unidad) {
  const u = String(unidad || "unidad").toLowerCase();
  if (["unid","unidades","u"].includes(u)) return "unidad";
  if (["doc","docenas"].includes(u)) return "docena";
  if (["kilo","kilos"].includes(u)) return "kg";
  if (u === "paquetes") return "paquete";
  if (u === "bolsas") return "bolsa";
  if (u === "bandejas") return "bandeja";
  return u;
}

function precioUnitarioItem(producto, unidad, cliente = "") {
  if (!producto) return 0;

  const listaCliente = listaPrecioCliente(cliente);
  let precio = precioLista(producto.id, unidad, listaCliente);
  if (precio > 0) return precio;

  // Si Fratello, Giuliano u otro cliente no tiene un precio específico,
  // usar la lista general de cliente para que el ticket pueda calcular totales.
  if (listaCliente !== "cliente") {
    precio = precioLista(producto.id, unidad, "cliente");
    if (precio > 0) return precio;
  }

  // Último respaldo: tomar el primer precio válido disponible para ese producto/unidad.
  const clave = clavePrecio(producto.id, normalizarUnidadPrecio(unidad));
  const preciosDisponibles = Object.values(listasPrecios?.[clave] || {})
    .map(Number)
    .filter(valor => valor > 0);

  return preciosDisponibles[0] || 0;
}


let ticketsSeleccionadosActuales = [];
let ticketsMemoria = JSON.parse(
  localStorage.getItem("fratello_tickets_memoria") || "[]"
);

function fechaISODesdeDate(fecha) {
  return [
    fecha.getFullYear(),
    String(fecha.getMonth() + 1).padStart(2, "0"),
    String(fecha.getDate()).padStart(2, "0")
  ].join("-");
}

function limitesSemanaTickets(fechaBase = fechaOperativaActual()) {
  const fecha = new Date(fechaBase + "T12:00:00");
  const dia = fecha.getDay();
  const retroceso = dia === 0 ? 6 : dia - 1;

  const lunes = new Date(fecha);
  lunes.setDate(fecha.getDate() - retroceso);

  const domingo = new Date(lunes);
  domingo.setDate(lunes.getDate() + 6);

  return {
    inicio: fechaISODesdeDate(lunes),
    fin: fechaISODesdeDate(domingo)
  };
}


function normalizarClienteReparacion(valor) {
  return String(valor || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .trim()
    .toLowerCase()
    .replace(/\s+/g, " ");
}

function puntajePedidoConservar(pedido) {
  let puntos = 0;
  if (pedido?.entregaConfirmada) puntos += 1000;
  if (pedido?.entregado) puntos += 500;
  if (Number(pedido?.pagoEntrega || 0) > 0) puntos += 400;
  if (pedido?.modificadoDesdeFijo) puntos += 250;
  if (Array.isArray(pedido?.entregaItems) && pedido.entregaItems.length) puntos += 200;
  if (Array.isArray(pedido?.items) && pedido.items.length) puntos += 50;
  if (pedido?.textoOriginal) puntos += 20;
  puntos += Number(pedido?.id || 0) / 1e15;
  return puntos;
}

function claveSemanticaPedidoFijo(pedido) {
  if (!pedido || pedido.origen !== "pedido_fijo") return "";
  const fecha = fechaEntregaPedido(pedido);
  const cliente = normalizarClienteReparacion(pedido.cliente);
  if (!fecha || !cliente) return "";
  return `${fecha}::${cliente}`;
}

function fusionarDatosPedidoDuplicado(destino, origen) {
  if (!destino || !origen) return destino;

  const camposProtegidos = [
    "entregaConfirmada", "entregaItems", "observacionEntrega", "pagoEntrega",
    "entregado", "fechaEntregaReal", "modificadoDesdeFijo"
  ];

  camposProtegidos.forEach(campo => {
    const valorDestino = destino[campo];
    const valorOrigen = origen[campo];
    const destinoVacio =
      valorDestino === undefined ||
      valorDestino === null ||
      valorDestino === false ||
      valorDestino === "" ||
      (Array.isArray(valorDestino) && !valorDestino.length) ||
      (typeof valorDestino === "number" && valorDestino === 0);

    if (destinoVacio && valorOrigen !== undefined && valorOrigen !== null) {
      destino[campo] = valorOrigen;
    }
  });

  if ((!Array.isArray(destino.items) || !destino.items.length) && Array.isArray(origen.items)) {
    destino.items = origen.items;
  }
  if (!destino.textoOriginal && origen.textoOriginal) destino.textoOriginal = origen.textoOriginal;
  if (!destino.textoFijoOriginal && origen.textoFijoOriginal) destino.textoFijoOriginal = origen.textoFijoOriginal;
  if (!destino.pedidoFijoId && origen.pedidoFijoId) destino.pedidoFijoId = origen.pedidoFijoId;

  return destino;
}

function repararDuplicadosPedidosFijos(fechaObjetivo = "", mostrarAviso = false) {
  if (!Array.isArray(pedidos)) pedidos = [];
  if (!Array.isArray(ticketsMemoria)) ticketsMemoria = [];

  const grupos = new Map();

  pedidos.forEach(pedido => {
    if (pedido?.origen !== "pedido_fijo") return;
    const fecha = fechaEntregaPedido(pedido);
    if (fechaObjetivo && fecha !== fechaObjetivo) return;

    const clave = claveSemanticaPedidoFijo(pedido);
    if (!clave) return;
    if (!grupos.has(clave)) grupos.set(clave, []);
    grupos.get(clave).push(pedido);
  });

  const idsEliminados = new Set();
  let gruposReparados = 0;

  grupos.forEach(lista => {
    if (lista.length <= 1) return;

    lista.sort((a, b) => puntajePedidoConservar(b) - puntajePedidoConservar(a));
    const conservar = lista[0];

    lista.slice(1).forEach(duplicado => {
      fusionarDatosPedidoDuplicado(conservar, duplicado);
      idsEliminados.add(String(duplicado.id));
    });

    gruposReparados += 1;
  });

  if (idsEliminados.size) {
    pedidos = pedidos.filter(pedido => !idsEliminados.has(String(pedido.id)));

    ticketsMemoria = ticketsMemoria.filter(ticket => {
      const tipo = ticket.tipoTicket || "normal";
      return !(tipo === "normal" && idsEliminados.has(String(ticket.id)));
    });

    // Los movimientos de cuenta corriente de tickets eliminados se fusionan
    // en el ticket conservado por cliente y fecha, evitando saldos duplicados.
    if (Array.isArray(cuentaCorrienteV42)) {
      const movimientosAEliminar = new Set(
        [...idsEliminados].map(id => `normal-${id}`)
      );

      cuentaCorrienteV42 = cuentaCorrienteV42.filter(movimiento =>
        !movimientosAEliminar.has(String(movimiento.claveTicket || ""))
      );
      localStorage.setItem(CUENTA_CORRIENTE_KEY_V42, JSON.stringify(cuentaCorrienteV42));
    }

    localStorage.setItem("pedidos", JSON.stringify(pedidos));
    localStorage.setItem("fratello_tickets_memoria", JSON.stringify(ticketsMemoria));

    if (typeof guardarTodo === "function") guardarTodo();
    else if (typeof guardarEnNube === "function") guardarEnNube();
  }

  if (mostrarAviso) {
    alert(
      idsEliminados.size
        ? `Reparación terminada.\n\nSe eliminaron ${idsEliminados.size} pedido(s) fijo(s) duplicado(s) en ${gruposReparados} cliente(s).\nLos pedidos manuales se conservaron.`
        : "No se encontraron pedidos fijos duplicados para reparar."
    );
  }

  return {
    eliminados: idsEliminados.size,
    grupos: gruposReparados
  };
}

function repararPedidosYTicketsDelDia(fecha) {
  if (!fecha) return;

  const etiqueta = etiquetaFechaTickets(fecha);
  if (!confirm(
    `¿Reparar los pedidos y tickets de ${etiqueta}?\n\n` +
    "Se eliminarán únicamente los pedidos fijos repetidos del mismo cliente. " +
    "Los pedidos manuales y las entregas registradas se conservarán."
  )) return;

  const resultado = repararDuplicadosPedidosFijos(fecha, false);

  // v4.2.2: la reparación ya no elimina tickets operativos ni históricos.
  // Únicamente limpia pedidos fijos duplicados y luego vuelve a sincronizar.
  guardarMemoriaTickets();
  sincronizarMemoriaTickets();
  renderPedidosCargados();
  renderTicketsPorDia();

  alert(
    `Reparación terminada.\n\n` +
    `Pedidos fijos duplicados eliminados: ${resultado.eliminados}\n` +
    `Tickets de Pedido Hoy conservados: sí\n` +
    `Tickets entregados o con cobro conservados: sí\n\n` +
    "La pantalla de Tickets volvió a sincronizarse sin borrar comprobantes."
  );
}


function claveTicketMemoria(pedido, tipo = "normal") {
  return `${tipo}-${String(pedido.id)}`;
}

function guardarMemoriaTickets() {
  localStorage.setItem("fratello_tickets_memoria", JSON.stringify(ticketsMemoria));
  guardarEnNube();
}

function recuperarTicketsPedidoHoyV422() {
  if (!Array.isArray(ticketsMemoria)) return 0;
  let recuperados = 0;

  ticketsMemoria.forEach(ticket => {
    const clave = String(ticket.claveMemoria || "");
    if (
      ticket.tipoTicket === "hoy" ||
      ticket.esPedidoHoy === true ||
      clave.startsWith("hoy-")
    ) {
      if (ticket.tipoTicket !== "hoy" || ticket.esPedidoHoy !== true) {
        ticket.tipoTicket = "hoy";
        ticket.esPedidoHoy = true;
        recuperados += 1;
      }
    }
  });

  if (recuperados) {
    localStorage.setItem("fratello_tickets_memoria", JSON.stringify(ticketsMemoria));
  }
  return recuperados;
}

function sincronizarMemoriaTickets() {
  recuperarTicketsPedidoHoyV422();

  // Corrige automáticamente duplicados de pedidos fijos antes de construir tickets.
  repararDuplicadosPedidosFijos("", false);

  const actuales = [
    ...pedidos.map(pedido => ({ pedido, tipo: "normal" })),
    ...pedidosHoy.map(pedido => ({ pedido, tipo: "hoy" }))
  ];

  const clavesActuales = new Set(
    actuales.map(({ pedido, tipo }) => claveTicketMemoria(pedido, tipo))
  );

  const porClave = new Map(
    (Array.isArray(ticketsMemoria) ? ticketsMemoria : [])
      .filter(ticket => {
        const clave = ticket.claveMemoria || claveTicketMemoria(ticket, ticket.tipoTicket || "normal");
        const fecha = ticket.fechaTicket || ticket.fechaEntrega || ticket.fecha || "";
        const esPedidoHoy = ticket.tipoTicket === "hoy" || ticket.esPedidoHoy === true;
        const tieneEntrega = Boolean(
          ticket.entregado ||
          ticket.entregaConfirmada ||
          ticket.fechaEntregaReal ||
          (Array.isArray(ticket.entregaItems) && ticket.entregaItems.length)
        );
        const tieneCobro = Number(ticket.pagoEntrega || 0) > 0;

        // v4.2.2:
        // Los pedidos de hoy, entregas y cobros son comprobantes históricos.
        // Se conservan aunque ya no estén en las listas operativas actuales.
        return (
          clavesActuales.has(clave) ||
          esPedidoHoy ||
          tieneEntrega ||
          tieneCobro ||
          jornadaEstaCerrada(fecha)
        );
      })
      .map(ticket => [
        ticket.claveMemoria || claveTicketMemoria(ticket, ticket.tipoTicket || "normal"),
        ticket
      ])
  );

  actuales.forEach(({ pedido, tipo }) => {
    const clave = claveTicketMemoria(pedido, tipo);
    const anterior = porClave.get(clave) || {};

    porClave.set(clave, {
      ...anterior,
      ...pedido,
      claveMemoria: clave,
      tipoTicket: tipo,
      esPedidoHoy: tipo === "hoy",
      fechaTicket:
        pedido.fechaEntrega ||
        pedido.fecha ||
        pedido.jornada ||
        anterior.fechaTicket ||
        fechaOperativaActual(),
      actualizadoTicket: new Date().toISOString()
    });
  });

  ticketsMemoria = [...porClave.values()]
    .filter(ticket => ticket && ticket.id)
    .sort((a, b) =>
      String(a.fechaTicket || "").localeCompare(String(b.fechaTicket || "")) ||
      String(a.cliente || "").localeCompare(String(b.cliente || ""), "es")
    );

  localStorage.setItem("fratello_tickets_memoria", JSON.stringify(ticketsMemoria));
}

function ticketsMemoriaParaFecha(fecha) {
  sincronizarMemoriaTickets();

  return ticketsMemoria
    .filter(ticket => ticket.fechaTicket === fecha)
    .map(ticket => ({
      ...ticket,
      esPedidoHoy: ticket.tipoTicket === "hoy"
    }))
    .sort((a, b) => {
      const entregadoA = Boolean(a.entregado || a.entregaConfirmada);
      const entregadoB = Boolean(b.entregado || b.entregaConfirmada);
      if (entregadoA !== entregadoB) return entregadoA ? -1 : 1;
      return String(a.cliente || "").localeCompare(String(b.cliente || ""), "es");
    });
}

function pedidosTicketParaFecha(fecha) {
  return ticketsMemoriaParaFecha(fecha);
}

function fechasDisponiblesTickets() {
  sincronizarMemoriaTickets();
  return [...new Set(
    ticketsMemoria.map(ticket => ticket.fechaTicket).filter(Boolean)
  )].sort();
}

function etiquetaFechaTickets(fecha) {
  const d = new Date(fecha + "T12:00:00");
  const nombre = d.toLocaleDateString("es-AR", {
    weekday: "long",
    day: "2-digit",
    month: "2-digit"
  });
  return nombre.charAt(0).toUpperCase() + nombre.slice(1);
}

function mostrarPestanaTickets(pestana) {
  const esSemana = pestana !== "pendientes";
  $("vistaTicketsSemana")?.classList.toggle("hidden", !esSemana);
  $("vistaTicketsPendientes")?.classList.toggle("hidden", esSemana);
  $("btnTicketsSemanaActual")?.classList.toggle("active", esSemana);
  $("btnTicketsPendientes")?.classList.toggle("active", !esSemana);
}

let fechaTicketAbierta = "";

function htmlPanelTicketsFechas(fechas, fechaAbierta = "") {
  if (!fechas.length) {
    return '<p class="weeklyEmpty">No hay tickets en esta sección.</p>';
  }

  return fechas.map((fecha, indice) => {
    const lista = pedidosTicketParaFecha(fecha);

    return `<details class="ticketDayPanel" data-ticket-fecha="${fecha}" ${fechaAbierta === fecha ? "open" : ""}>
      <summary>
        <span>${etiquetaFechaTickets(fecha)}</span>
        <span class="weeklyCount">${lista.length}</span>
      </summary>
      <div class="ticketDayBody">
        ${lista.map(pedido => {
          const tipo = "archivo";
          return `<article class="ticketClientRow ${(pedido.entregado || pedido.entregaConfirmada) ? "isDelivered" : ""}">
            <div>
              <strong>${escaparHtmlCatalogo(pedido.cliente || "Cliente")}</strong>
              <small>${pedido.esPedidoHoy ? `Pedido de hoy${pedido.horaEntrega ? ` · ${pedido.horaEntrega}` : ""}` : etiquetaOrigenPedido(pedido)}${(pedido.entregado || pedido.entregaConfirmada) ? " · ✅ Entregado" : " · ⏳ Pendiente"}</small>
            </div>
            <div class="ticketClientActions">
              <button type="button" class="primary" onclick="abrirEntregaTicket('${pedido.claveMemoria}')">📦 Entrega / cobro</button>
              <button type="button" onclick="verTicketIndividual('${tipo}', '${pedido.claveMemoria}')">👁 Ver</button>
              <button type="button" onclick="imprimirTicketIndividual('${tipo}', '${pedido.claveMemoria}')">🖨 Imprimir</button>
              <button type="button" onclick="guardarTicketIndividualJpg('${tipo}', '${pedido.claveMemoria}')">🖼 JPG</button>
            </div>
          </article>`;
        }).join("")}
        <div class="ticketDayFooter">
          <button type="button" class="ticketRepairButtonV422" onclick="repararPedidosYTicketsDelDia('${fecha}')">🧹 Reparar pedidos y tickets</button>
          <button type="button" class="primary" onclick="imprimirTicketsDelDia('${fecha}')">🖨 Imprimir todos los tickets de ${etiquetaFechaTickets(fecha)}</button>
          <button type="button" onclick="guardarTicketsDelDiaJpg('${fecha}')">🖼 Guardar todos en JPG</button>
          <button type="button" onclick="descargarTicketsDelDiaPdf('${fecha}')">📄 Descargar todos en PDF</button>
        </div>
      </div>
    </details>`;
  }).join("");
}

function renderTicketsPorDia() {
  const panelSemana = $("panelTicketsPorDia");
  const panelPendientes = $("panelTicketsPendientes");
  if (!panelSemana && !panelPendientes) return;

  sincronizarMemoriaTickets();

  const limites = limitesSemanaTickets();
  const fechas = fechasDisponiblesTickets();
  const fechasSemana = fechas.filter(
    fecha => fecha >= limites.inicio && fecha <= limites.fin
  );
  const fechasPendientes = fechas.filter(fecha => fecha < limites.inicio);

  if (panelSemana) panelSemana.innerHTML = htmlPanelTicketsFechas(fechasSemana, fechaTicketAbierta);
  if (panelPendientes) panelPendientes.innerHTML = htmlPanelTicketsFechas(fechasPendientes.reverse(), fechaTicketAbierta);

  [panelSemana, panelPendientes].filter(Boolean).forEach(panel => {
    if (panel.dataset.ticketToggleInstalado === "1") return;
    panel.dataset.ticketToggleInstalado = "1";
    panel.addEventListener("toggle", evento => {
      const detalle = evento.target.closest?.(".ticketDayPanel");
      if (!detalle) return;
      if (detalle.open) {
        fechaTicketAbierta = detalle.dataset.ticketFecha || "";
        panel.querySelectorAll(".ticketDayPanel[open]").forEach(otro => {
          if (otro !== detalle) otro.removeAttribute("open");
        });
      } else if (fechaTicketAbierta === detalle.dataset.ticketFecha) {
        fechaTicketAbierta = "";
      }
    }, true);
  });

  const cantidadSemana = fechasSemana.reduce(
    (total, fecha) => total + pedidosTicketParaFecha(fecha).length,
    0
  );
  const cantidadPendientes = fechasPendientes.reduce(
    (total, fecha) => total + pedidosTicketParaFecha(fecha).length,
    0
  );

  if ($("badgeTicketsSemana")) $("badgeTicketsSemana").textContent = String(cantidadSemana);
  if ($("badgeTicketsPendientes")) $("badgeTicketsPendientes").textContent = String(cantidadPendientes);

  if ($("rangoSemanaTickets")) {
    const inicio = new Date(limites.inicio + "T12:00:00").toLocaleDateString("es-AR");
    const fin = new Date(limites.fin + "T12:00:00").toLocaleDateString("es-AR");
    $("rangoSemanaTickets").textContent = `Semana actual: ${inicio} al ${fin}`;
  }
}

function buscarPedidoTicket(tipo, id) {
  if (tipo === "archivo") {
    sincronizarMemoriaTickets();
    return ticketsMemoria.find(
      ticket => String(ticket.claveMemoria) === String(id)
    ) || null;
  }

  const lista = tipo === "hoy" ? pedidosHoy : pedidos;
  return lista.find(pedido => Number(pedido.id) === Number(id)) || null;
}

function cargarCanvasTickets(lista) {
  const canvas = $("canvasPedidosImpresion");
  if (!canvas || !Array.isArray(lista) || !lista.length) return false;

  ticketsSeleccionadosActuales = [...lista];
  const tickets = lista.map(datosTicketPedido);
  const ctx = canvas.getContext("2d");

  if (tickets.length === 1) {
    const ticket = tickets[0];
    const individual = crearCanvasTicketIndividual(ticket, 640);
    canvas.width = individual.width;
    canvas.height = individual.height;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(individual, 0, 0);
    canvas.dataset.ticketIndividual = "1";
    return true;
  }

  canvas.dataset.ticketIndividual = "0";
  const W = 1400;
  const cols = 2;
  const cellW = W / cols;
  const alturas = tickets.map(ticket => calcularAltoTicket(ticket, cellW - 16));
  const rows = Math.ceil(tickets.length / cols);
  const cellH = Math.max(900, ...alturas) + 16;

  canvas.width = W;
  canvas.height = Math.max(cellH, rows * cellH);
  ctx.fillStyle = "#fff";
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  tickets.forEach((ticket, i) =>
    dibujarTicketEnCanvas(
      ctx,
      ticket,
      (i % cols) * cellW + 8,
      Math.floor(i / cols) * cellH + 8,
      cellW - 16,
      calcularAltoTicket(ticket, cellW - 16),
      String(ticket.id).slice(-6)
    )
  );

  return true;
}

function verTicketIndividual(tipo, id) {
  const pedido = buscarPedidoTicket(tipo, id);
  if (!pedido) {
    alert("No se encontró el pedido.");
    return;
  }

  ticketsSeleccionadosActuales = [pedido];

  if (!cargarCanvasTickets(ticketsSeleccionadosActuales)) {
    alert("No se pudo preparar el ticket.");
    return;
  }

  abrirModalImpresion();
}

function imprimirListaTickets(lista) {
  if (!lista.length) {
    alert("No hay tickets para imprimir.");
    return;
  }

  const imgs = lista.map(pedido =>
    crearCanvasTicketIndividual(datosTicketPedido(pedido)).toDataURL("image/jpeg", 0.92)
  );

  const ventana = window.open("", "_blank");
  if (!ventana) {
    alert("Permití ventanas emergentes para imprimir.");
    return;
  }

  ventana.document.write(`
    <html>
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <style>
          @page { size: 58mm 210mm; margin: 1mm; }
          * { box-sizing: border-box; }
          html, body {
            margin: 0;
            padding: 0;
            width: 56mm;
            background: #fff;
          }
          .sheet {
            width: 56mm;
            display: block;
            margin: 0;
            padding: 0;
          }
          .ticket {
            display: block;
            width: 56mm;
            max-width: 54mm;
            height: auto;
            margin: 0 0 2mm 0;
            object-fit: contain;
            break-inside: avoid;
            page-break-inside: avoid;
          }
          @media screen {
            html, body { width: 58mm; }
            .sheet { width: 54mm; margin: 0 auto; }
          }
          @media print {
            html, body, .sheet { width: 56mm !important; }
            .ticket { width: 56mm !important; max-width: 56mm !important; }
          }
        </style>
      </head>
      <body>
        <div class="sheet">${imgs.map(src => `<img class="ticket" src="${src}">`).join("")}</div>
        <script>window.addEventListener("load",()=>setTimeout(()=>window.print(),400));<\/script>
      </body>
    </html>
  `);
  ventana.document.close();
}

function imprimirTicketIndividual(tipo, id) {
  const pedido = buscarPedidoTicket(tipo, id);
  if (!pedido) return alert("No se encontró el pedido.");
  imprimirListaTickets([pedido]);
}

function imprimirTicketsDelDia(fecha) {
  const lista = pedidosTicketParaFecha(fecha);
  imprimirListaTickets(lista);
}

async function guardarTicketIndividualJpg(tipo, id) {
  const pedido = buscarPedidoTicket(tipo, id);
  if (!pedido) return alert("No se encontró el pedido.");

  const ticket = datosTicketPedido(pedido);
  const canvas = crearCanvasTicketIndividual(ticket);
  const blob = await new Promise(resolve => canvas.toBlob(resolve, "image/jpeg", 0.95));
  if (!blob) return alert("No se pudo generar la imagen.");

  await descargarBlobCompatible(
    blob,
    `ticket-fratello-${nombreArchivoSeguro(ticket.cliente)}-${ticket.fecha}.jpg`,
    `Ticket de ${ticket.cliente}`
  );
}

async function guardarTicketsDelDiaJpg(fecha) {
  const lista = pedidosTicketParaFecha(fecha);
  if (!lista.length) return alert("No hay tickets para ese día.");

  cargarCanvasTickets(lista);
  await guardarImagenPedidos();
}

function descargarTicketsDelDiaPdf(fecha) {
  const lista = pedidosTicketParaFecha(fecha);
  if (!lista.length) return alert("No hay tickets para ese día.");

  const J = obtenerJsPDF();
  if (!J) return alert("No se pudo cargar el generador de PDF.");

  const doc = new J({ orientation: "portrait", unit: "mm", format: "a4" });
  const ancho = 62, margen = 6, espacio = 4;
  let x = margen, y = margen, columna = 0, altoFila = 0;

  lista.map(datosTicketPedido).forEach((ticket, indice) => {
    const canvas = crearCanvasTicketIndividual(ticket);
    const alto = ancho * canvas.height / canvas.width;

    if (columna === 0 && y + alto > 291) {
      doc.addPage();
      y = margen;
    }

    agregarTicketPdf(doc, ticket, x, y, ancho);
    altoFila = Math.max(altoFila, alto);
    columna++;

    if (columna === 3) {
      columna = 0;
      x = margen;
      y += altoFila + espacio;
      altoFila = 0;
      if (indice < lista.length - 1 && y + 80 > 291) {
        doc.addPage();
        y = margen;
      }
    } else {
      x = margen + columna * (ancho + espacio);
    }
  });

  doc.save(`tickets-fratello-${fecha}.pdf`);
}

function datosTicketPedido(pedido) {
  const dc = datosClientesCompletos[pedido.cliente] || {};
  const lista = listaPrecioCliente(pedido.cliente);
  const itemsBase = pedido.entregaConfirmada && Array.isArray(pedido.entregaItems)
    ? pedido.entregaItems
    : pedido.items;

  const itemsOrigen = Array.isArray(itemsBase) && itemsBase.length
    ? itemsBase
    : procesarTextoPedido(
        pedido.textoOriginal || pedido.texto || "",
        pedido.cliente || "Cliente",
        pedido.fechaEntrega || pedido.fecha || pedido.jornada || fechaOperativaActual()
      );

  const items = itemsOrigen
    .filter(i => i.estado !== "NO PEDIDO")
    .map(item => {
      const p = productoPorId(item.productoId);
      const precioUnitario = precioUnitarioItem(p, item.unidad, pedido.cliente);
      return {
        descripcion: p?.nombre || item.producto || "Producto",
        cantidad: Number(item.cantidad || 0),
        unidad: normalizarUnidadPrecio(item.unidad),
        precioUnitario,
        total: Number(item.cantidad || 0) * precioUnitario
      };
    });

  return {
    id: pedido.id,
    cliente: pedido.cliente || "Sin cliente",
    fecha: pedido.fechaEntrega || pedido.fecha || pedido.jornada || $("fechaPedido")?.value || hoyISO(),
    horaEntrega: pedido.horaEntrega || "",
    direccion: dc.direccion || "",
    barrio: dc.barrio || "",
    listaPrecio: lista,
    listaPrecioNombre: etiquetaListaPrecio(lista),
    items,
    total: items.reduce((a, i) => a + i.total, 0),
    entregaConfirmada: Boolean(pedido.entregaConfirmada),
    observacionEntrega: pedido.observacionEntrega || "",
    saldoAnterior: saldoAnteriorTicket(pedido),
    pagoHoy: pagoTicketActual(pedido),
    saldoFinal: saldoFinalTicket(pedido)
  };
}

function formatoDineroTicket(valor) {
  return new Intl.NumberFormat("es-AR", {
    style: "currency", currency: "ARS", maximumFractionDigits: 0
  }).format(Number(valor || 0));
}

function nombreArchivoSeguro(texto) {
  return String(texto || "cliente").normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "").replace(/[^a-zA-Z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "").toLowerCase();
}

function cortarTextoCanvas(ctx, texto, maxWidth) {
  const palabras = String(texto || "").split(/\s+/);
  const lineas = [];
  let linea = "";
  palabras.forEach(p => {
    const prueba = linea ? `${linea} ${p}` : p;
    if (ctx.measureText(prueba).width <= maxWidth) linea = prueba;
    else { if (linea) lineas.push(linea); linea = p; }
  });
  if (linea) lineas.push(linea);
  return lineas.length ? lineas : [""];
}

function calcularAltoTicket(t, a = 640) {
  const altoItems = (t.items || []).reduce(
    (total, item) => total + (String(item.descripcion || "").length > 25 ? 105 : 82),
    0
  );
  const altoDireccion = t.direccion || t.barrio ? 125 : 55;
  const altoCuenta = 205;
  const altoObservacion = t.observacionEntrega ? 85 : 0;
  return Math.max(980, 610 + altoItems + altoDireccion + altoCuenta + altoObservacion);
}

function dibujarTicketEnCanvas(ctx, t, x, y, a, h, n = "") {
  const p = 26;
  const l = x + p;
  const r = x + a - p;
  let yy = y + 38;

  ctx.save();
  ctx.fillStyle = "#fff";
  ctx.fillRect(x, y, a, h);
  ctx.strokeStyle = "#111";
  ctx.lineWidth = 2;
  ctx.strokeRect(x + 1, y + 1, a - 2, h - 2);
  ctx.fillStyle = "#111";

  ctx.textAlign = "center";
  ctx.font = "bold 38px Arial";
  ctx.fillText("PANADERÍA FRATELLO", x + a / 2, yy);
  yy += 43;
  ctx.font = "22px Arial";
  ctx.fillText(t.entregaConfirmada ? "COMPROBANTE DE ENTREGA" : "PEDIDO / TICKET DE ENTREGA", x + a / 2, yy);
  yy += 38;

  ctx.setLineDash([8, 5]);
  ctx.beginPath(); ctx.moveTo(l, yy); ctx.lineTo(r, yy); ctx.stroke();
  ctx.setLineDash([]);
  yy += 34;

  ctx.textAlign = "left";
  ctx.font = "bold 31px Arial";
  ctx.fillText(`Cliente: ${t.cliente}`, l, yy);
  yy += 32;
  ctx.font = "22px Arial";
  ctx.fillText(
    `Fecha: ${new Date(t.fecha + "T12:00:00").toLocaleDateString("es-AR")}${t.horaEntrega ? ` · Entrega ${t.horaEntrega}` : ""}`,
    l, yy
  );
  ctx.textAlign = "right";
  ctx.fillText(`Pedido Nº ${n}`, r, yy);
  yy += 30;

  ctx.textAlign = "left";
  ctx.font = "bold 20px Arial";
  ctx.fillText(`Lista de precios: ${t.listaPrecioNombre || "Cliente"}`, l, yy);
  yy += 22;

  ctx.setLineDash([8, 5]);
  ctx.beginPath(); ctx.moveTo(l, yy); ctx.lineTo(r, yy); ctx.stroke();
  ctx.setLineDash([]);
  yy += 24;

  ctx.font = "bold 21px Arial";
  ctx.textAlign = "left";
  ctx.fillText("DESCRIPCIÓN", l, yy);
  yy += 22;
  ctx.font = "bold 20px Arial";
  ctx.fillText("CANT.", l, yy);
  ctx.textAlign = "right";
  ctx.fillText("P. UNIT.", x + a * .70, yy);
  ctx.fillText("TOTAL", r, yy);
  yy += 16;
  ctx.beginPath(); ctx.moveTo(l, yy); ctx.lineTo(r, yy); ctx.stroke();
  yy += 24;

  for (const i of t.items || []) {
    ctx.textAlign = "left";
    ctx.font = "bold 30px Arial";
    const lineas = cortarTextoCanvas(ctx, i.descripcion, a - p * 2).slice(0, 2);
    lineas.forEach((linea, j) => ctx.fillText(linea, l, yy + j * 27));
    yy += lineas.length * 27 + 10;

    ctx.font = "22px Arial";
    ctx.fillText(`${fmt(i.cantidad)} ${i.unidad}`, l, yy);
    ctx.textAlign = "right";
    ctx.fillText(i.precioUnitario > 0 ? formatoDineroTicket(i.precioUnitario) : "Sin precio", x + a * .70, yy);
    ctx.fillText(i.precioUnitario > 0 ? formatoDineroTicket(i.total) : "—", r, yy);
    yy += 27;

    ctx.strokeStyle = "#bbb";
    ctx.setLineDash([4, 4]);
    ctx.beginPath(); ctx.moveTo(l, yy); ctx.lineTo(r, yy); ctx.stroke();
    ctx.setLineDash([]);
    ctx.strokeStyle = "#111";
    yy += 25;
  }

  ctx.lineWidth = 3;
  ctx.beginPath(); ctx.moveTo(l, yy); ctx.lineTo(r, yy); ctx.stroke();
  yy += 34;
  ctx.font = "bold 30px Arial";
  ctx.textAlign = "left";
  ctx.fillText("COMPRA DE HOY", l, yy);
  ctx.textAlign = "right";
  ctx.fillText(formatoDineroTicket(t.total), r, yy);
  yy += 32;

  ctx.lineWidth = 1;
  ctx.font = "22px Arial";
  ctx.textAlign = "left";
  ctx.fillText("Saldo anterior", l, yy);
  ctx.textAlign = "right";
  ctx.fillText(formatoDineroTicket(t.saldoAnterior), r, yy);
  yy += 25;

  if (Number(t.pagoHoy || 0) > 0) {
    ctx.textAlign = "left";
    ctx.fillText("Pago recibido", l, yy);
    ctx.textAlign = "right";
    ctx.fillText(`- ${formatoDineroTicket(t.pagoHoy)}`, r, yy);
    yy += 25;
  }

  ctx.lineWidth = 3;
  ctx.beginPath(); ctx.moveTo(l, yy); ctx.lineTo(r, yy); ctx.stroke();
  yy += 34;
  ctx.font = "bold 31px Arial";
  ctx.textAlign = "left";
  ctx.fillText("TOTAL PENDIENTE", l, yy);
  ctx.textAlign = "right";
  ctx.fillText(formatoDineroTicket(t.saldoFinal), r, yy);
  yy += 34;

  if (t.observacionEntrega) {
    ctx.setLineDash([8, 5]);
    ctx.beginPath(); ctx.moveTo(l, yy); ctx.lineTo(r, yy); ctx.stroke();
    ctx.setLineDash([]);
    yy += 24;
    ctx.textAlign = "left";
    ctx.font = "bold 21px Arial";
    ctx.fillText("OBSERVACIÓN DE ENTREGA", l, yy);
    yy += 21;
    ctx.font = "22px Arial";
    cortarTextoCanvas(ctx, t.observacionEntrega, a - p * 2).slice(0, 2).forEach(linea => {
      ctx.fillText(linea, l, yy);
      yy += 19;
    });
  }

  ctx.setLineDash([8, 5]);
  ctx.beginPath(); ctx.moveTo(l, yy); ctx.lineTo(r, yy); ctx.stroke();
  ctx.setLineDash([]);
  yy += 28;

  ctx.textAlign = "left";
  ctx.font = "bold 23px Arial";
  ctx.fillText("DIRECCIÓN DE ENTREGA", l, yy);
  yy += 24;
  ctx.font = "22px Arial";
  if (t.direccion) {
    cortarTextoCanvas(ctx, t.direccion, a - p * 2).forEach(linea => {
      ctx.fillText(linea, l, yy);
      yy += 20;
    });
  } else {
    ctx.fillText("Sin dirección cargada", l, yy);
    yy += 20;
  }
  if (t.barrio) {
    ctx.fillText(`Barrio: ${t.barrio}`, l, yy);
    yy += 22;
  }

  yy += 12;
  ctx.textAlign = "center";
  ctx.font = "22px Arial";
  ctx.fillText("Gracias por elegir Panadería Fratello", x + a / 2, yy);
  ctx.restore();
}

function crearCanvasTicketIndividual(t,a=640){const h=calcularAltoTicket(t,a),c=document.createElement("canvas");c.width=a;c.height=h;dibujarTicketEnCanvas(c.getContext("2d"),t,0,0,a,h,String(t.id).slice(-6));return c;}


const CUENTA_CORRIENTE_KEY_V42 = "fratello_cuenta_corriente_v42";
let cuentaCorrienteV42 = JSON.parse(localStorage.getItem(CUENTA_CORRIENTE_KEY_V42) || "[]");

function guardarCuentaCorrienteV42() {
  localStorage.setItem(CUENTA_CORRIENTE_KEY_V42, JSON.stringify(cuentaCorrienteV42));
  if (typeof guardarEnNube === "function") guardarEnNube();
}

function movimientosClienteV42(cliente) {
  return (Array.isArray(cuentaCorrienteV42) ? cuentaCorrienteV42 : [])
    .filter(m => String(m.cliente || "") === String(cliente || ""))
    .sort((a, b) =>
      String(a.fecha || "").localeCompare(String(b.fecha || "")) ||
      String(a.creado || "").localeCompare(String(b.creado || ""))
    );
}

function saldoClienteV42(cliente, excluirClave = "") {
  return movimientosClienteV42(cliente).reduce((saldo, mov) => {
    if (excluirClave && mov.claveTicket === excluirClave) return saldo;
    return saldo + Number(mov.cargo || 0) - Number(mov.pago || 0);
  }, 0);
}

function movimientoTicketV42(pedido) {
  const clave = pedido?.claveMemoria || claveTicketMemoria(pedido, pedido?.tipoTicket || "normal");
  return cuentaCorrienteV42.find(m => m.claveTicket === clave) || null;
}

function saldoAnteriorTicket(pedido) {
  const clave = pedido?.claveMemoria || claveTicketMemoria(pedido, pedido?.tipoTicket || "normal");
  return Math.max(0, saldoClienteV42(pedido?.cliente, clave));
}

function pagoTicketActual(pedido) {
  return Number(movimientoTicketV42(pedido)?.pago || pedido?.pagoEntrega || 0);
}

function saldoFinalTicket(pedido) {
  const anterior = saldoAnteriorTicket(pedido);
  const compra = pedido?.entregaConfirmada
    ? totalEntregaPedidoV42(pedido)
    : datosTicketTotalOriginalV42(pedido);
  return Math.max(0, anterior + compra - pagoTicketActual(pedido));
}

function datosTicketTotalOriginalV42(pedido) {
  const items = Array.isArray(pedido?.items) ? pedido.items : [];
  return items
    .filter(item => item.estado !== "NO PEDIDO")
    .reduce((total, item) => {
      const producto = productoPorId(item.productoId);
      return total + Number(item.cantidad || 0) *
        Number(precioUnitarioItem(producto, item.unidad, pedido.cliente) || 0);
    }, 0);
}

function totalEntregaPedidoV42(pedido) {
  const items = Array.isArray(pedido?.entregaItems) ? pedido.entregaItems : [];
  return items
    .filter(item => item.estado !== "NO PEDIDO" && Number(item.cantidad || 0) > 0)
    .reduce((total, item) => {
      const producto = productoPorId(item.productoId);
      return total + Number(item.cantidad || 0) *
        Number(precioUnitarioItem(producto, item.unidad, pedido.cliente) || 0);
    }, 0);
}

function asegurarModalEntregaV42() {
  if ($("modalEntregaTicketV42")) return;

  const modal = document.createElement("div");
  modal.id = "modalEntregaTicketV42";
  modal.className = "deliveryModalV42 hidden";
  modal.innerHTML = `
    <div class="deliveryModalCardV42">
      <button type="button" class="deliveryCloseV42" onclick="cerrarEntregaTicketV42()">×</button>
      <div id="contenidoEntregaTicketV42"></div>
    </div>`;
  document.body.appendChild(modal);

  modal.addEventListener("click", evento => {
    if (evento.target === modal) cerrarEntregaTicketV42();
  });
}

function abrirEntregaTicket(clave) {
  sincronizarMemoriaTickets();
  const pedido = ticketsMemoria.find(t => String(t.claveMemoria) === String(clave));
  if (!pedido) return alert("No se encontró el ticket.");

  asegurarModalEntregaV42();
  const items = (pedido.entregaConfirmada && Array.isArray(pedido.entregaItems)
    ? pedido.entregaItems
    : pedido.items || []
  ).filter(item => item.estado !== "NO PEDIDO");

  const saldoAnterior = saldoAnteriorTicket(pedido);
  const pagoActual = pagoTicketActual(pedido);

  $("contenidoEntregaTicketV42").innerHTML = `
    <header class="deliveryHeaderV42">
      <div>
        <span class="deliveryEyebrowV42">Entrega real</span>
        <h2>${escaparHtmlCatalogo(pedido.cliente || "Cliente")}</h2>
        <p>El pedido original no se modifica. Acá registrás únicamente lo que realmente salió.</p>
      </div>
      <span class="deliveryStatusV42">${pedido.entregaConfirmada ? "✅ Entrega guardada" : "Pendiente"}</span>
    </header>

    <input type="hidden" id="entregaClaveV42" value="${escaparHtmlCatalogo(clave)}">

    <div class="deliveryItemsV42">
      ${items.map((item, indice) => {
        const producto = productoPorId(item.productoId);
        const precio = precioUnitarioItem(producto, item.unidad, pedido.cliente);
        const original = (pedido.items || []).find(i =>
          String(i.itemId || "") === String(item.itemId || "") ||
          String(i.productoId || "") === String(item.productoId || "")
        );
        return `
          <article class="deliveryItemV42" data-index="${indice}">
            <div>
              <strong>${escaparHtmlCatalogo(producto?.nombre || item.producto || "Producto")}</strong>
              <small>Pedido: ${fmt(Number(original?.cantidad ?? item.cantidad ?? 0))} ${escaparHtmlCatalogo(item.unidad || "")} · ${formatoDineroTicket(precio)} c/u</small>
            </div>
            <label>
              Entregado
              <input class="entregaCantidadV42" type="number" min="0" step="0.01"
                value="${Number(item.cantidad || 0)}"
                data-item='${escaparHtmlCatalogo(JSON.stringify(item))}'>
            </label>
            <button type="button" onclick="marcarNoEntregadoV42(this)">No se llevó</button>
          </article>`;
      }).join("")}
    </div>

    <div class="deliverySummaryV42">
      <label>
        Observación
        <textarea id="entregaObservacionV42" rows="2" placeholder="Ej.: faltaron 2 kg de pan">${escaparHtmlCatalogo(pedido.observacionEntrega || "")}</textarea>
      </label>
      <div class="deliveryAccountV42">
        <div><span>Saldo anterior</span><strong>${formatoDineroTicket(saldoAnterior)}</strong></div>
        <div><span>Entrega de hoy</span><strong id="entregaTotalV42">$ 0</strong></div>
        <label>
          Pago recibido hoy
          <input id="entregaPagoV42" type="number" min="0" step="1" value="${pagoActual}">
        </label>
        <div class="deliveryGrandV42"><span>Saldo final estimado</span><strong id="entregaSaldoFinalV42">$ 0</strong></div>
      </div>
    </div>

    <div class="deliveryActionsV42">
      <button type="button" onclick="cerrarEntregaTicketV42()">Cancelar</button>
      <button type="button" class="primary" onclick="guardarEntregaTicketV42()">Guardar entrega y actualizar ticket</button>
    </div>`;

  $("modalEntregaTicketV42").classList.remove("hidden");
  $("modalEntregaTicketV42").querySelectorAll(".entregaCantidadV42, #entregaPagoV42").forEach(campo => {
    campo.addEventListener("input", recalcularEntregaV42);
  });
  recalcularEntregaV42();
}

function marcarNoEntregadoV42(boton) {
  const input = boton.closest(".deliveryItemV42")?.querySelector(".entregaCantidadV42");
  if (input) {
    input.value = "0";
    recalcularEntregaV42();
  }
}

function cerrarEntregaTicketV42() {
  $("modalEntregaTicketV42")?.classList.add("hidden");
}

function itemsFormularioEntregaV42() {
  return [...document.querySelectorAll(".entregaCantidadV42")].map(input => {
    let base = {};
    try { base = JSON.parse(input.dataset.item || "{}"); } catch {}
    return {
      ...base,
      cantidad: Math.max(0, Number(input.value || 0)),
      estado: Number(input.value || 0) > 0 ? (base.estado || "OK") : "NO ENTREGADO"
    };
  });
}

function totalFormularioEntregaV42() {
  const clave = $("entregaClaveV42")?.value || "";
  const pedido = ticketsMemoria.find(t => String(t.claveMemoria) === String(clave));
  if (!pedido) return 0;

  return itemsFormularioEntregaV42().reduce((total, item) => {
    if (Number(item.cantidad || 0) <= 0) return total;
    const producto = productoPorId(item.productoId);
    const precio = precioUnitarioItem(producto, item.unidad, pedido.cliente);
    return total + Number(item.cantidad || 0) * Number(precio || 0);
  }, 0);
}

function recalcularEntregaV42() {
  const clave = $("entregaClaveV42")?.value || "";
  const pedido = ticketsMemoria.find(t => String(t.claveMemoria) === String(clave));
  if (!pedido) return;

  const total = totalFormularioEntregaV42();
  const anterior = saldoAnteriorTicket(pedido);
  const pago = Math.max(0, Number($("entregaPagoV42")?.value || 0));
  const saldo = Math.max(0, anterior + total - pago);

  if ($("entregaTotalV42")) $("entregaTotalV42").textContent = formatoDineroTicket(total);
  if ($("entregaSaldoFinalV42")) $("entregaSaldoFinalV42").textContent = formatoDineroTicket(saldo);
}

function actualizarPedidoOrigenEntregaV42(ticketActualizado) {
  [pedidos, pedidosHoy].forEach(lista => {
    const pedido = lista.find(p => Number(p.id) === Number(ticketActualizado.id));
    if (!pedido) return;
    pedido.entregaConfirmada = ticketActualizado.entregaConfirmada;
    pedido.entregaItems = ticketActualizado.entregaItems;
    pedido.observacionEntrega = ticketActualizado.observacionEntrega;
    pedido.pagoEntrega = ticketActualizado.pagoEntrega;
    pedido.entregado = true;
  });

  if (typeof guardarPedidos === "function") guardarPedidos();
  if (typeof guardarPedidosHoy === "function") guardarPedidosHoy();
}

function guardarEntregaTicketV42() {
  const clave = $("entregaClaveV42")?.value || "";
  const pedido = ticketsMemoria.find(t => String(t.claveMemoria) === String(clave));
  if (!pedido) return alert("No se encontró el ticket.");

  const entregaItems = itemsFormularioEntregaV42();
  const total = totalFormularioEntregaV42();
  const pago = Math.max(0, Number($("entregaPagoV42")?.value || 0));
  const observacion = $("entregaObservacionV42")?.value.trim() || "";

  pedido.entregaConfirmada = true;
  pedido.entregaItems = entregaItems;
  pedido.observacionEntrega = observacion;
  pedido.pagoEntrega = pago;
  pedido.entregado = true;
  pedido.fechaEntregaReal = new Date().toISOString();

  const existente = cuentaCorrienteV42.findIndex(m => m.claveTicket === clave);
  const movimiento = {
    id: existente >= 0 ? cuentaCorrienteV42[existente].id : Date.now(),
    claveTicket: clave,
    cliente: pedido.cliente,
    fecha: pedido.fechaTicket || pedido.fechaEntrega || hoyISO(),
    cargo: total,
    pago,
    observacion,
    creado: existente >= 0 ? cuentaCorrienteV42[existente].creado : new Date().toISOString(),
    actualizado: new Date().toISOString()
  };

  if (existente >= 0) cuentaCorrienteV42[existente] = movimiento;
  else cuentaCorrienteV42.push(movimiento);

  actualizarPedidoOrigenEntregaV42(pedido);
  guardarMemoriaTickets();
  guardarCuentaCorrienteV42();
  renderTicketsPorDia();
  cerrarEntregaTicketV42();

  alert(`Entrega guardada.\n\nCompra de hoy: ${formatoDineroTicket(total)}\nPago recibido: ${formatoDineroTicket(pago)}\nSaldo final: ${formatoDineroTicket(saldoFinalTicket(pedido))}`);
}


function avisarPreciosFaltantes(lista=pedidos) {
  const faltantes=new Set();
  lista.forEach(p=>(p.items||[]).forEach(i=>{
    if(i.estado==="NO PEDIDO")return;
    const prod=productoPorId(i.productoId);
    if(precioUnitarioItem(prod,i.unidad,p.cliente)<=0)faltantes.add(prod?.nombre||i.producto);
  }));
  if(faltantes.size)alert("El ticket se generará, pero faltan precios para:\n\n"+[...faltantes].slice(0,12).join("\n")+"\n\nCargalos desde Administrar productos predeterminados.");
}

async function generarVistaPedidos() {
  renderTicketsPorDia();
  abrirSeccionFratello("seccionTickets");
}

function obtenerJsPDF(){return window.jspdf?.jsPDF||null;}

function agregarTicketPdf(doc,t,x,y,a){const c=crearCanvasTicketIndividual(t),h=a*c.height/c.width;doc.addImage(c.toDataURL("image/jpeg",.95),"JPEG",x,y,a,h,undefined,"FAST");return h;}
function descargarPdfPedidos() {
  const lista = Array.isArray(ticketsSeleccionadosActuales)
    ? ticketsSeleccionadosActuales
    : [];

  if (!lista.length) {
    alert("Primero abrí un ticket o elegí un día.");
    return;
  }

  const J = obtenerJsPDF();
  if (!J) {
    alert("No se pudo cargar el generador de PDF.");
    return;
  }

  if (lista.length === 1) {
    const ticket = datosTicketPedido(lista[0]);
    const canvas = crearCanvasTicketIndividual(ticket);
    const ancho = 80;
    const alto = Math.max(100, ancho * canvas.height / canvas.width);
    const doc = new J({ orientation: "portrait", unit: "mm", format: [ancho, alto] });
    doc.addImage(canvas.toDataURL("image/jpeg", 0.96), "JPEG", 0, 0, ancho, alto, undefined, "FAST");
    doc.save(`ticket-fratello-${nombreArchivoSeguro(ticket.cliente)}-${ticket.fecha}.pdf`);
    return;
  }

  const doc = new J({ orientation: "portrait", unit: "mm", format: "a4" });
  const ancho = 62, margen = 6, espacio = 4;
  let x = margen, y = margen, columna = 0, altoFila = 0;

  lista.map(datosTicketPedido).forEach((ticket, indice) => {
    const canvas = crearCanvasTicketIndividual(ticket);
    const alto = ancho * canvas.height / canvas.width;

    if (columna === 0 && y + alto > 291) {
      doc.addPage();
      y = margen;
    }

    agregarTicketPdf(doc, ticket, x, y, ancho);
    altoFila = Math.max(altoFila, alto);
    columna++;

    if (columna === 3) {
      columna = 0;
      x = margen;
      y += altoFila + espacio;
      altoFila = 0;
      if (indice < lista.length - 1 && y + 80 > 291) {
        doc.addPage();
        y = margen;
      }
    } else {
      x = margen + columna * (ancho + espacio);
    }
  });

  doc.save(`tickets-fratello-${hoyISO()}.pdf`);
}
function descargarPdfPedidoIndividual(id){const p=pedidos.find(x=>Number(x.id)===Number(id));if(!p){alert("No se encontró el pedido.");return;}const J=obtenerJsPDF();if(!J){alert("No se pudo cargar el generador de PDF.");return;}avisarPreciosFaltantes([p]);const t=datosTicketPedido(p),c=crearCanvasTicketIndividual(t),a=80,h=Math.max(100,a*c.height/c.width),d=new J({orientation:"portrait",unit:"mm",format:[a,h]});d.addImage(c.toDataURL("image/jpeg",.96),"JPEG",0,0,a,h,undefined,"FAST");d.save(`ticket-fratello-${nombreArchivoSeguro(t.cliente)}-${t.fecha}.pdf`);}


function verTicketPedidoHoy(id) {
  const pedido = pedidosHoy.find(item => Number(item.id) === Number(id));
  if (!pedido) {
    alert("No se encontró el pedido de hoy.");
    return;
  }

  ticketsSeleccionadosActuales = [pedido];

  if (!cargarCanvasTickets([pedido])) {
    alert("No se pudo preparar el ticket.");
    return;
  }

  abrirModalImpresion();
}

function descargarPdfPedidoHoy(id) {
  const pedido = pedidosHoy.find(item => Number(item.id) === Number(id));
  if (!pedido) {
    alert("No se encontró el pedido de hoy.");
    return;
  }

  const J = obtenerJsPDF();
  if (!J) {
    alert("No se pudo cargar el generador de PDF.");
    return;
  }

  const t = datosTicketPedido(pedido);
  const c = crearCanvasTicketIndividual(t);
  const ancho = 80;
  const alto = Math.max(100, ancho * c.height / c.width);
  const doc = new J({ orientation: "portrait", unit: "mm", format: [ancho, alto] });
  doc.addImage(c.toDataURL("image/jpeg", 0.96), "JPEG", 0, 0, ancho, alto, undefined, "FAST");
  doc.save(`ticket-fratello-${nombreArchivoSeguro(t.cliente)}-${t.fecha}.pdf`);
}

async function descargarBlobCompatible(blob, nombreArchivo, titulo = "Ticket Fratello") {
  const archivo = new File([blob], nombreArchivo, { type: blob.type || "image/jpeg" });

  if (navigator.share && navigator.canShare && navigator.canShare({ files: [archivo] })) {
    try {
      await navigator.share({ title: titulo, files: [archivo] });
      return true;
    } catch (error) {
      if (error?.name === "AbortError") return false;
    }
  }

  const url = URL.createObjectURL(blob);
  const enlace = document.createElement("a");
  enlace.href = url;
  enlace.download = nombreArchivo;
  enlace.rel = "noopener";
  document.body.appendChild(enlace);
  enlace.click();
  enlace.remove();

  setTimeout(() => URL.revokeObjectURL(url), 60000);
  return true;
}

async function guardarJpgPedidoHoy(id) {
  const pedido = pedidosHoy.find(item => Number(item.id) === Number(id));
  if (!pedido) {
    alert("No se encontró el pedido de hoy.");
    return;
  }

  const ticket = datosTicketPedido(pedido);
  const canvas = crearCanvasTicketIndividual(ticket);
  const blob = await new Promise(resolve => canvas.toBlob(resolve, "image/jpeg", 0.95));

  if (!blob) {
    alert("No se pudo generar la imagen.");
    return;
  }

  await descargarBlobCompatible(
    blob,
    `ticket-fratello-${nombreArchivoSeguro(ticket.cliente)}-${ticket.fecha}.jpg`,
    `Ticket de ${ticket.cliente}`
  );
}

async function guardarImagenPedidos() {
  const canvas = $("canvasPedidosImpresion");

  if (!canvas || !canvas.width || !canvas.height || !ticketsSeleccionadosActuales.length) {
    alert("Primero abrí un ticket o elegí un día.");
    return;
  }

  const blob = await new Promise(resolve =>
    canvas.toBlob(resolve, "image/jpeg", 0.95)
  );

  if (!blob) {
    alert("No se pudo generar la imagen.");
    return;
  }

  const nombre = ticketsSeleccionadosActuales.length === 1
    ? `ticket-fratello-${nombreArchivoSeguro(datosTicketPedido(ticketsSeleccionadosActuales[0]).cliente)}-${hoyISO()}.jpg`
    : `tickets-fratello-${hoyISO()}.jpg`;

  await descargarBlobCompatible(blob, nombre, "Tickets Fratello");
}
async function compartirImagenPedidos() {
  const canvas = $("canvasPedidosImpresion");

  if (!canvas || !canvas.width || !canvas.height || !ticketsSeleccionadosActuales.length) {
    alert("Primero abrí un ticket o elegí un día.");
    return;
  }

  const blob = await new Promise(resolve =>
    canvas.toBlob(resolve, "image/jpeg", 0.95)
  );

  if (!blob) {
    alert("No se pudo generar la imagen.");
    return;
  }

  const archivo = new File(
    [blob],
    `tickets-fratello-${hoyISO()}.jpg`,
    { type: "image/jpeg" }
  );

  if (navigator.share && navigator.canShare && navigator.canShare({ files: [archivo] })) {
    try {
      await navigator.share({ title: "Tickets Fratello", files: [archivo] });
      return;
    } catch (error) {
      if (error?.name === "AbortError") return;
    }
  }

  await descargarBlobCompatible(blob, archivo.name, "Tickets Fratello");
}
function imprimirImagenPedidos() {
  imprimirListaTickets(ticketsSeleccionadosActuales);
}


function resetDatos() {
  if (!confirm("¿Seguro que querés borrar solo los pedidos cargados?")) return;

  pedidos = [];
  localStorage.setItem("fratello_pedidos", JSON.stringify(pedidos));
      localStorage.setItem("fratello_pedidos_eliminados", JSON.stringify(pedidosEliminados));
  guardarEnNube();

  renderPedidosCargados();
  $("ultimoProcesado").innerHTML = "";
  $("comparador").innerHTML = "";
  $("resumenPanadero").textContent = "";
}


// --- MODO ADMINISTRADOR ÚNICO ---
let usuarioActual = "admin";

function aplicarPermisosUsuario() {
  document.querySelectorAll(".adminOnly").forEach(el => {
    el.style.display = "";
  });

  document.querySelectorAll(".normalOnly").forEach(el => {
    el.style.display = "none";
  });
}



function destildarCasillasConfirmacion() {
  const checkProduccion = $("checkProduccionCompleta");

  if (checkProduccion) checkProduccion.checked = false;
  if (checkPedido) checkPedido.checked = false;
}

function actualizarEstadoConfirmacion() {
  const contenedor = $("estadoConfirmacion");
  if (!contenedor) return;

  const estadoPedidos = estadoConfirmacionFechaSeleccionada();
  const produccionConfirmada = Boolean($("checkProduccionCompleta")?.checked);
  const faltanPedidos = Math.max(
    0,
    estadoPedidos.pedidosFecha.length - estadoPedidos.confirmados.length
  );

  contenedor.classList.remove("estadoListo", "estadoPendiente", "estadoAlerta");

  if (!estadoPedidos.pedidosFecha.length) {
    contenedor.textContent = "🟠 No hay pedidos cargados para el día seleccionado";
    contenedor.classList.add("estadoAlerta");
    return;
  }

  if (!produccionConfirmada || faltanPedidos > 0) {
    const pendientes = [];
    if (!produccionConfirmada) pendientes.push("confirmar producción");
    if (faltanPedidos > 0) pendientes.push(`confirmar ${faltanPedidos} pedido(s)`);

    contenedor.textContent = `🔴 Faltan acciones: ${pendientes.join(" y ")}`;
    contenedor.classList.add("estadoPendiente");
    return;
  }

  contenedor.textContent = "🟢 Jornada lista para calcular y enviar";
  contenedor.classList.add("estadoListo");
}

function confirmarPedidos() {
  const checkProduccion = $("checkProduccionCompleta");
  const estado = sincronizarConfirmacionDiaDesdePedidos();

  if (!estado.pedidosFecha.length) {
    alert("Todavía no hay pedidos cargados para el día seleccionado.");
    return;
  }

  if (!estado.todosConfirmados) {
    const faltan = estado.pedidosFecha.length - estado.confirmados.length;
    alert(`Falta confirmar ${faltan} pedido(s) del día seleccionado.`);
    return;
  }

  if (checkProduccion && !checkProduccion.checked) {
    alert("Falta confirmar la producción del día seleccionado.");
    return;
  }

  const ambiguosUnidad = pedidosConUnidadAmbigua();
  const ambiguosProducto = pedidosConProductoAmbiguo();
  const totalAmbiguos = ambiguosUnidad.length + ambiguosProducto.length;

  if (totalAmbiguos) {
    alert(`Hay ${totalAmbiguos} revisión(es) pendiente(s) de producto o unidad.`);
    return;
  }

  pedidosConfirmados = true;
  guardarTodo();
  actualizarEstadoConfirmacion();
  alert("Pedidos confirmados correctamente.");
}




function reabrirJornadaParaNuevoPedido(fecha) {
  if (!fecha) return;

  const antes = jornadasCerradas.length;
  jornadasCerradas = (jornadasCerradas || []).filter(item => item !== fecha);

  if (memoriaUltimoEnvio?.fecha === fecha && memoriaUltimoEnvio?.jornadaEnviada === true) {
    memoriaUltimoEnvio = {};
  }

  if (jornadasCerradas.length !== antes) {
    localStorage.setItem("fratello_jornadas_cerradas", JSON.stringify(jornadasCerradas));
  }
}

function jornadaEstaCerrada(fecha) {
  return Array.isArray(jornadasCerradas) && jornadasCerradas.includes(fecha);
}

function cerrarJornada(fecha) {
  if (!fecha) return;
  if (!Array.isArray(jornadasCerradas)) jornadasCerradas = [];
  if (!jornadasCerradas.includes(fecha)) jornadasCerradas.push(fecha);
  localStorage.setItem("fratello_jornadas_cerradas", JSON.stringify(jornadasCerradas));
}

function reabrirJornada(fecha) {
  jornadasCerradas = (Array.isArray(jornadasCerradas) ? jornadasCerradas : [])
    .filter(item => item !== fecha);
  localStorage.setItem("fratello_jornadas_cerradas", JSON.stringify(jornadasCerradas));
}

function estadoJornadaActual() {
  return jornadaEstaCerrada(fechaJornadaActual()) ? "cerrada" : "abierta";
}

function fechaJornadaActual() {
  return $("fechaPedido")?.value || hoyISO();
}

function diaJornadaActual() {
  return $("diaProduccion")?.value || $("diaProduccionPedidos")?.value || "";
}

function totalesPedidosDe(listaPedidos) {
  const totales = {};

  (listaPedidos || []).forEach(pedido => {
    (pedido.items || []).forEach(it => {
      if (it.estado === "NO PEDIDO") return;

      const id = it.productoId;
      if (!id) return;

      const producto = productoPorId(id);
      if (!producto) return;

      const cantidadBase = cantidadAUnidadBase(it.cantidad, it.unidad, producto);
      totales[id] = Number(totales[id] || 0) + cantidadBase;
    });
  });

  return totales;
}

function sumarTotales(a, b) {
  const salida = {...(a || {})};
  Object.entries(b || {}).forEach(([id, cantidad]) => {
    salida[id] = Number(salida[id] || 0) + Number(cantidad || 0);
  });
  return salida;
}

function mapaProduccionActual() {
  const salida = {};

  productos.forEach(p => {
    const cantidadCargada = Number(produccion[claveProduccion(p.id)] || 0);
    salida[p.id] = cantidadAUnidadBase(cantidadCargada, p.unidad, p);
  });

  return salida;
}

function diferenciasDesde(produccionMapa, pedidosMapa) {
  const salida = {};
  const ids = new Set([
    ...Object.keys(produccionMapa || {}),
    ...Object.keys(pedidosMapa || {})
  ]);

  ids.forEach(id => {
    salida[id] = Number(produccionMapa?.[id] || 0) - Number(pedidosMapa?.[id] || 0);
  });

  return salida;
}

function productoPorIdMemoria(id) {
  return productos.find(p => p.id === id) || {
    id,
    nombre: id.replace(/^EXTRA_/, "").replace(/_/g, " "),
    unidad: "unidad"
  };
}

function memoriaCorrespondeAJornadaActual() {
  if (!memoriaUltimoEnvio) return false;
  return memoriaUltimoEnvio.fecha === fechaJornadaActual();
}

function actualizarPanelMemoriaEnvio() {
  const estado = $("estadoMemoriaEnvio");
  if (!estado) return;

  if (!memoriaUltimoEnvio) {
    estado.textContent = "No hay un envío guardado.";
    return;
  }

  const cantidadClientes = (memoriaUltimoEnvio.clientes || []).length;
  estado.textContent =
    `${memoriaUltimoEnvio.fecha} · ${memoriaUltimoEnvio.hora || ""} · ` +
    `${cantidadClientes} cliente${cantidadClientes === 1 ? "" : "s"} incluidos.`;
}

function borrarMemoriaEnvio() {
  if (!memoriaUltimoEnvio) {
    alert("No hay memoria de envío para borrar.");
    return;
  }

  if (!confirm("¿Seguro que querés comenzar una jornada nueva y borrar la memoria del último envío?")) return;

  const fecha = memoriaUltimoEnvio?.fecha || $("fechaPedido")?.value || fechaISOManana();
  memoriaUltimoEnvio = null;
  localStorage.removeItem("fratello_memoria_envio");
  reabrirJornada(fecha);

  limpiarJornadaDespuesDeEnviar();
  asegurarPedidosFijosParaFecha(fecha, false);
  renderPedidosCargados();
  calcularDiferencias();
  actualizarPanelMemoriaEnvio();

  alert("Nueva jornada iniciada. Los pedidos fijos del día volvieron a cargarse.");
}

function guardarMemoriaEnvio(produccionMapa, pedidosAcumulados, diferencias, clientesAcumulados) {
  memoriaUltimoEnvio = {
    fecha: fechaJornadaActual(),
    dia: diaJornadaActual(),
    produccion: produccionMapa,
    pedidosTotales: pedidosAcumulados,
    diferencias,
    clientes: clientesAcumulados,
    hora: new Date().toLocaleTimeString("es-AR", {hour:"2-digit", minute:"2-digit"}),
    actualizado: new Date().toISOString(),
    jornadaEnviada: true
  };

  localStorage.setItem("fratello_memoria_envio", JSON.stringify(memoriaUltimoEnvio));
      localStorage.setItem("fratello_jornadas_cerradas", JSON.stringify(jornadasCerradas));
  actualizarPanelMemoriaEnvio();
}

function construirMensajeActualizacion(pedidosNuevos, diferenciasAnteriores, diferenciasNuevas) {
  let mensaje = "FRATELLO - ACTUALIZACIÓN DE PEDIDOS\n\n";
  mensaje += "⚠️ PRIMERO: CAMBIOS A REALIZAR\n\n";

  const ids = new Set([
    ...Object.keys(diferenciasAnteriores || {}),
    ...Object.keys(diferenciasNuevas || {})
  ]);

  const cambios = [];
  ids.forEach(id => {
    const anterior = Number(diferenciasAnteriores?.[id] || 0);
    const nuevo = Number(diferenciasNuevas?.[id] || 0);
    const delta = nuevo - anterior;
    if (Math.abs(delta) < 0.0001) return;
    cambios.push({ producto: productoPorIdMemoria(id), delta });
  });

  if (!cambios.length) {
    mensaje += "- El pedido no modifica las cantidades informadas anteriormente.\n";
  } else {
    cambios.forEach(({producto, delta}) => {
      const cantidadTexto = formatearCantidadResumen(Math.abs(delta), producto);

      if (delta < 0) {
        mensaje += `🔴 AGREGAR / HACER ${cantidadTexto} ${producto.nombre}\n`;
      } else {
        mensaje += `🟢 REDUCIR / GUARDAR ${cantidadTexto} ${producto.nombre}\n`;
      }
    });
  }

  mensaje += "\n--------------------\n";
  mensaje += "PEDIDOS NUEVOS / TARDÍOS:\n\n";

  pedidosNuevos.forEach(pedido => {
    mensaje += `${pedido.cliente}:\n`;
    const items = (pedido.items || []).filter(i => i.estado !== "NO PEDIDO");
    if (!items.length) {
      mensaje += "- Sin productos detectados\n";
    } else {
      items.forEach(it => {
        mensaje += `- ${fmt(it.cantidad)} ${it.unidad} ${it.producto}\n`;
      });
    }
    mensaje += "\n";
  });

  mensaje += "Este mensaje complementa el envío anterior.";
  return mensaje;
}


function obtenerFilasComparador() {
  const totalesPedido = totalesPedidosDe(
    pedidosConfirmadosParaFecha(fechaJornadaActual())
  );
  const produccionMapa = mapaProduccionActual();
  const filas = [];

  for (const p of productos) {
    const prod = Number(produccionMapa[p.id] || 0);
    const ped = Number(totalesPedido[p.id] || 0);

    if (prod === 0 && ped === 0) continue;

    filas.push({
      productoId: p.id,
      producto: p.nombre,
      unidad: p.unidad,
      productoConfig: p,
      prod,
      ped,
      dif: prod - ped
    });
  }

  return filas;
}


function limpiarPedidosDespuesDeEnviar() {
  pedidos = [];
  pedidosConfirmados = false;

  localStorage.setItem("fratello_pedidos", JSON.stringify([]));
  localStorage.setItem("fratello_pedidos_confirmados", JSON.stringify(false));

  if ($("checkPedidoCompleto")) $("checkPedidoCompleto").checked = false;
  if ($("pedidoCrudo")) $("pedidoCrudo").value = "";
  if ($("pedidosCargados")) $("pedidosCargados").innerHTML = "<p>Jornada enviada. No hay pedidos pendientes.</p>";
  if ($("ultimoProcesado")) $("ultimoProcesado").innerHTML = "";
  if ($("comparador")) $("comparador").innerHTML = "";
  if ($("resumenPanadero")) $("resumenPanadero").textContent = "";
  if ($("vistaPedidosInline")) $("vistaPedidosInline").innerHTML = "";

  renderPedidosFuturos();
  renderPedidosRecibidosFormulario();
  actualizarEstadoConfirmacion();
  guardarEnNube();
}

function limpiarJornadaDespuesDeEnviar() {
  pedidos = [];
  pedidosConfirmados = false;

  localStorage.setItem("fratello_pedidos", JSON.stringify(pedidos));
      localStorage.setItem("fratello_pedidos_eliminados", JSON.stringify(pedidosEliminados));
  localStorage.setItem("fratello_pedidos_confirmados", JSON.stringify(false));

  const selectorProduccion = $("diaProduccion");
  const selectorPedidos = $("diaProduccionPedidos");
  const checkProduccion = $("checkProduccionCompleta");
  const checkDiaPedidos = $("checkDiaPedidos");
  const checkPedidos = $("checkPedidoCompleto");
  const pedidoCrudo = $("pedidoCrudo");

  if (selectorProduccion) selectorProduccion.value = "";
  if (selectorPedidos) selectorPedidos.value = "";
  if (checkProduccion) checkProduccion.checked = false;
  if (checkDiaPedidos) checkDiaPedidos.checked = false;
  if (checkPedidos) checkPedidos.checked = false;
  if (pedidoCrudo) pedidoCrudo.value = "";

  const pedidosCargados = $("pedidosCargados");
  const ultimoProcesado = $("ultimoProcesado");
  const comparador = $("comparador");
  const resumenPanadero = $("resumenPanadero");
  const vistaPedidos = $("vistaPedidosInline");
  const produccionLista = $("produccionLista");
  const produccionExtra = $("produccionExtra");

  if (pedidosCargados) pedidosCargados.innerHTML = "<p>No hay pedidos cargados.</p>";
  if (ultimoProcesado) ultimoProcesado.innerHTML = "";
  if (comparador) comparador.innerHTML = "";
  if (resumenPanadero) resumenPanadero.textContent = "";
  if (vistaPedidos) vistaPedidos.innerHTML = "";
  if (produccionLista) produccionLista.innerHTML = "";
  if (produccionExtra) produccionExtra.innerHTML = "";

  actualizarTarjetaDiaPedidos();
  guardarEnNube();
}

function abrirWhatsApp(numero, mensaje) {
  const texto = encodeURIComponent(mensaje);
  const url = numero
    ? `https://wa.me/${numero}?text=${texto}`
    : `https://wa.me/?text=${texto}`;

  window.location.href = url;
}


function verificarChecksAntesDeWhatsApp() {
  const selectorProduccion = $("diaProduccion");
  const selectorPedidos = $("diaProduccionPedidos");
  const checkProduccion = $("checkProduccionCompleta");
  const estado = sincronizarConfirmacionDiaDesdePedidos();

  const diaProduccion = selectorProduccion?.value || "";
  const diaPedidos = selectorPedidos?.value || diaProduccion;

  if (!estado.pedidosFecha.length) {
    alert("No hay pedidos cargados para el día seleccionado.");
    return false;
  }

  if (!estado.todosConfirmados) {
    const faltan = estado.pedidosFecha.length - estado.confirmados.length;
    alert(`Falta confirmar ${faltan} pedido(s) antes de enviar.`);
    return false;
  }

  if (!diaProduccion || !checkProduccion?.checked) {
    alert("Primero confirmá la producción del día seleccionado.");
    return false;
  }

  if (diaPedidos && diaProduccion !== diaPedidos) {
    alert("El día de Pedidos no coincide con el día de Producción.");
    return false;
  }

  return true;
}

function generarMensajeGrupoFratello() {
  if (!verificarChecksAntesDeWhatsApp()) return;

  const pedidosNuevos = pedidosConfirmadosParaFecha(fechaPanelSemanalAbierto() || fechaJornadaActual());
  if (!pedidosNuevos.length) {
    alert("No hay pedidos confirmados para enviar.");
    return;
  }
  const totalesNuevos = totalesPedidosDe(pedidosNuevos);
  const esActualizacion = memoriaCorrespondeAJornadaActual();

  let produccionMapa;
  let pedidosAcumulados;
  let diferenciasNuevas;
  let clientesAcumulados;
  let mensaje;

  if (esActualizacion) {
    produccionMapa = memoriaUltimoEnvio.produccion || mapaProduccionActual();
    pedidosAcumulados = sumarTotales(memoriaUltimoEnvio.pedidosTotales, totalesNuevos);
    diferenciasNuevas = diferenciasDesde(produccionMapa, pedidosAcumulados);
    clientesAcumulados = [
      ...(memoriaUltimoEnvio.clientes || []),
      ...pedidosNuevos.map(p => p.cliente)
    ];

    mensaje = construirMensajeActualizacion(
      pedidosNuevos,
      memoriaUltimoEnvio.diferencias || {},
      diferenciasNuevas
    );
  } else {
    produccionMapa = mapaProduccionActual();
    pedidosAcumulados = totalesNuevos;
    diferenciasNuevas = diferenciasDesde(produccionMapa, pedidosAcumulados);
    clientesAcumulados = pedidosNuevos.map(p => p.cliente);

    const filas = obtenerFilasComparador();
    const faltan = filas.filter(f => f.dif < 0);
    const sobran = filas.filter(f => f.dif > 0);

    mensaje = "FRATELLO - Resumen de producción y pedidos\n\n";

    mensaje += "🔴 FALTA HACER:\n";
    if (!faltan.length) {
      mensaje += "- Nada\n";
    } else {
      faltan.forEach(f => {
        mensaje += `🔴 ${formatearCantidadResumen(Math.abs(f.dif), f.productoConfig)} ${f.producto}\n`;
      });
    }

    mensaje += "\n🟢 SOBRA / GUARDAR:\n";
    if (!sobran.length) {
      mensaje += "- Nada\n";
    } else {
      sobran.forEach(f => {
        mensaje += `🟢 ${formatearCantidadResumen(f.dif, f.productoConfig)} ${f.producto}\n`;
      });
    }

    mensaje += "\n--------------------\nPEDIDOS DE CLIENTES:\n\n";

    pedidosNuevos.forEach(pedido => {
      const itemsValidos = (pedido.items || []).filter(i => i.estado !== "NO PEDIDO");
      mensaje += `${pedido.cliente}:\n`;

      if (!itemsValidos.length) {
        mensaje += "- Sin productos detectados\n";
      } else {
        itemsValidos.forEach(it => {
          mensaje += `- ${fmt(it.cantidad)} ${it.unidad} ${it.producto}\n`;
        });
      }
      mensaje += "\n";
    });

    mensaje += "Enviado desde sistema Fratello.";
  }

  guardarMemoriaEnvio(
    produccionMapa,
    pedidosAcumulados,
    diferenciasNuevas,
    [...new Set(clientesAcumulados)]
  );

  cerrarJornada(fechaJornadaActual());
  limpiarPedidosDespuesDeEnviar();
  actualizarPanelMemoriaEnvio();

  abrirWhatsApp("", mensaje);
}


const WHATSAPP_CLIENTE_PRUEBA = "5492657545599";

function generarLinkFormularioCliente() {
  const base = window.location.origin + window.location.pathname.replace("index.html", "");
  return base + "pedido.html";
}

function recordarPedidoCliente() {
  const link = generarLinkFormularioCliente();

  const mensaje = `Hola! Te recordamos cargar tu pedido para mañana en este formulario:

${link}

Gracias, Fratello.`;

  abrirWhatsApp(WHATSAPP_CLIENTE_PRUEBA, mensaje);
}


function repararPedidosConParserV311() {
  let reparados = 0;

  pedidos.forEach(pedido => {
    const texto = String(pedido.textoOriginal || "").trim();
    if (!texto) return;

    const nuevosItems = procesarTextoPedido(
      texto,
      pedido.cliente || "",
      fechaEntregaPedido(pedido)
    );

    const firmaAnterior = JSON.stringify(
      (pedido.items || []).map(item => [
        item.productoId,
        Number(item.cantidad || 0),
        item.unidad
      ])
    );

    const firmaNueva = JSON.stringify(
      nuevosItems.map(item => [
        item.productoId,
        Number(item.cantidad || 0),
        item.unidad
      ])
    );

    if (firmaAnterior !== firmaNueva) {
      pedido.items = nuevosItems;
      pedido.versionInterpretador = "parser_v311_decimales";
      pedido.interpretadoEn = new Date().toISOString();
      reparados += 1;
    }
  });

  if (reparados > 0) guardarTodo();
  return reparados;
}





/* =========================================================
   FRATELLO ACCESO ADMINISTRADOR — v3.9.5D.1
   ========================================================= */

function mostrarModalAdministrador() {
  $("modalAccesoAdministrador")?.classList.remove("hidden");
  actualizarPanelSesionAdministrador();
  setTimeout(() => {
    if (!usuarioAdministradorActual) $("usuarioAdministrador")?.focus();
  }, 60);
}

function ocultarModalAdministrador() {
  $("modalAccesoAdministrador")?.classList.add("hidden");
  if ($("claveAdministrador")) $("claveAdministrador").value = "";
  if ($("estadoAccesoAdministrador")) $("estadoAccesoAdministrador").textContent = "";
}

function actualizarInterfazAdministrador() {
  const conectado = tieneRolAdministrador();
  $("tarjetaAdministracionInicio")?.classList.toggle("hidden", !conectado);
  document.body.classList.toggle("admin-authenticated", conectado);
  $("btnAdministrarPersonasCajaRapido")?.classList.toggle("hidden", !conectado);

  if ($("iconoUsuarioAdministrador")) {
    $("iconoUsuarioAdministrador").textContent = conectado ? "🔐" : "👤";
  }
  if ($("textoUsuarioAdministrador")) {
    $("textoUsuarioAdministrador").textContent = conectado ? "Administrador" : "Ingresar";
  }

  if (!conectado) {
    bloquearAdministracion();
    const seccion = document.getElementById("seccionAdministracion");
    if (seccion?.classList.contains("active")) mostrarInicio();
  }
}

function actualizarPanelSesionAdministrador() {
  const conectado = tieneRolAdministrador();
  $("panelLoginAdministrador")?.classList.toggle("hidden", conectado);
  $("panelSesionAdministrador")?.classList.toggle("hidden", !conectado);

  if ($("correoSesionAdministrador")) {
    $("correoSesionAdministrador").textContent = usuarioAdministradorActual?.email || "Administrador";
  }
}

async function ingresarAdministradorConUsuario() {
  if (!authFratello) {
    if ($("estadoAccesoAdministrador")) {
      $("estadoAccesoAdministrador").textContent = "Firebase Authentication no está disponible.";
    }
    return;
  }

  const usuario = String($("usuarioAdministrador")?.value || "").trim();
  const clave = String($("claveAdministrador")?.value || "");

  if (!usuario || !clave) {
    $("estadoAccesoAdministrador").textContent = "Completá usuario y contraseña.";
    return;
  }

  const boton = $("btnIngresarAdministrador");
  if (boton) {
    boton.disabled = true;
    boton.textContent = "Ingresando...";
  }

  try {
    await authFratello.signInWithEmailAndPassword(usuario, clave);
    if ($("estadoAccesoAdministrador")) $("estadoAccesoAdministrador").textContent = "";
  } catch (error) {
    console.error("Error de acceso:", error);
    const mensajes = {
      "auth/invalid-credential": "Usuario o contraseña incorrectos.",
      "auth/user-not-found": "Usuario o contraseña incorrectos.",
      "auth/wrong-password": "Usuario o contraseña incorrectos.",
      "auth/too-many-requests": "Demasiados intentos. Esperá unos minutos.",
      "auth/network-request-failed": "No se pudo conectar. Revisá Internet.",
      "auth/operation-not-allowed": "Activá Email/Password en Firebase Authentication."
    };
    if ($("estadoAccesoAdministrador")) {
      $("estadoAccesoAdministrador").textContent =
        mensajes[error?.code] || "No se pudo iniciar sesión.";
    }
  } finally {
    if (boton) {
      boton.disabled = false;
      boton.textContent = "Ingresar";
    }
  }
}

async function cerrarSesionAdministrador() {
  if (!authFratello) return;

  try {
    await authFratello.signOut();
    ocultarModalAdministrador();
    mostrarInicio();
  } catch (error) {
    console.error("No se pudo cerrar la sesión:", error);
  }
}

function abrirAdministracionAutenticada() {
  if (!tieneRolAdministrador()) {
    mostrarModalAdministrador();
    return;
  }

  ocultarModalAdministrador();
  vistaAdministracionActual = "";
  abrirAdministracionPrivada();

  // Entrada explícita desde Inicio: abre el menú principal de Administración.
  $("panelAdministracionLogin")?.classList.add("hidden");
  $("panelAdministracionPrivado")?.classList.remove("hidden");
  mostrarMenuAdministracion();
  renderAdministracionFinanciera();
  renderSeguridadCompleta();
  registrarActividadAdministracion();

  if (typeof mostrarSeccionFratelloSinApilar === "function") {
    mostrarSeccionFratelloSinApilar("seccionAdministracion");
  } else {
    mostrarSeccion("seccionAdministracion");
  }
}

function iniciarAccesoAdministrador() {
  if (window.__FRATELLO_ACCESO_ADMIN_INICIADO__) return;
  window.__FRATELLO_ACCESO_ADMIN_INICIADO__ = true;

  $("btnUsuarioAdministrador")?.addEventListener("click", mostrarModalAdministrador);
  $("btnCerrarModalAdministrador")?.addEventListener("click", ocultarModalAdministrador);
  $("btnIngresarAdministrador")?.addEventListener("click", ingresarAdministradorConUsuario);
  $("btnCerrarSesionAdministrador")?.addEventListener("click", cerrarSesionAdministrador);
  $("btnAbrirAdministracionDesdeUsuario")?.addEventListener("click", abrirAdministracionAutenticada);

  $("claveAdministrador")?.addEventListener("keydown", evento => {
    if (evento.key === "Enter") ingresarAdministradorConUsuario();
  });
  $("usuarioAdministrador")?.addEventListener("keydown", evento => {
    if (evento.key === "Enter") $("claveAdministrador")?.focus();
  });

  $("modalAccesoAdministrador")?.addEventListener("click", evento => {
    if (evento.target?.id === "modalAccesoAdministrador") ocultarModalAdministrador();
  });

  document.addEventListener("keydown", evento => {
    if (evento.key === "Escape") ocultarModalAdministrador();
  });

  if (authFratello) {
    // v5.0.3: mostrar la sesión restaurada de inmediato, sin esperar a Firestore.
    // Firebase conserva la sesión LOCAL; cuando currentUser ya está disponible,
    // la interfaz de administrador se pinta antes de iniciar la sincronización remota.
    const usuarioEnMemoria = authFratello.currentUser;
    if (usuarioEnMemoria) {
      usuarioAdministradorActual = usuarioEnMemoria;
      rolUsuarioActual = obtenerRolUsuario(usuarioEnMemoria);
      segCargarLocal();
      dispositivoFratelloActual = segObtenerDispositivoActual();
      const dispositivoLocal = seguridadFratello.dispositivos.find(
        d => d.id === dispositivoFratelloActual.id && d.uid === usuarioEnMemoria.uid
      );
      dispositivoAutorizadoActual = !dispositivoLocal || dispositivoLocal.estado === "autorizado";
      actualizarInterfazAdministrador();
      actualizarPanelSesionAdministrador();
      segAplicarPermisosUI();
    }

    authFratello.onAuthStateChanged(usuario => {
      // Primera pintura inmediata: no bloquear el botón Administrador por lecturas remotas.
      usuarioAdministradorActual = usuario || null;
      rolUsuarioActual = obtenerRolUsuario(usuarioAdministradorActual);

      if (usuarioAdministradorActual) {
        segCargarLocal();
        dispositivoFratelloActual = segObtenerDispositivoActual();
        const dispositivoLocal = seguridadFratello.dispositivos.find(
          d => d.id === dispositivoFratelloActual.id && d.uid === usuarioAdministradorActual.uid
        );
        dispositivoAutorizadoActual = !dispositivoLocal || dispositivoLocal.estado === "autorizado";
      } else {
        dispositivoAutorizadoActual = false;
      }

      actualizarInterfazAdministrador();
      actualizarPanelSesionAdministrador();
      segAplicarPermisosUI();

      // Verificación y auditoría en segundo plano. La app ya queda utilizable.
      if (usuarioAdministradorActual) {
        const usuarioVerificado = usuarioAdministradorActual;
        Promise.resolve()
          .then(() => segVerificarDispositivo(usuarioVerificado))
          .then(autorizado => {
            if (authFratello.currentUser?.uid !== usuarioVerificado.uid) return;
            dispositivoAutorizadoActual = Boolean(autorizado);
            rolUsuarioActual = obtenerRolUsuario(usuarioVerificado);
            actualizarInterfazAdministrador();
            actualizarPanelSesionAdministrador();
            segAplicarPermisosUI();
            if (autorizado) {
              // v5.0.9: no reiniciar la navegación si el usuario ya está dentro
              // de una subpantalla de Administración (Resumen, Gastos, etc.).
              const seccionAdministracionActiva =
                document.getElementById("seccionAdministracion")?.classList.contains("active");

              if (!seccionAdministracionActiva) {
                abrirAdministracionPrivada();
              } else {
                administracionPrivadaActiva = true;
                $("panelAdministracionLogin")?.classList.add("hidden");
                $("panelAdministracionPrivado")?.classList.remove("hidden");

                if (vistaAdministracionActual) {
                  restaurarVistaAdministracionActual();
                }

                renderAdministracionFinanciera();
              }

              renderSeguridadCompleta();
              segAuditar("sesion", "Inicio de sesión", usuarioVerificado.email || "").catch(() => {});
            }
          })
          .catch(error => {
            // Ante una demora o corte de Internet se mantiene la sesión local restaurada.
            console.warn("Verificación de administrador en segundo plano:", error);
          });
      }
    });
  } else {
    actualizarInterfazAdministrador();
  }
}


/* =========================================================
   FRATELLO ADMINISTRACIÓN FINANCIERA — v3.9.4C.1
   ========================================================= */

const ADMIN_FIN_STORAGE_KEY = "fratello_administracion_v394c1";
let administracionFinanciera = {
  ingresosExternos: [],
  clientesExternos: [],
  clientesExternosEliminados: [],
  gastosManuales: [],
  presupuestos: [],
  plataRealManual: {},
  transferenciasDinero: []
};
let administracionPrivadaActiva = false;
let temporizadorAdministracion = null;
const ADMIN_FIN_TIMEOUT_MS = 3 * 60 * 1000;

function adminFinId(prefijo) {
  return `${prefijo}_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
}

function adminFinHoy() {
  const ahora = new Date();
  const local = new Date(ahora.getTime() - ahora.getTimezoneOffset() * 60000);
  return local.toISOString().slice(0, 10);
}

function adminFinMesActual() {
  return adminFinHoy().slice(0, 7);
}

function adminFinMonto(valor) {
  const numero = Number(valor || 0);
  return Number.isFinite(numero) && numero >= 0 ? numero : 0;
}

function adminFinDinero(valor) {
  return new Intl.NumberFormat("es-AR", {
    style: "currency",
    currency: "ARS",
    maximumFractionDigits: 0
  }).format(Number(valor || 0));
}

function adminFinEscapar(valor) {
  return String(valor ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function cargarAdministracionLocal() {
  try {
    const guardado = leerJsonLocalSeguro(ADMIN_FIN_STORAGE_KEY, {});
    administracionFinanciera = {
      ingresosExternos: Array.isArray(guardado.ingresosExternos) ? guardado.ingresosExternos : [],
      clientesExternos: Array.isArray(guardado.clientesExternos) ? guardado.clientesExternos : [],
      clientesExternosEliminados: Array.isArray(guardado.clientesExternosEliminados)
        ? guardado.clientesExternosEliminados
        : [],
      gastosManuales: Array.isArray(guardado.gastosManuales) ? guardado.gastosManuales : [],
      presupuestos: Array.isArray(guardado.presupuestos) ? guardado.presupuestos : [],
      plataRealManual: guardado.plataRealManual && typeof guardado.plataRealManual === "object"
        ? guardado.plataRealManual
        : {},
      transferenciasDinero: Array.isArray(guardado.transferenciasDinero)
        ? guardado.transferenciasDinero
        : []
    };
  } catch (error) {
    console.error("No se pudo cargar Administración:", error);
  }
}

function guardarAdministracionLocal() {
  localStorage.setItem(ADMIN_FIN_STORAGE_KEY, JSON.stringify(administracionFinanciera));
}

function guardarAdministracion() {
  guardarAdministracionLocal();
  renderAdministracionFinanciera();
  guardarAdminModuloEnNube();
}

function mesSeleccionadoAdministracion() {
  return $("mesAdministracionRapido")?.value ||
    $("mesAdministracion")?.value ||
    adminFinMesActual();
}

function sincronizarSelectoresMesAdministracion(valor, origen = "") {
  const mes = valor || adminFinMesActual();
  if (origen !== "rapido" && $("mesAdministracionRapido")) {
    $("mesAdministracionRapido").value = mes;
  }
  if (origen !== "principal" && $("mesAdministracion")) {
    $("mesAdministracion").value = mes;
  }
}

function plataRealManualMes(mes = mesSeleccionadoAdministracion()) {
  const base = administracionFinanciera.plataRealManual || {};
  const registro = base[mes] || {};
  return {
    efectivo: adminFinMonto(registro.efectivo),
    transferencias: adminFinMonto(registro.transferencias),
    cheques: adminFinMonto(registro.cheques)
  };
}

function guardarPlataRealManualDesdeResumen() {
  const mes = mesSeleccionadoAdministracion();
  administracionFinanciera.plataRealManual ||= {};
  administracionFinanciera.plataRealManual[mes] = {
    efectivo: adminFinMonto($("plataRealEfectivoManual")?.value),
    transferencias: adminFinMonto($("plataRealTransferenciasManual")?.value),
    cheques: adminFinMonto($("plataRealChequesManual")?.value),
    actualizadoEn: new Date().toISOString()
  };
  guardarAdministracionLocal();
  guardarAdminModuloEnNube();
  renderResumenMovilAdministracion();

  const boton = $("btnGuardarPlataRealManual");
  if (boton) {
    const textoOriginal = boton.textContent;
    boton.textContent = "✓ Plata real guardada";
    boton.disabled = true;
    setTimeout(() => {
      boton.textContent = textoOriginal;
      boton.disabled = false;
    }, 1200);
  }
}

function recalcularPlataRealManualEnPantalla() {
  const efectivo = adminFinMonto($("plataRealEfectivoManual")?.value);
  const transferencias = adminFinMonto($("plataRealTransferenciasManual")?.value);
  const cheques = adminFinMonto($("plataRealChequesManual")?.value);
  const total = efectivo + transferencias + cheques;
  const resultado = resumenNumericoAdministracion().resultado;
  const diferencia = total - resultado;
  const clase = Math.abs(diferencia) < 0.01 ? "ok" : diferencia > 0 ? "positive" : "negative";

  if ($("plataRealTotalManual")) $("plataRealTotalManual").textContent = adminFinDinero(total);
  if ($("plataRealDiferenciaManual")) {
    $("plataRealDiferenciaManual").textContent = adminFinDinero(diferencia);
    $("plataRealDiferenciaManual").closest("article")?.classList.remove("ok", "positive", "negative");
    $("plataRealDiferenciaManual").closest("article")?.classList.add(clase);
  }
}

function fechaEnMesAdministracion(fecha, mes = mesSeleccionadoAdministracion()) {
  return String(fecha || "").slice(0, 7) === mes;
}

function ingresosCajaDelMesAdministracion() {
  const mes = mesSeleccionadoAdministracion();
  return (Array.isArray(cierresCaja) ? cierresCaja : [])
    .filter(cierre => fechaEnMesAdministracion(cierre.fecha, mes))
    .map(cierre => ({
      id: `caja_ingreso_${cierre.id}`,
      fecha: cierre.fecha,
      cliente: "Fratello",
      descripcion: `Caja ${turnoTextoCaja(cierre.turno)}`,
      efectivo: adminFinMonto(cierre.efectivo),
      transferencias: adminFinMonto(cierre.transferencias),
      monto: adminFinMonto(cierre.efectivo) + adminFinMonto(cierre.transferencias),
      origen: "Caja"
    }))
    .sort((a, b) => String(b.fecha).localeCompare(String(a.fecha)));
}

function gastosCajaDelMesAdministracion() {
  const mes = mesSeleccionadoAdministracion();
  const resultado = [];

  (Array.isArray(cierresCaja) ? cierresCaja : [])
    .filter(cierre => fechaEnMesAdministracion(cierre.fecha, mes))
    .forEach(cierre => {
      (Array.isArray(cierre.gastos) ? cierre.gastos : []).forEach((gasto, indice) => {
        resultado.push({
          id: `caja_gasto_${cierre.id}_${indice}`,
          fecha: cierre.fecha,
          categoria: "Gasto de Caja",
          motivo: gasto.motivo || "Gasto sin descripción",
          monto: adminFinMonto(gasto.monto),
          medio: "Efectivo",
          origen: `Caja ${turnoTextoCaja(cierre.turno)}`
        });
      });
    });

  return resultado.sort((a, b) => String(b.fecha).localeCompare(String(a.fecha)));
}

function ingresosExternosDelMesAdministracion() {
  const mes = mesSeleccionadoAdministracion();
  return administracionFinanciera.ingresosExternos
    .filter(item => fechaEnMesAdministracion(item.fecha, mes))
    .sort((a, b) => String(b.fecha).localeCompare(String(a.fecha)));
}

function gastosManualesDelMesAdministracion() {
  const mes = mesSeleccionadoAdministracion();
  return administracionFinanciera.gastosManuales
    .filter(item => fechaEnMesAdministracion(item.fecha, mes))
    .sort((a, b) => String(b.fecha).localeCompare(String(a.fecha)));
}

function presupuestosDelMesAdministracion() {
  const mes = mesSeleccionadoAdministracion();
  return administracionFinanciera.presupuestos
    .filter(item => item.mes === mes)
    .sort((a, b) => String(a.categoria).localeCompare(String(b.categoria)));
}

function resumenNumericoAdministracion() {
  const ingresosCaja = ingresosCajaDelMesAdministracion();
  const ingresosExternos = ingresosExternosDelMesAdministracion();
  const gastosCaja = gastosCajaDelMesAdministracion();
  const gastosManuales = gastosManualesDelMesAdministracion();

  const totalCaja = ingresosCaja.reduce((s, x) => s + x.monto, 0);
  const externosCobrados = ingresosExternos
    .filter(x => x.cobrado !== false)
    .reduce((s, x) => s + adminFinMonto(x.monto), 0);
  const externosPendientes = ingresosExternos
    .filter(x => x.cobrado === false)
    .reduce((s, x) => s + adminFinMonto(x.monto), 0);

  const totalGastosCaja = gastosCaja.reduce((s, x) => s + x.monto, 0);
  const manualesPagados = gastosManuales
    .filter(x => x.pagado !== false)
    .reduce((s, x) => s + adminFinMonto(x.monto), 0);
  const manualesPendientes = gastosManuales
    .filter(x => x.pagado === false)
    .reduce((s, x) => s + adminFinMonto(x.monto), 0);

  const ingresos = totalCaja + externosCobrados;
  const gastos = totalGastosCaja + manualesPagados;

  return {
    ingresos,
    gastos,
    resultado: ingresos - gastos,
    totalCaja,
    externosCobrados,
    externosPendientes,
    totalGastosCaja,
    manualesPagados,
    manualesPendientes
  };
}

function adminFinVacio(texto) {
  return `<div class="adminFinanceEmpty">${adminFinEscapar(texto)}</div>`;
}

function adminFinTabla(encabezados, filas) {
  if (!filas.length) return "";
  return `
    <div class="adminFinanceTableWrap">
      <table class="adminFinanceTable">
        <thead><tr>${encabezados.map(x => `<th>${x}</th>`).join("")}</tr></thead>
        <tbody>${filas.join("")}</tbody>
      </table>
    </div>`;
}

function transferenciasDineroDelMes(mes = mesSeleccionadoAdministracion()) {
  return (administracionFinanciera.transferenciasDinero || [])
    .filter(item => String(item.fecha || "").slice(0, 7) === mes)
    .sort((a, b) => String(b.fecha).localeCompare(String(a.fecha)));
}

function aplicarTransferenciasEntreMedios(totales, movimientos = transferenciasDineroDelMes()) {
  const resultado = {
    "Efectivo": adminFinMonto(totales?.["Efectivo"]),
    "Transferencia": adminFinMonto(totales?.["Transferencia"]),
    "Mercado Pago": adminFinMonto(totales?.["Mercado Pago"]),
    "Cheque": adminFinMonto(totales?.["Cheque"]),
    "Otro": adminFinMonto(totales?.["Otro"])
  };

  (movimientos || []).forEach(item => {
    const desde = normalizarMedioPagoAdministracion(item.desde);
    const hacia = normalizarMedioPagoAdministracion(item.hacia);
    const monto = adminFinMonto(item.monto);
    resultado[desde] = adminFinMonto(resultado[desde]) - monto;
    resultado[hacia] = adminFinMonto(resultado[hacia]) + monto;
  });

  return resultado;
}

function guardarTransferenciaDinero() {
  const desde = $("transferenciaDineroDesde")?.value || "Efectivo";
  const hacia = $("transferenciaDineroHacia")?.value || "Transferencia";
  const monto = adminFinMonto($("transferenciaDineroMonto")?.value);
  const fecha = $("transferenciaDineroFecha")?.value || adminFinHoy();
  const observacion = String($("transferenciaDineroObservacion")?.value || "").trim();

  if (desde === hacia) {
    alert("Elegí dos medios de dinero diferentes.");
    return;
  }
  if (!monto) {
    alert("Ingresá un monto válido.");
    return;
  }

  const base = datosResumenMovilAdministracion();
  const disponible = adminFinMonto(base.ingresosPorMedio?.[normalizarMedioPagoAdministracion(desde)]);
  if (monto > disponible) {
    alert(`No podés transferir más de ${adminFinDinero(disponible)} desde ${desde}.`);
    return;
  }

  administracionFinanciera.transferenciasDinero ||= [];
  administracionFinanciera.transferenciasDinero.push({
    id: adminFinId("transf"),
    fecha,
    desde,
    hacia,
    monto,
    observacion,
    creadoEn: new Date().toISOString()
  });

  guardarAdministracion();
  renderResumenMovilAdministracion();
}

function eliminarTransferenciaDinero(id) {
  if (!confirm("¿Eliminar esta transferencia de dinero?")) return;
  administracionFinanciera.transferenciasDinero =
    (administracionFinanciera.transferenciasDinero || []).filter(item => item.id !== id);
  guardarAdministracion();
  renderResumenMovilAdministracion();
}

function renderHistorialTransferenciasDinero() {
  const host = $("historialTransferenciasDinero");
  if (!host) return;
  const movimientos = transferenciasDineroDelMes();

  host.innerHTML = movimientos.length
    ? `<h4>Historial de transferencias</h4>${movimientos.map(item => `
        <div class="moneyTransferRow">
          <span>
            <strong>${adminFinEscapar(item.desde)} → ${adminFinEscapar(item.hacia)}</strong>
            <small>${adminFinEscapar(item.fecha)}${item.observacion ? ` · ${adminFinEscapar(item.observacion)}` : ""}</small>
          </span>
          <b>${adminFinDinero(item.monto)}</b>
          <button type="button" onclick="eliminarTransferenciaDinero('${item.id}')">Eliminar</button>
        </div>`).join("")}`
    : "";
}

function datosResumenMovilAdministracion() {
  const r = resumenNumericoAdministracion();
  const caja = ingresosCajaDelMesAdministracion();
  const externos = ingresosExternosDelMesAdministracion();

  const porCliente = new Map();
  porCliente.set("Panadería Fratello", caja.reduce((s, x) => s + adminFinMonto(x.monto), 0));
  externos
    .filter(item => item.cobrado !== false)
    .forEach(item => {
      const cliente = String(item.cliente || "Otros").trim() || "Otros";
      porCliente.set(cliente, (porCliente.get(cliente) || 0) + adminFinMonto(item.monto));
    });

  let efectivo = caja.reduce((s, x) => s + adminFinMonto(x.efectivo), 0);
  let transferencias = caja.reduce((s, x) => s + adminFinMonto(x.transferencias), 0);
  let cheques = 0;

  externos.filter(x => x.cobrado !== false).forEach(item => {
    const medio = String(item.medio || "").toLowerCase();
    const monto = adminFinMonto(item.monto);
    if (medio.includes("cheque")) cheques += monto;
    else if (medio.includes("transfer") || medio.includes("mercado") || medio.includes("mp")) transferencias += monto;
    else efectivo += monto;
  });

  const manual = plataRealManualMes();
  const plataReal = manual.efectivo + manual.transferencias + manual.cheques;
  const diferencia = plataReal - r.resultado;
  const ingresosCaja = ingresosCajaDelMesAdministracion();
  const ingresosExternos = ingresosExternosDelMesAdministracion().filter(item => item.cobrado !== false);
  const gastosCaja = gastosCajaDelMesAdministracion().map(item => ({ ...item, medio: "Efectivo" }));
  const gastosManuales = gastosManualesDelMesAdministracion()
    .filter(item => item.pagado !== false);

  const ingresosPorMedioBase = totalesPorMedioAdministracion([
    ...ingresosCaja.flatMap(item => [
      { monto: item.efectivo, medio: "Efectivo" },
      { monto: item.transferencias, medio: "Transferencia" }
    ]),
    ...ingresosExternos
  ]);
  const ingresosPorMedio = aplicarTransferenciasEntreMedios(ingresosPorMedioBase);

  const gastosPorMedio = totalesPorMedioAdministracion([
    ...gastosCaja,
    ...gastosManuales
  ]);

  const gananciaPorMedio = {};
  ["Efectivo", "Transferencia", "Mercado Pago", "Cheque", "Otro"].forEach(medio => {
    gananciaPorMedio[medio] =
      adminFinMonto(ingresosPorMedio[medio]) - adminFinMonto(gastosPorMedio[medio]);
  });

  return {
    ...r,
    clientes: [...porCliente.entries()].sort((a, b) => b[1] - a[1]),
    ingresosPorMedio,
    gastosPorMedio,
    gananciaPorMedio,
    efectivoCalculado: efectivo,
    transferenciasCalculadas: transferencias,
    chequesCalculados: cheques,
    efectivo: manual.efectivo,
    transferencias: manual.transferencias,
    cheques: manual.cheques,
    plataReal,
    diferencia
  };
}

function renderResumenMovilAdministracion() {
  const host = $("resumenMovilAdministracion");
  if (!host) return;
  const d = datosResumenMovilAdministracion();
  const diferenciaClase = Math.abs(d.diferencia) < 0.01 ? "ok" : d.diferencia > 0 ? "positive" : "negative";
  const clientesHtml = d.clientes.length
    ? d.clientes.map(([cliente, monto]) => `<div><span>${adminFinEscapar(cliente)}</span><strong>${adminFinDinero(monto)}</strong></div>`).join("")
    : `<div class="adminMobileEmpty">Todavía no hay ingresos cargados en este mes.</div>`;

  host.innerHTML = `
    <article class="adminMobileClients">
      <h3>💰 Ingresos de la panadería y pagos externos</h3>
      <div class="adminMobileClientList">${clientesHtml}</div>
      <div class="adminMobileClientTotal"><span>Total de ingresos</span><strong>${adminFinDinero(d.ingresos)}</strong></div>
    </article>
    <div class="adminMobileKpis">
      <article>
        <span>Total ingresos</span>
        <strong>${adminFinDinero(d.ingresos)}</strong>
        ${htmlDesgloseMediosAdministracion(d.ingresosPorMedio, true)}
      </article>
      <article class="expense">
        <span>Total gastos</span>
        <strong>${adminFinDinero(d.gastos)}</strong>
        ${htmlDesgloseMediosAdministracion(d.gastosPorMedio, true)}
      </article>
      <article class="profit">
        <span>Ganancia</span>
        <strong>${adminFinDinero(d.resultado)}</strong>
        ${htmlDesgloseMediosAdministracion(d.gananciaPorMedio, true)}
      </article>
      <article class="realMoneyEditable">
        <span>Plata real</span>
        <strong id="plataRealTotalManual">${adminFinDinero(d.plataReal)}</strong>
        ${htmlDesgloseMediosAdministracion({
          "Efectivo": d.efectivo,
          "Transferencia": d.transferencias,
          "Cheque": d.cheques,
          "Mercado Pago": 0,
          "Otro": 0
        }, true)}
        <small>Ingresada manualmente</small>
      </article>
      <article class="difference ${diferenciaClase}">
        <span>Diferencia</span>
        <strong id="plataRealDiferenciaManual">${adminFinDinero(d.diferencia)}</strong>
        <small>Plata real − ganancia esperada</small>
      </article>
    </div>
    <section class="adminMobileRealEditor">
      <div class="realEditorTitle">
        <strong>✍️ Cargar plata real</strong>
        <small>Valores contados y verificados por vos</small>
      </div>
      <div class="realEditorGrid">
        <label>Efectivo
          <input id="plataRealEfectivoManual" inputmode="decimal" type="number" min="0" step="1" value="${d.efectivo}">
        </label>
        <label>Transferencias
          <input id="plataRealTransferenciasManual" inputmode="decimal" type="number" min="0" step="1" value="${d.transferencias}">
        </label>
        <label>Cheques
          <input id="plataRealChequesManual" inputmode="decimal" type="number" min="0" step="1" value="${d.cheques}">
        </label>
      </div>
      <button id="btnGuardarPlataRealManual" class="primary" type="button">Guardar plata real</button>
    </section>

    <section class="adminMoneyTransfer">
      <button id="btnAbrirTransferenciaDinero" class="primary" type="button">🔄 Transferencia de dinero</button>
      <div id="formTransferenciaDinero" class="moneyTransferForm hidden">
        <div class="moneyTransferGrid">
          <label>Desde
            <select id="transferenciaDineroDesde">
              <option>Efectivo</option>
              <option>Transferencia</option>
              <option>Cheque</option>
              <option>Mercado Pago</option>
            </select>
          </label>
          <label>Hacia
            <select id="transferenciaDineroHacia">
              <option>Transferencia</option>
              <option>Efectivo</option>
              <option>Cheque</option>
              <option>Mercado Pago</option>
            </select>
          </label>
          <label>Monto
            <input id="transferenciaDineroMonto" type="number" min="1" step="1" inputmode="decimal" placeholder="0">
          </label>
          <label>Fecha
            <input id="transferenciaDineroFecha" type="date" value="${adminFinHoy()}">
          </label>
          <label class="wide">Observación
            <input id="transferenciaDineroObservacion" type="text" placeholder="Ej.: Cambio con cuenta del gimnasio">
          </label>
        </div>
        <div class="moneyTransferActions">
          <button id="btnCancelarTransferenciaDinero" type="button">Cancelar</button>
          <button id="btnGuardarTransferenciaDinero" class="primary" type="button">Confirmar transferencia</button>
        </div>
      </div>
      <div id="historialTransferenciasDinero" class="moneyTransferHistory"></div>
    </section>`;

  renderHistorialTransferenciasDinero();
}

function renderResumenAdministracion() {
  const r = resumenNumericoAdministracion();
  renderResumenMovilAdministracion();
  const resultadoClase = r.resultado >= 0 ? "positive" : "negative";

  if ($("tarjetasResumenAdministracion")) {
    $("tarjetasResumenAdministracion").innerHTML = `
      <article><span>Ingresos totales</span><strong>${adminFinDinero(r.ingresos)}</strong><small>Caja + ingresos externos cobrados</small></article>
      <article><span>Gastos totales</span><strong>${adminFinDinero(r.gastos)}</strong><small>Caja + gastos administrativos pagados</small></article>
      <article class="${resultadoClase}"><span>Resultado estimado</span><strong>${adminFinDinero(r.resultado)}</strong><small>Ingresos menos gastos</small></article>
      <article class="pending"><span>Compromisos pendientes</span><strong>${adminFinDinero(r.manualesPendientes)}</strong><small>Gastos cargados todavía no pagados</small></article>`;
  }

  if ($("resumenIngresosAdministracion")) {
    $("resumenIngresosAdministracion").innerHTML = `
      <div class="adminFinanceBreakdown">
        <div><span>Fratello / Cajas</span><b>${adminFinDinero(r.totalCaja)}</b></div>
        <div><span>Clientes externos cobrados</span><b>${adminFinDinero(r.externosCobrados)}</b></div>
        <div class="pending"><span>Clientes pendientes de cobro</span><b>${adminFinDinero(r.externosPendientes)}</b></div>
        <div class="total"><span>Total contabilizado</span><b>${adminFinDinero(r.ingresos)}</b></div>
      </div>`;
  }

  if ($("resumenGastosAdministracion")) {
    $("resumenGastosAdministracion").innerHTML = `
      <div class="adminFinanceBreakdown">
        <div><span>Gastos tomados de Caja</span><b>${adminFinDinero(r.totalGastosCaja)}</b></div>
        <div><span>Gastos externos pagados</span><b>${adminFinDinero(r.manualesPagados)}</b></div>
        <div class="pending"><span>Gastos pendientes</span><b>${adminFinDinero(r.manualesPendientes)}</b></div>
        <div class="total"><span>Total contabilizado</span><b>${adminFinDinero(r.gastos)}</b></div>
      </div>`;
  }

  renderResumenPresupuestoAdministracion();
}

function asegurarClientesExternosDesdeIngresos() {
  administracionFinanciera.clientesExternos ||= [];
  administracionFinanciera.clientesExternosEliminados ||= [];

  const existentes = new Set(
    administracionFinanciera.clientesExternos.map(item =>
      String(item.nombre || "").trim().toLowerCase()
    )
  );
  const eliminados = new Set(
    administracionFinanciera.clientesExternosEliminados.map(nombre =>
      String(nombre || "").trim().toLowerCase()
    )
  );

  administracionFinanciera.ingresosExternos.forEach(item => {
    const nombre = String(item.cliente || "").trim();
    const clave = nombre.toLowerCase();
    if (!nombre || existentes.has(clave) || eliminados.has(clave)) return;

    administracionFinanciera.clientesExternos.push({
      id: adminFinId("cli"),
      nombre,
      observacion: "",
      activo: true,
      actualizadoEn: new Date().toISOString()
    });
    existentes.add(clave);
  });
}

function clientesExternosActivos() {
  asegurarClientesExternosDesdeIngresos();
  return [...administracionFinanciera.clientesExternos]
    .filter(item => item.activo !== false)
    .sort((a, b) => String(a.nombre).localeCompare(String(b.nombre), "es"));
}

function llenarSelectClientesExternos(clienteSeleccionado = "") {
  const select = $("ingresoAdminCliente");
  if (!select) return;

  const clientes = clientesExternosActivos();
  select.innerHTML = clientes.length
    ? clientes.map(item => `<option value="${adminFinEscapar(item.nombre)}">${adminFinEscapar(item.nombre)}</option>`).join("")
    : '<option value="">Primero agregá un cliente</option>';

  if (clienteSeleccionado) select.value = clienteSeleccionado;
}

function mostrarFormularioClienteExterno(datos = null) {
  $("formClienteExterno")?.classList.remove("hidden");
  if ($("clienteExternoId")) $("clienteExternoId").value = datos?.id || "";
  if ($("clienteExternoNombre")) $("clienteExternoNombre").value = datos?.nombre || "";
  if ($("clienteExternoObservacion")) $("clienteExternoObservacion").value = datos?.observacion || "";
  if ($("clienteExternoActivo")) $("clienteExternoActivo").checked = datos?.activo !== false;
  $("clienteExternoNombre")?.focus();
}

function ocultarFormularioClienteExterno() {
  $("formClienteExterno")?.classList.add("hidden");
  if ($("clienteExternoId")) $("clienteExternoId").value = "";
  if ($("clienteExternoNombre")) $("clienteExternoNombre").value = "";
  if ($("clienteExternoObservacion")) $("clienteExternoObservacion").value = "";
  if ($("clienteExternoActivo")) $("clienteExternoActivo").checked = true;
}

function guardarClienteExterno() {
  const id = $("clienteExternoId")?.value || adminFinId("cli");
  const nombre = String($("clienteExternoNombre")?.value || "").trim();
  const observacion = String($("clienteExternoObservacion")?.value || "").trim();
  const activo = Boolean($("clienteExternoActivo")?.checked);

  if (!nombre) {
    alert("Ingresá el nombre del cliente.");
    return;
  }

  const duplicado = administracionFinanciera.clientesExternos.find(item =>
    item.id !== id &&
    String(item.nombre || "").trim().toLowerCase() === nombre.toLowerCase()
  );
  if (duplicado) {
    alert("Ya existe un cliente con ese nombre.");
    return;
  }

  administracionFinanciera.clientesExternosEliminados ||= [];
  administracionFinanciera.clientesExternosEliminados =
    administracionFinanciera.clientesExternosEliminados.filter(
      eliminado => String(eliminado || "").trim().toLowerCase() !== nombre.toLowerCase()
    );

  const item = { id, nombre, observacion, activo, actualizadoEn: new Date().toISOString() };
  const indice = administracionFinanciera.clientesExternos.findIndex(x => x.id === id);
  if (indice >= 0) administracionFinanciera.clientesExternos[indice] = item;
  else administracionFinanciera.clientesExternos.push(item);

  ocultarFormularioClienteExterno();
  guardarAdministracion();
}

function editarClienteExterno(id) {
  const item = administracionFinanciera.clientesExternos.find(x => x.id === id);
  if (!item) return;
  mostrarFormularioClienteExterno(item);
}

function eliminarClienteExterno(id) {
  const item = administracionFinanciera.clientesExternos.find(x => x.id === id);
  if (!item) return;
  if (!confirm(`¿Eliminar el cliente ${item.nombre}? Los pagos ya registrados se conservarán.`)) return;

  administracionFinanciera.clientesExternosEliminados ||= [];
  const clave = String(item.nombre || "").trim().toLowerCase();
  if (!administracionFinanciera.clientesExternosEliminados.some(
    nombre => String(nombre || "").trim().toLowerCase() === clave
  )) {
    administracionFinanciera.clientesExternosEliminados.push(item.nombre);
  }

  administracionFinanciera.clientesExternos =
    administracionFinanciera.clientesExternos.filter(x => x.id !== id);

  guardarAdministracion();
}

function normalizarMedioPagoAdministracion(valor) {
  const texto = String(valor || "").trim().toLowerCase();
  if (texto.includes("efect")) return "Efectivo";
  if (texto.includes("transfer")) return "Transferencia";
  if (texto.includes("mercado")) return "Mercado Pago";
  if (texto.includes("cheque")) return "Cheque";
  return "Otro";
}

function totalesPorMedioAdministracion(items, campoMonto = "monto", campoMedio = "medio") {
  const totales = {
    "Efectivo": 0,
    "Transferencia": 0,
    "Mercado Pago": 0,
    "Cheque": 0,
    "Otro": 0
  };

  (items || []).forEach(item => {
    const medio = normalizarMedioPagoAdministracion(item?.[campoMedio]);
    totales[medio] += adminFinMonto(item?.[campoMonto]);
  });

  return totales;
}

function htmlDesgloseMediosAdministracion(totales, compacto = false) {
  const orden = ["Efectivo", "Transferencia", "Mercado Pago", "Cheque", "Otro"];
  return `<div class="moneyMethodBreakdown ${compacto ? "compact" : ""}">
    ${orden.map(medio => {
      const monto = adminFinMonto(totales?.[medio]);
      if (!monto && medio !== "Efectivo" && medio !== "Transferencia") return "";
      return `<div><span>${medio}</span><strong>${adminFinDinero(monto)}</strong></div>`;
    }).join("")}
  </div>`;
}

function renderResumenClientesExternos() {
  asegurarClientesExternosDesdeIngresos();
  const ingresos = ingresosExternosDelMesAdministracion()
    .filter(item => item.cobrado !== false);
  const caja = ingresosCajaDelMesAdministracion();

  const totalCaja = caja.reduce((s, item) => s + adminFinMonto(item.monto), 0);
  const totalExternos = ingresos.reduce((s, item) => s + adminFinMonto(item.monto), 0);
  const total = totalCaja + totalExternos;

  const mediosBase = totalesPorMedioAdministracion([
    ...caja.flatMap(item => [
      { monto: item.efectivo, medio: "Efectivo" },
      { monto: item.transferencias, medio: "Transferencia" }
    ]),
    ...ingresos
  ]);
  const medios = aplicarTransferenciasEntreMedios(mediosBase);

  if ($("totalIngresosMesResumen")) {
    $("totalIngresosMesResumen").textContent = adminFinDinero(total);
  }
  if ($("desgloseIngresosMesResumen")) {
    $("desgloseIngresosMesResumen").innerHTML =
      htmlDesgloseMediosAdministracion(medios, true);
  }
  if ($("resumenOrigenIngresos")) {
    $("resumenOrigenIngresos").innerHTML = `
      <article><span>🥖 Panadería Fratello · Caja</span><strong>${adminFinDinero(totalCaja)}</strong></article>
      <article><span>👥 Clientes externos</span><strong>${adminFinDinero(totalExternos)}</strong></article>
    `;
  }

  const host = $("tarjetasClientesExternos");
  if (!host) return;

  const esClientePanaderiaFratello = nombre => {
    const normalizado = normalizarPedidoInteligente(String(nombre || ""));
    return normalizado === "panaderia fratello";
  };

  const clientes = [...administracionFinanciera.clientesExternos]
    .filter(cliente => !esClientePanaderiaFratello(cliente.nombre))
    .sort((a, b) => String(a.nombre).localeCompare(String(b.nombre), "es"));

  const efectivoCaja = caja.reduce((s, item) => s + adminFinMonto(item.efectivo), 0);
  const transferenciasCaja = caja.reduce((s, item) => s + adminFinMonto(item.transferencias), 0);
  const mediosCaja = {
    "Efectivo": efectivoCaja,
    "Transferencia": transferenciasCaja,
    "Mercado Pago": 0,
    "Cheque": 0,
    "Otro": 0
  };

  const tarjetaPanaderia = `<details class="ingresoClienteCard ingresoClientePanaderia">
    <summary>
      <span>
        <strong>🥖 Panadería Fratello</strong>
        <small>Ingresos automáticos de Caja</small>
        ${htmlDesgloseMediosAdministracion(mediosCaja, true)}
      </span>
      <b>${adminFinDinero(totalCaja)}</b>
    </summary>
    <div class="ingresoClienteDetalle">
      ${caja.length
        ? caja.map(cierre => `<div class="ingresoClientePago">
            <span>
              <strong>${adminFinEscapar(cierre.fecha)}</strong>
              <small>${adminFinEscapar(cierre.descripcion || "Cierre de Caja")}</small>
            </span>
            <b>${adminFinDinero(cierre.monto)}</b>
          </div>`).join("")
        : `<div class="ingresoClienteVacio">No hay cierres de Caja cargados en este mes.</div>`
      }
    </div>
  </details>`;

  const tarjetasClientes = clientes.map(cliente => {
    const pagos = ingresos
      .filter(item => String(item.cliente || "").trim().toLowerCase() ===
        String(cliente.nombre || "").trim().toLowerCase())
      .sort((a, b) => String(b.fecha).localeCompare(String(a.fecha)));

    const totalCliente = pagos.reduce((s, item) => s + adminFinMonto(item.monto), 0);
    const mediosCliente = totalesPorMedioAdministracion(pagos);

    return `<details class="ingresoClienteCard">
      <summary>
        <span>
          <strong>${adminFinEscapar(cliente.nombre)}</strong>
          ${cliente.observacion ? `<small>${adminFinEscapar(cliente.observacion)}</small>` : ""}
          ${htmlDesgloseMediosAdministracion(mediosCliente, true)}
        </span>
        <b>${adminFinDinero(totalCliente)}</b>
      </summary>
      <div class="ingresoClienteDetalle">
        ${pagos.length
          ? pagos.map(pago => `<div class="ingresoClientePago">
              <span>
                <strong>${adminFinEscapar(pago.fecha)}</strong>
                <small>${adminFinEscapar(pago.descripcion || pago.medio || "Pago")}</small>
              </span>
              <b>${adminFinDinero(pago.monto)}</b>
            </div>`).join("")
          : `<div class="ingresoClienteVacio">Sin pagos cobrados en este mes.</div>`
        }
        <div class="ingresoClienteAcciones">
          <button type="button" onclick="editarClienteExterno('${cliente.id}')">Editar cliente</button>
          <button type="button" onclick="eliminarClienteExterno('${cliente.id}')">Eliminar cliente</button>
        </div>
      </div>
    </details>`;
  }).join("");

  host.innerHTML = tarjetaPanaderia + tarjetasClientes;
}

function mostrarVistaIngresos(tipo = "resumen") {
  const resumen = tipo === "resumen";
  $("vistaResumenIngresos")?.classList.toggle("hidden", !resumen);
  $("vistaCargaIngresos")?.classList.toggle("hidden", resumen);
  $("btnVistaResumenIngresos")?.classList.toggle("active", resumen);
  $("btnVistaCargaIngresos")?.classList.toggle("active", !resumen);

  if (resumen) renderResumenClientesExternos();
  else llenarSelectClientesExternos();
}

function renderIngresosAdministracion() {
  asegurarClientesExternosDesdeIngresos();
  renderResumenClientesExternos();
  llenarSelectClientesExternos();

  const externos = ingresosExternosDelMesAdministracion();
  if ($("listaIngresosExternosAdministracion")) {
    $("listaIngresosExternosAdministracion").innerHTML = externos.length
      ? adminFinTabla(
          ["Fecha", "Cliente", "Descripción", "Medio", "Estado", "Monto", ""],
          externos.map(item => `<tr>
            <td>${adminFinEscapar(item.fecha)}</td>
            <td><strong>${adminFinEscapar(item.cliente)}</strong></td>
            <td>${adminFinEscapar(item.descripcion || "")}</td>
            <td>${adminFinEscapar(item.medio || "")}</td>
            <td><span class="statusPill ${item.cobrado !== false ? "paid" : "pending"}">${item.cobrado !== false ? "Cobrado" : "Pendiente"}</span></td>
            <td><strong>${adminFinDinero(item.monto)}</strong></td>
            <td class="adminFinanceRowActions">
              <button type="button" onclick="editarIngresoAdministracion('${item.id}')">Editar</button>
              <button type="button" onclick="eliminarIngresoAdministracion('${item.id}')">Eliminar</button>
            </td>
          </tr>`)
        )
      : adminFinVacio("No cargaste pagos de clientes externos en este mes.");
  }
}

let filtroCategoriaGastosActual = "Todos";

function categoriaResumenGasto(categoria, origen = "") {
  const texto = String(categoria || "").toLowerCase();

  if (String(origen || "").toLowerCase().includes("caja")) return "Atención";
  if (texto.includes("empleado") || texto.includes("sueldo") || texto.includes("jornal")) return "Empleados";
  if (
    texto.includes("proveedor") ||
    texto.includes("insumo") ||
    texto.includes("materia prima")
  ) return "Insumos";
  if (
    texto.includes("atención") ||
    texto.includes("atencion") ||
    texto.includes("panadería") ||
    texto.includes("panaderia")
  ) return "Atención";

  return "Generales";
}

function todosGastosResumenMes() {
  const manuales = gastosManualesDelMesAdministracion().map(item => ({
    id: item.id,
    fecha: item.fecha,
    motivo: item.motivo,
    monto: adminFinMonto(item.monto),
    categoriaResumen: categoriaResumenGasto(item.categoria, item.origen),
    medio: item.medio || "Otro",
    origen: "Manual"
  }));

  const caja = gastosCajaDelMesAdministracion().map((item, indice) => ({
    id: `caja-${item.fecha}-${indice}`,
    fecha: item.fecha,
    motivo: item.motivo,
    monto: adminFinMonto(item.monto),
    categoriaResumen: "Atención",
    medio: "Efectivo",
    origen: "Caja"
  }));

  return [...manuales, ...caja].sort((a, b) =>
    String(a.fecha).localeCompare(String(b.fecha))
  );
}

function semanaMesGasto(fechaISO) {
  const dia = Number(String(fechaISO || "").slice(8, 10)) || 1;
  if (dia <= 7) return 1;
  if (dia <= 14) return 2;
  if (dia <= 21) return 3;
  return 4;
}

function rangoSemanaGastos(numero, mes) {
  const [anio, numeroMes] = String(mes).split("-").map(Number);
  const ultimoDia = new Date(anio, numeroMes, 0).getDate();
  const rangos = {
    1: [1, Math.min(7, ultimoDia)],
    2: [8, Math.min(14, ultimoDia)],
    3: [15, Math.min(21, ultimoDia)],
    4: [22, ultimoDia]
  };
  const [desde, hasta] = rangos[numero];
  return `${String(desde).padStart(2, "0")} al ${String(hasta).padStart(2, "0")}`;
}

function renderResumenSemanalGastos() {
  const gastos = todosGastosResumenMes();
  const mes = mesSeleccionadoAdministracion();
  const categorias = ["Empleados", "Insumos", "Atención", "Generales"];

  const totalMes = gastos.reduce((s, item) => s + item.monto, 0);
  if ($("totalGastosMesResumen")) {
    $("totalGastosMesResumen").textContent = adminFinDinero(totalMes);
  }
  if ($("desgloseGastosMesResumen")) {
    $("desgloseGastosMesResumen").innerHTML =
      htmlDesgloseMediosAdministracion(totalesPorMedioAdministracion(gastos), true);
  }

  if ($("tarjetasCategoriasGastos")) {
    $("tarjetasCategoriasGastos").innerHTML = categorias.map(categoria => {
      const total = gastos
        .filter(item => item.categoriaResumen === categoria)
        .reduce((s, item) => s + item.monto, 0);

      const iconos = {
        Empleados: "👥",
        Insumos: "📦",
        Atención: "🏪",
        Generales: "🧾"
      };

      const itemsCategoria = gastos.filter(item => item.categoriaResumen === categoria);
      const mediosCategoria = totalesPorMedioAdministracion(itemsCategoria);

      return `<article>
        <span>${iconos[categoria]} ${categoria}</span>
        <strong>${adminFinDinero(total)}</strong>
        ${htmlDesgloseMediosAdministracion(mediosCategoria, true)}
      </article>`;
    }).join("");
  }

  const filtrados = filtroCategoriaGastosActual === "Todos"
    ? gastos
    : gastos.filter(item => item.categoriaResumen === filtroCategoriaGastosActual);

  const host = $("resumenSemanalGastos");
  if (!host) return;

  if (!filtrados.length) {
    host.innerHTML = adminFinVacio("No hay gastos para esta categoría en el mes seleccionado.");
    return;
  }

  host.innerHTML = [1, 2, 3, 4].map(numeroSemana => {
    const items = filtrados.filter(item => semanaMesGasto(item.fecha) === numeroSemana);
    const total = items.reduce((s, item) => s + item.monto, 0);

    return `<details class="gastosSemanaPanel">
      <summary>
        <span>
          <strong>Semana ${numeroSemana}</strong>
          <small>${rangoSemanaGastos(numeroSemana, mes)}</small>
        </span>
        <b>${adminFinDinero(total)}</b>
      </summary>
      <div class="gastosSemanaDetalle">
        ${items.length
          ? items.map(item => `<div class="gastoSemanaFila">
              <span>
                <strong>${adminFinEscapar(item.motivo)}</strong>
                <small>${adminFinEscapar(item.fecha)} · ${adminFinEscapar(item.categoriaResumen)}${item.origen === "Caja" ? " · Caja" : ""}</small>
              </span>
              <b>${adminFinDinero(item.monto)}</b>
            </div>`).join("")
          : `<div class="gastosSemanaVacia">Sin gastos en esta semana.</div>`
        }
        <div class="gastosSemanaTotal">
          <span>
            <strong>Total semana ${numeroSemana}</strong>
            ${htmlDesgloseMediosAdministracion(totalesPorMedioAdministracion(items), true)}
          </span>
          <strong>${adminFinDinero(total)}</strong>
        </div>
      </div>
    </details>`;
  }).join("");
}

function mostrarVistaGastos(tipo = "resumen") {
  const resumen = tipo === "resumen";
  $("vistaResumenGastos")?.classList.toggle("hidden", !resumen);
  $("vistaCargaGastos")?.classList.toggle("hidden", resumen);
  $("btnVistaResumenGastos")?.classList.toggle("active", resumen);
  $("btnVistaCargaGastos")?.classList.toggle("active", !resumen);

  if (resumen) renderResumenSemanalGastos();
}

function renderGastosAdministracion() {
  renderResumenSemanalGastos();
  const caja = gastosCajaDelMesAdministracion();
  const manuales = gastosManualesDelMesAdministracion();

  if ($("gastosCajaAdministracion")) {
    $("gastosCajaAdministracion").innerHTML = caja.length
      ? adminFinTabla(
          ["Fecha", "Motivo", "Origen", "Monto"],
          caja.map(item => `<tr>
            <td>${adminFinEscapar(item.fecha)}</td>
            <td><strong>${adminFinEscapar(item.motivo)}</strong></td>
            <td><span class="originBadge caja">${adminFinEscapar(item.origen)}</span></td>
            <td><strong>${adminFinDinero(item.monto)}</strong></td>
          </tr>`)
        )
      : adminFinVacio("No hay gastos cargados en los cierres de Caja de este mes.");
  }

  if ($("listaGastosManualesAdministracion")) {
    $("listaGastosManualesAdministracion").innerHTML = manuales.length
      ? adminFinTabla(
          ["Fecha", "Categoría", "Motivo", "Medio", "Estado", "Monto", ""],
          manuales.map(item => `<tr>
            <td>${adminFinEscapar(item.fecha)}</td>
            <td>${adminFinEscapar(item.categoria)}</td>
            <td><strong>${adminFinEscapar(item.motivo)}</strong></td>
            <td>${adminFinEscapar(item.medio || "")}</td>
            <td><span class="statusPill ${item.pagado !== false ? "paid" : "pending"}">${item.pagado !== false ? "Pagado" : "Pendiente"}</span></td>
            <td><strong>${adminFinDinero(item.monto)}</strong></td>
            <td class="adminFinanceRowActions">
              <button type="button" onclick="editarGastoAdministracion('${item.id}')">Editar</button>
              <button type="button" onclick="eliminarGastoAdministracion('${item.id}')">Eliminar</button>
            </td>
          </tr>`)
        )
      : adminFinVacio("No cargaste gastos por fuera de Caja en este mes.");
  }
}

function gastoRealPorCategoriaAdministracion(categoria) {
  const manual = gastosManualesDelMesAdministracion()
    .filter(x => x.pagado !== false && x.categoria === categoria)
    .reduce((s, x) => s + adminFinMonto(x.monto), 0);

  // Los gastos de Caja se muestran separados porque las chicas no eligen categoría.
  const caja = categoria === "Gastos de Caja"
    ? gastosCajaDelMesAdministracion().reduce((s, x) => s + x.monto, 0)
    : 0;

  return manual + caja;
}

function renderPresupuestoAdministracion() {
  const items = presupuestosDelMesAdministracion();

  if (!$("listaPresupuestoAdministracion")) return;

  $("listaPresupuestoAdministracion").innerHTML = items.length
    ? adminFinTabla(
        ["Concepto", "Categoría", "Presupuestado", "Gastado", "Diferencia", ""],
        items.map(item => {
          const gastado = gastoRealPorCategoriaAdministracion(item.categoria);
          const diferencia = adminFinMonto(item.monto) - gastado;
          return `<tr>
            <td><strong>${adminFinEscapar(item.concepto)}</strong></td>
            <td>${adminFinEscapar(item.categoria)}</td>
            <td>${adminFinDinero(item.monto)}</td>
            <td>${adminFinDinero(gastado)}</td>
            <td class="${diferencia >= 0 ? "amountPositive" : "amountNegative"}"><strong>${adminFinDinero(diferencia)}</strong></td>
            <td class="adminFinanceRowActions">
              <button type="button" onclick="editarPresupuestoAdministracion('${item.id}')">Editar</button>
              <button type="button" onclick="eliminarPresupuestoAdministracion('${item.id}')">Eliminar</button>
            </td>
          </tr>`;
        })
      )
    : adminFinVacio("Todavía no cargaste el presupuesto para este mes.");
}

function renderResumenPresupuestoAdministracion() {
  const items = presupuestosDelMesAdministracion();
  if (!$("resumenPresupuestoAdministracion")) return;

  if (!items.length) {
    $("resumenPresupuestoAdministracion").innerHTML = adminFinVacio("Cargá el presupuesto del mes para ver el comparativo.");
    return;
  }

  const previsto = items.reduce((s, x) => s + adminFinMonto(x.monto), 0);
  const categorias = [...new Set(items.map(x => x.categoria))];
  const gastado = categorias.reduce((s, categoria) => s + gastoRealPorCategoriaAdministracion(categoria), 0);
  const diferencia = previsto - gastado;
  const porcentaje = previsto > 0 ? Math.min(100, Math.round(gastado / previsto * 100)) : 0;

  $("resumenPresupuestoAdministracion").innerHTML = `
    <div class="adminBudgetOverview">
      <div><span>Presupuesto</span><strong>${adminFinDinero(previsto)}</strong></div>
      <div><span>Gastado</span><strong>${adminFinDinero(gastado)}</strong></div>
      <div class="${diferencia >= 0 ? "amountPositive" : "amountNegative"}"><span>Disponible / Exceso</span><strong>${adminFinDinero(diferencia)}</strong></div>
    </div>
    <div class="adminBudgetBar"><i style="width:${porcentaje}%"></i></div>
    <small>${porcentaje}% del presupuesto utilizado.</small>`;
}

function renderAdministracionFinanciera() {
  if (!administracionPrivadaActiva) return;
  const mes = mesSeleccionadoAdministracion();
  if ($("periodoAdministracionTexto")) {
    const fecha = new Date(`${mes}-01T12:00:00`);
    $("periodoAdministracionTexto").textContent = fecha.toLocaleDateString("es-AR", { month: "long", year: "numeric" });
  }
  renderResumenAdministracion();
  renderIngresosAdministracion();
  renderGastosAdministracion();
  renderPresupuestoAdministracion();
}

function abrirAdministracionPrivada() {
  if (!tieneRolAdministrador()) {
    administracionPrivadaActiva = false;
    $("panelAdministracionLogin")?.classList.remove("hidden");
    $("panelAdministracionPrivado")?.classList.add("hidden");
    return false;
  }
  administracionPrivadaActiva = true;
  asegurarCajaPrivadaDentroAdministracion();
  instalarNavegacionAdministracionEstable();
  $("panelAdministracionLogin")?.classList.add("hidden");
  $("panelAdministracionPrivado")?.classList.remove("hidden");
  $("panelAdministracionPrivado")?.removeAttribute("style");

  const yaEstaEnAdministracion =
    document.getElementById("seccionAdministracion")?.classList.contains("active");

  if (yaEstaEnAdministracion && vistaAdministracionActual) {
    restaurarVistaAdministracionActual();
  } else if (!vistaAdministracionActual) {
    mostrarMenuAdministracion();
  }

  renderAdministracionFinanciera();
  renderSeguridadCompleta();
  registrarActividadAdministracion();
  return true;
}

function ingresarAdministracion() {
  if (!tieneRolAdministrador()) {
    mostrarModalAdministrador();
    return;
  }
  abrirAdministracionPrivada();
}

function bloquearAdministracion() {
  administracionPrivadaActiva = false;
  clearTimeout(temporizadorAdministracion);
  $("panelAdministracionPrivado")?.classList.add("hidden");
  $("panelAdministracionLogin")?.classList.toggle("hidden", Boolean(usuarioAdministradorActual));
}

function registrarActividadAdministracion() {
  if (!administracionPrivadaActiva) return;
  clearTimeout(temporizadorAdministracion);
  temporizadorAdministracion = setTimeout(bloquearAdministracion, ADMIN_FIN_TIMEOUT_MS);
}

function cambiarTabAdministracion(nombre) {
  document.querySelectorAll("[data-admin-tab]").forEach(btn => {
    btn.classList.toggle("active", btn.dataset.adminTab === nombre);
  });
  document.querySelectorAll("[data-admin-panel]").forEach(panel => {
    panel.classList.toggle("active", panel.dataset.adminPanel === nombre);
  });
}

function mostrarFormularioAdministracion(tipo, datos = null) {
  const id = tipo === "ingreso" ? "formIngresoAdministracion"
    : tipo === "gasto" ? "formGastoAdministracion"
    : "formPresupuestoAdministracion";
  $(id)?.classList.remove("hidden");

  if (tipo === "ingreso") {
    $("ingresoAdminId").value = datos?.id || "";
    $("ingresoAdminFecha").value = datos?.fecha || adminFinHoy();
    llenarSelectClientesExternos(datos?.cliente || "");
    if ($("ingresoAdminCliente")) $("ingresoAdminCliente").value = datos?.cliente || "";
    $("ingresoAdminMonto").value = datos?.monto || "";
    $("ingresoAdminMedio").value = datos?.medio || "Transferencia";
    $("ingresoAdminCobrado").checked = datos?.cobrado !== false;
    $("ingresoAdminDescripcion").value = datos?.descripcion || "";
  } else if (tipo === "gasto") {
    $("gastoAdminId").value = datos?.id || "";
    $("gastoAdminFecha").value = datos?.fecha || adminFinHoy();
    $("gastoAdminCategoria").value = datos?.categoria || "Proveedores / Insumos";
    $("gastoAdminMotivo").value = datos?.motivo || "";
    $("gastoAdminMonto").value = datos?.monto || "";
    $("gastoAdminMedio").value = datos?.medio || "Transferencia";
    $("gastoAdminPagado").checked = datos?.pagado !== false;
  } else {
    $("presupuestoAdminId").value = datos?.id || "";
    $("presupuestoAdminConcepto").value = datos?.concepto || "";
    $("presupuestoAdminCategoria").value = datos?.categoria || "Proveedores / Insumos";
    $("presupuestoAdminMonto").value = datos?.monto || "";
  }
}

function ocultarFormularioAdministracion(tipo) {
  const id = tipo === "ingreso" ? "formIngresoAdministracion"
    : tipo === "gasto" ? "formGastoAdministracion"
    : "formPresupuestoAdministracion";
  $(id)?.classList.add("hidden");
}

function guardarIngresoAdministracion() {
  const id = $("ingresoAdminId")?.value || adminFinId("ing");
  const item = {
    id,
    fecha: $("ingresoAdminFecha")?.value || adminFinHoy(),
    cliente: String($("ingresoAdminCliente")?.value || "").trim(),
    monto: adminFinMonto($("ingresoAdminMonto")?.value),
    medio: $("ingresoAdminMedio")?.value || "Transferencia",
    cobrado: Boolean($("ingresoAdminCobrado")?.checked),
    descripcion: String($("ingresoAdminDescripcion")?.value || "").trim(),
    actualizadoEn: new Date().toISOString()
  };

  if (!item.cliente || !item.monto) {
    alert("Completá cliente y monto.");
    return;
  }

  asegurarClientesExternosDesdeIngresos();
  const clienteExiste = administracionFinanciera.clientesExternos.some(cliente =>
    String(cliente.nombre || "").trim().toLowerCase() === item.cliente.toLowerCase()
  );
  if (!clienteExiste) {
    administracionFinanciera.clientesExternos.push({
      id: adminFinId("cli"),
      nombre: item.cliente,
      observacion: "",
      activo: true,
      actualizadoEn: new Date().toISOString()
    });
  }

  const indice = administracionFinanciera.ingresosExternos.findIndex(x => x.id === id);
  if (indice >= 0) administracionFinanciera.ingresosExternos[indice] = item;
  else administracionFinanciera.ingresosExternos.push(item);

  ocultarFormularioAdministracion("ingreso");
  guardarAdministracion();
}

function editarIngresoAdministracion(id) {
  const item = administracionFinanciera.ingresosExternos.find(x => x.id === id);
  if (!item) return;
  activarTabAdministracion("ingresos");
  mostrarVistaIngresos("carga");
  llenarSelectClientesExternos(item.cliente);
  mostrarFormularioAdministracion("ingreso", item);
}

function eliminarIngresoAdministracion(id) {
  if (!confirm("¿Eliminar este ingreso?")) return;
  administracionFinanciera.ingresosExternos = administracionFinanciera.ingresosExternos.filter(x => x.id !== id);
  guardarAdministracion();
}

function guardarGastoAdministracion() {
  const id = $("gastoAdminId")?.value || adminFinId("gas");
  const item = {
    id,
    fecha: $("gastoAdminFecha")?.value || adminFinHoy(),
    categoria: $("gastoAdminCategoria")?.value || "Otros",
    motivo: String($("gastoAdminMotivo")?.value || "").trim(),
    monto: adminFinMonto($("gastoAdminMonto")?.value),
    medio: $("gastoAdminMedio")?.value || "Transferencia",
    pagado: Boolean($("gastoAdminPagado")?.checked),
    origen: "Manual",
    actualizadoEn: new Date().toISOString()
  };

  if (!item.motivo || !item.monto) {
    alert("Completá motivo y monto.");
    return;
  }

  const indice = administracionFinanciera.gastosManuales.findIndex(x => x.id === id);
  if (indice >= 0) administracionFinanciera.gastosManuales[indice] = item;
  else administracionFinanciera.gastosManuales.push(item);

  ocultarFormularioAdministracion("gasto");
  guardarAdministracion();
}

function editarGastoAdministracion(id) {
  const item = administracionFinanciera.gastosManuales.find(x => x.id === id);
  if (!item) return;
  cambiarTabAdministracion("gastos");
  mostrarFormularioAdministracion("gasto", item);
}

function eliminarGastoAdministracion(id) {
  if (!confirm("¿Eliminar este gasto?")) return;
  administracionFinanciera.gastosManuales = administracionFinanciera.gastosManuales.filter(x => x.id !== id);
  guardarAdministracion();
}

function guardarPresupuestoAdministracion() {
  const id = $("presupuestoAdminId")?.value || adminFinId("pre");
  const item = {
    id,
    mes: mesSeleccionadoAdministracion(),
    concepto: String($("presupuestoAdminConcepto")?.value || "").trim(),
    categoria: $("presupuestoAdminCategoria")?.value || "Otros",
    monto: adminFinMonto($("presupuestoAdminMonto")?.value),
    actualizadoEn: new Date().toISOString()
  };

  if (!item.concepto || !item.monto) {
    alert("Completá concepto y monto previsto.");
    return;
  }

  const indice = administracionFinanciera.presupuestos.findIndex(x => x.id === id);
  if (indice >= 0) administracionFinanciera.presupuestos[indice] = item;
  else administracionFinanciera.presupuestos.push(item);

  ocultarFormularioAdministracion("presupuesto");
  guardarAdministracion();
}

function editarPresupuestoAdministracion(id) {
  const item = administracionFinanciera.presupuestos.find(x => x.id === id);
  if (!item) return;
  cambiarTabAdministracion("presupuesto");
  mostrarFormularioAdministracion("presupuesto", item);
}

function eliminarPresupuestoAdministracion(id) {
  if (!confirm("¿Eliminar este concepto del presupuesto?")) return;
  administracionFinanciera.presupuestos = administracionFinanciera.presupuestos.filter(x => x.id !== id);
  guardarAdministracion();
}

function tituloTabAdministracion(nombre) {
  const titulos = {
    resumen: "📊 Resumen",
    ingresos: "💰 Ingresos",
    gastos: "💸 Gastos",
    presupuesto: "📅 Presupuesto",
    caja: "🏦 Caja privada",
    usuarios: "👥 Usuarios",
    dispositivos: "📱 Dispositivos",
    auditoria: "📜 Auditoría",
    backup: "💾 Copias"
  };
  return titulos[nombre] || "Administración";
}

let vistaAdministracionActual = "";

function restaurarVistaAdministracionActual() {
  if (!vistaAdministracionActual) return false;
  return activarTabAdministracion(vistaAdministracionActual, { restaurando: true });
}

function mostrarMenuAdministracion() {
  vistaAdministracionActual = "";
  asegurarCajaPrivadaDentroAdministracion();
  const panel = $("panelAdministracionPrivado");
  if (!panel) return;
  panel.classList.remove("adminSubvistaActiva");
  panel.querySelector(".adminFinanceTabs")?.classList.remove("hidden");
  $("adminVistaEncabezado")?.classList.add("hidden");
  panel.querySelectorAll("[data-admin-tab]").forEach(boton => {
    boton.classList.remove("active");
    boton.setAttribute("aria-selected", "false");
  });
  panel.querySelectorAll("[data-admin-panel]").forEach(seccion => {
    seccion.classList.remove("active");
    seccion.classList.add("hidden");
    seccion.setAttribute("aria-hidden", "true");
    seccion.style.display = "none";
  });
  window.scrollTo({ top: document.getElementById("seccionAdministracion")?.offsetTop || 0, behavior: "smooth" });
}

function activarTabAdministracion(nombre = "resumen", opciones = {}) {
  const tabsSeguras = ["caja", "usuarios", "dispositivos", "auditoria", "backup"];
  if (tabsSeguras.includes(nombre) && !tieneRolAdministrador()) {
    mostrarModalAdministrador();
    return false;
  }
  asegurarCajaPrivadaDentroAdministracion();
  vistaAdministracionActual = nombre;
  const panelAdministracion = $("panelAdministracionPrivado");
  panelAdministracion?.classList.add("adminSubvistaActiva");
  panelAdministracion?.querySelector(".adminFinanceTabs")?.classList.add("hidden");
  $("adminVistaEncabezado")?.classList.remove("hidden");
  if ($("tituloVistaAdministracion")) $("tituloVistaAdministracion").textContent = tituloTabAdministracion(nombre);
  const botones = [...document.querySelectorAll("#panelAdministracionPrivado [data-admin-tab]")];
  const paneles = [...document.querySelectorAll("#panelAdministracionPrivado [data-admin-panel]")];
  let botonObjetivo = botones.find(b => b.dataset.adminTab === nombre);
  let panelObjetivo = paneles.find(p => p.dataset.adminPanel === nombre);
  if (!botonObjetivo || !panelObjetivo) {
    nombre = "resumen";
    botonObjetivo = botones.find(b => b.dataset.adminTab === nombre);
    panelObjetivo = paneles.find(p => p.dataset.adminPanel === nombre);
  }
  botones.forEach(boton => {
    const activo = boton === botonObjetivo;
    boton.classList.toggle("active", activo);
    boton.setAttribute("aria-selected", activo ? "true" : "false");
  });
  paneles.forEach(panel => {
    const activo = panel === panelObjetivo;
    panel.classList.toggle("active", activo);
    panel.classList.toggle("hidden", !activo);
    panel.setAttribute("aria-hidden", activo ? "false" : "true");
    panel.style.display = activo ? "block" : "none";
  });
  if (!panelObjetivo) {
    console.error("Administración: no se encontró el panel solicitado", nombre);
    return false;
  }
  switch (nombre) {
    case "resumen": case "presupuesto":
      renderAdministracionFinanciera(); break;
    case "ingresos":
      renderAdministracionFinanciera();
      mostrarVistaIngresos("resumen");
      break;
    case "gastos":
      renderAdministracionFinanciera();
      mostrarVistaGastos("resumen");
      break;
    case "caja":
      cajaAdminActivo = true; renderCajaAdminSeguro(); break;
    case "usuarios": case "dispositivos": case "auditoria": case "backup":
      renderSeguridadCompleta(); break;
  }
  panelObjetivo.scrollTop = 0;
  return true;
}

function asegurarCajaPrivadaDentroAdministracion() {
  const panelCaja = $("panelCajaAdmin");
  const panelAdministracion = $("panelAdministracionPrivado");
  const tabs = panelAdministracion?.querySelector(".adminFinanceTabs");
  if (!panelCaja || !panelAdministracion) return false;
  if (panelCaja.parentElement !== panelAdministracion) panelAdministracion.appendChild(panelCaja);
  panelCaja.dataset.adminPanel = "caja";
  panelCaja.classList.add("adminFinanceTab");
  panelCaja.classList.remove("hidden");
  panelCaja.removeAttribute("style");
  if (tabs && !tabs.querySelector('[data-admin-tab="caja"]')) {
    const botonCaja = document.createElement("button");
    botonCaja.type = "button"; botonCaja.dataset.adminTab = "caja";
    botonCaja.innerHTML = '🏦 Caja privada <span class="adminTabNew">NUEVO</span>';
    tabs.appendChild(botonCaja);
  }
  return true;
}


function instalarNavegacionAdministracionEstable() {
  const panel = $("panelAdministracionPrivado");
  if (!panel || panel.dataset.navEstable === "1") return;
  panel.dataset.navEstable = "1";
  panel.addEventListener("click", evento => {
    const boton = evento.target.closest("[data-admin-tab]");
    if (!boton || !panel.contains(boton)) return;
    evento.preventDefault();
    activarTabAdministracion(boton.dataset.adminTab || "resumen");
  });
  $("btnAbrirControlCajaAdministracion")?.addEventListener("click", evento => {
    evento.preventDefault();
    if (activarTabAdministracion("caja")) $("panelCajaAdmin")?.scrollIntoView({ behavior: "smooth", block: "start" });
  });
}

function iniciarModuloAdministracion() {
  if (window.__FRATELLO_ADMIN_FIN_INICIADA__) return;
  window.__FRATELLO_ADMIN_FIN_INICIADA__ = true;

  asegurarCajaPrivadaDentroAdministracion();
  instalarNavegacionAdministracionEstable();
  iniciarSeguridadFratello();
  cargarAdministracionLocal();
  sincronizarSelectoresMesAdministracion(adminFinMesActual());


  $("btnSalirAdministracion")?.addEventListener("click", cerrarSesionAdministrador);
  $("btnActualizarAdministracion")?.addEventListener("click", renderAdministracionFinanciera);
  $("mesAdministracion")?.addEventListener("change", evento => {
    sincronizarSelectoresMesAdministracion(evento.target.value, "principal");
    renderAdministracionFinanciera();
  });
  $("mesAdministracionRapido")?.addEventListener("change", evento => {
    sincronizarSelectoresMesAdministracion(evento.target.value, "rapido");
    renderAdministracionFinanciera();
  });

  $("resumenMovilAdministracion")?.addEventListener("input", evento => {
    if (evento.target.matches("#plataRealEfectivoManual, #plataRealTransferenciasManual, #plataRealChequesManual")) {
      recalcularPlataRealManualEnPantalla();
    }
  });
  $("resumenMovilAdministracion")?.addEventListener("click", evento => {
    if (evento.target.closest("#btnGuardarPlataRealManual")) {
      guardarPlataRealManualDesdeResumen();
      return;
    }
    if (evento.target.closest("#btnAbrirTransferenciaDinero")) {
      $("formTransferenciaDinero")?.classList.toggle("hidden");
      return;
    }
    if (evento.target.closest("#btnCancelarTransferenciaDinero")) {
      $("formTransferenciaDinero")?.classList.add("hidden");
      return;
    }
    if (evento.target.closest("#btnGuardarTransferenciaDinero")) {
      guardarTransferenciaDinero();
    }
  });
  $("btnVolverMenuAdministracion")?.addEventListener("click", mostrarMenuAdministracion);

  $("btnAbrirControlCajaAdministracion")?.addEventListener("click", () => {
    activarTabAdministracion("caja");
    document.getElementById("panelCajaAdmin")?.scrollIntoView({ behavior: "smooth", block: "start" });
  });

  $("btnVistaResumenIngresos")?.addEventListener("click", () => mostrarVistaIngresos("resumen"));
  $("btnVistaCargaIngresos")?.addEventListener("click", () => mostrarVistaIngresos("carga"));
  $("btnAgregarClienteExterno")?.addEventListener("click", () => mostrarFormularioClienteExterno());
  $("btnCancelarClienteExterno")?.addEventListener("click", ocultarFormularioClienteExterno);
  $("btnGuardarClienteExterno")?.addEventListener("click", guardarClienteExterno);

  $("btnNuevoIngresoAdministracion")?.addEventListener("click", () => mostrarFormularioAdministracion("ingreso"));
  $("btnCancelarIngresoAdministracion")?.addEventListener("click", () => ocultarFormularioAdministracion("ingreso"));
  $("btnGuardarIngresoAdministracion")?.addEventListener("click", guardarIngresoAdministracion);

  $("btnVistaResumenGastos")?.addEventListener("click", () => mostrarVistaGastos("resumen"));
  $("btnVistaCargaGastos")?.addEventListener("click", () => mostrarVistaGastos("carga"));

  $("filtrosCategoriasGastos")?.addEventListener("click", evento => {
    const boton = evento.target.closest("[data-gasto-categoria]");
    if (!boton) return;

    filtroCategoriaGastosActual = boton.dataset.gastoCategoria || "Todos";
    $("filtrosCategoriasGastos")?.querySelectorAll("button").forEach(item => {
      item.classList.toggle("active", item === boton);
    });
    renderResumenSemanalGastos();
  });

  $("btnNuevoGastoAdministracion")?.addEventListener("click", () => mostrarFormularioAdministracion("gasto"));
  $("btnCancelarGastoAdministracion")?.addEventListener("click", () => ocultarFormularioAdministracion("gasto"));
  $("btnGuardarGastoAdministracion")?.addEventListener("click", guardarGastoAdministracion);

  $("btnNuevoPresupuestoAdministracion")?.addEventListener("click", () => mostrarFormularioAdministracion("presupuesto"));
  $("btnCancelarPresupuestoAdministracion")?.addEventListener("click", () => ocultarFormularioAdministracion("presupuesto"));
  $("btnGuardarPresupuestoAdministracion")?.addEventListener("click", guardarPresupuestoAdministracion);

  ["click", "touchstart", "keydown", "input"].forEach(nombre => {
    document.addEventListener(nombre, registrarActividadAdministracion, { passive: true });
  });

  window.addEventListener("pagehide", bloquearAdministracion);
}

window.editarIngresoAdministracion = editarIngresoAdministracion;
window.eliminarTransferenciaDinero = eliminarTransferenciaDinero;
window.editarClienteExterno = editarClienteExterno;
window.eliminarClienteExterno = eliminarClienteExterno;
window.eliminarIngresoAdministracion = eliminarIngresoAdministracion;
window.editarGastoAdministracion = editarGastoAdministracion;
window.eliminarGastoAdministracion = eliminarGastoAdministracion;
window.editarPresupuestoAdministracion = editarPresupuestoAdministracion;
window.eliminarPresupuestoAdministracion = eliminarPresupuestoAdministracion;


/* =========================================================
   FRATELLO CAJA v1 — v3.9.0
   ========================================================= */

const CAJA_STORAGE_KEY = "fratello_caja_v390";
let cierresCaja = [];
let cierresCajaEliminados = [];
let auditoriaCaja = [];
let personasCaja = ["Sofía", "María"];
let configuracionCaja = { pinAdmin: "2580" };
let gastosCajaEdicion = [];
let cajaAdminActivo = false;
let temporizadorCajaAdmin = null;
let ultimoMovimientoCajaAdmin = 0;
const CAJA_ADMIN_TIMEOUT_MS = 2 * 60 * 1000;

function hoyISOCaja() {
  const ahora = new Date();
  const local = new Date(ahora.getTime() - ahora.getTimezoneOffset() * 60000);
  return local.toISOString().slice(0, 10);
}

function montoCaja(valor) {
  const numero = Number(valor || 0);
  return Number.isFinite(numero) && numero >= 0 ? numero : 0;
}

function formatoDineroCaja(valor) {
  return new Intl.NumberFormat("es-AR", {
    style: "currency",
    currency: "ARS",
    maximumFractionDigits: 0
  }).format(montoCaja(valor));
}

function escaparCaja(texto) {
  return String(texto ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function cargarCajaLocal() {
  try {
    const guardado = JSON.parse(localStorage.getItem(CAJA_STORAGE_KEY) || "{}");
    cierresCaja = Array.isArray(guardado.cierresCaja) ? guardado.cierresCaja : [];
    cierresCajaEliminados = Array.isArray(guardado.cierresCajaEliminados)
      ? guardado.cierresCajaEliminados
      : [];
    auditoriaCaja = Array.isArray(guardado.auditoriaCaja)
      ? guardado.auditoriaCaja
      : [];
    personasCaja = Array.isArray(guardado.personasCaja) && guardado.personasCaja.length
      ? guardado.personasCaja
      : ["Sofía", "María"];
    configuracionCaja = guardado.configuracionCaja && typeof guardado.configuracionCaja === "object"
      ? { pinAdmin: String(guardado.configuracionCaja.pinAdmin || "2580") }
      : { pinAdmin: "2580" };
  } catch (error) {
    console.error("No se pudo leer Caja local:", error);
  }
}

function guardarCajaLocal() {
  localStorage.setItem(CAJA_STORAGE_KEY, JSON.stringify({
    cierresCaja,
    cierresCajaEliminados,
    auditoriaCaja,
    personasCaja,
    configuracionCaja
  }));
}

function idCierreCaja(fecha, turno) {
  return `${fecha}_${turno}`;
}

function obtenerCierreCaja(fecha, turno) {
  return cierresCaja.find(cierre => cierre.id === idCierreCaja(fecha, turno)) || null;
}

function turnoTextoCaja(turno) {
  return turno === "tarde" ? "Tarde" : "Mañana";
}

function renderPersonasCaja() {
  const selector = $("cajaPersona");
  if (selector) {
    const valorActual = selector.value;
    selector.innerHTML = personasCaja
      .map(nombre => `<option value="${escaparCaja(nombre)}">${escaparCaja(nombre)}</option>`)
      .join("");
    if (personasCaja.includes(valorActual)) selector.value = valorActual;
  }

  const renderLista = (contenedor) => {
    if (!contenedor) return;
    contenedor.innerHTML = personasCaja.length
      ? personasCaja.map((nombre, indice) => `
          <div class="cajaPersonRow">
            <span>${escaparCaja(nombre)}</span>
            <button type="button" onclick="eliminarPersonaCaja(${indice})">Eliminar</button>
          </div>
        `).join("")
      : '<p class="hint">No hay personas cargadas.</p>';
  };

  renderLista($("listaPersonasCaja"));
  renderLista($("listaPersonasCajaRapida"));
}

function renderGastosCaja() {
  const lista = $("listaGastosCaja");
  if (!lista) return;

  if (!gastosCajaEdicion.length) {
    lista.innerHTML = '<div class="cajaExpenseEmpty">Todavía no se cargaron gastos en este turno.</div>';
  } else {
    lista.innerHTML = gastosCajaEdicion.map((gasto, indice) => `
      <div class="cajaExpenseRow">
        <input
          type="text"
          value="${escaparCaja(gasto.motivo)}"
          placeholder="Motivo"
          aria-label="Motivo del gasto"
          onchange="actualizarGastoCaja(${indice}, 'motivo', this.value)">
        <input
          type="number"
          min="0"
          step="1"
          inputmode="numeric"
          value="${montoCaja(gasto.monto) || ""}"
          placeholder="$ 0"
          aria-label="Monto del gasto"
          onchange="actualizarGastoCaja(${indice}, 'monto', this.value)">
        <button type="button" aria-label="Eliminar gasto" onclick="eliminarGastoCaja(${indice})">🗑</button>
      </div>
    `).join("");
  }

  const total = gastosCajaEdicion.reduce((suma, gasto) => suma + montoCaja(gasto.monto), 0);
  if ($("totalGastosCaja")) $("totalGastosCaja").textContent = formatoDineroCaja(total);
}

function agregarGastoCaja() {
  gastosCajaEdicion.push({ motivo: "", monto: 0 });
  renderGastosCaja();
  setTimeout(() => {
    const inputs = document.querySelectorAll("#listaGastosCaja .cajaExpenseRow input");
    inputs[inputs.length - 2]?.focus();
  }, 30);
}

function actualizarGastoCaja(indice, campo, valor) {
  if (!gastosCajaEdicion[indice]) return;
  gastosCajaEdicion[indice][campo] = campo === "monto" ? montoCaja(valor) : String(valor || "");
  renderGastosCaja();
}

function eliminarGastoCaja(indice) {
  gastosCajaEdicion.splice(indice, 1);
  renderGastosCaja();
}

function limpiarFormularioCaja({ conservarFechaTurno = true } = {}) {
  if (!conservarFechaTurno && $("cajaFecha")) $("cajaFecha").value = hoyISOCaja();
  if ($("cajaEfectivo")) $("cajaEfectivo").value = "";
  if ($("cajaTransferencias")) $("cajaTransferencias").value = "";
  if ($("cajaObservacion")) $("cajaObservacion").value = "";
  gastosCajaEdicion = [];
  renderGastosCaja();
  $("avisoCierreExistente")?.classList.add("hidden");
}

function cargarCierreSeleccionadoCaja() {
  const fecha = $("cajaFecha")?.value || hoyISOCaja();
  const turno = $("cajaTurno")?.value || "manana";
  const cierre = obtenerCierreCaja(fecha, turno);
  const aviso = $("avisoCierreExistente");

  // La pantalla del empleado nunca muestra nuevamente los importes guardados.
  // Solo informa que ese turno ya fue cargado.
  limpiarFormularioCaja({ conservarFechaTurno: true });

  if (!cierre) {
    aviso?.classList.add("hidden");
    return;
  }

  if (aviso) {
    aviso.textContent = `✅ El cierre del turno ${turnoTextoCaja(turno).toLowerCase()} de esta fecha ya fue cargado.`;
    aviso.classList.remove("hidden");
  }
}

function validarCierreCaja() {
  const fecha = $("cajaFecha")?.value;
  const turno = $("cajaTurno")?.value;
  const persona = $("cajaPersona")?.value;
  const efectivo = montoCaja($("cajaEfectivo")?.value);
  const transferencias = montoCaja($("cajaTransferencias")?.value);

  if (!fecha) return "Seleccioná la fecha.";
  if (!turno) return "Seleccioná el turno.";
  if (!persona) return "Seleccioná quién realiza el cierre.";
  if (!efectivo && !transferencias) return "Cargá al menos un monto de venta.";

  const gastoIncompleto = gastosCajaEdicion.some(gasto =>
    !String(gasto.motivo || "").trim() || montoCaja(gasto.monto) <= 0
  );
  if (gastoIncompleto) return "Revisá los gastos: cada uno necesita motivo y monto.";

  return "";
}

function idDispositivoCaja() {
  const clave = "fratello_dispositivo_caja_id";
  let id = localStorage.getItem(clave);
  if (!id) {
    id = `DISP-${Math.random().toString(36).slice(2, 7).toUpperCase()}`;
    localStorage.setItem(clave, id);
  }
  return id;
}

function descripcionDispositivoCaja() {
  const ua = navigator.userAgent || "";
  const sistema = /Android/i.test(ua) ? "Android"
    : /iPhone|iPad|iPod/i.test(ua) ? "iPhone/iPad"
    : /Windows/i.test(ua) ? "Windows"
    : /Macintosh/i.test(ua) ? "Mac"
    : "Dispositivo";
  const navegador = /Edg/i.test(ua) ? "Edge"
    : /Chrome/i.test(ua) ? "Chrome"
    : /Safari/i.test(ua) ? "Safari"
    : /Firefox/i.test(ua) ? "Firefox"
    : "Navegador";
  return `${idDispositivoCaja()} · ${sistema} · ${navegador}`;
}

function fusionarAuditoriaCaja(remota = [], local = []) {
  const mapa = new Map();
  [...(Array.isArray(remota) ? remota : []), ...(Array.isArray(local) ? local : [])]
    .forEach(item => {
      if (!item) return;
      const id = String(item.id || `${item.fecha || ""}_${item.turno || ""}_${item.timestamp || ""}_${item.resultado || ""}`);
      if (!id) return;
      mapa.set(id, { ...item, id });
    });
  return [...mapa.values()].sort((a, b) =>
    String(a.timestamp || "").localeCompare(String(b.timestamp || ""))
  );
}

function registrarEventoAuditoriaCaja({ fecha, turno, persona = "", resultado, detalle = "", cierreId = "" }) {
  const evento = {
    id: `AUD-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    cierreId: cierreId || idCierreCaja(fecha, turno),
    fecha,
    turno,
    persona,
    resultado,
    detalle,
    timestamp: new Date().toISOString(),
    dispositivo: descripcionDispositivoCaja(),
    online: navigator.onLine
  };
  auditoriaCaja = fusionarAuditoriaCaja(auditoriaCaja, [evento]);
  guardarCajaLocal();
  return evento;
}

function eventosAuditoriaCierreCaja(fecha, turno) {
  const id = idCierreCaja(fecha, turno);
  return auditoriaCaja
    .filter(item => item.cierreId === id || (item.fecha === fecha && item.turno === turno))
    .sort((a, b) => String(a.timestamp || "").localeCompare(String(b.timestamp || "")));
}

function formatoFechaHoraAuditoriaCaja(valor) {
  if (!valor) return "Sin registro";
  const fecha = new Date(valor);
  if (Number.isNaN(fecha.getTime())) return "Sin registro";
  return fecha.toLocaleString("es-AR", {
    day: "2-digit", month: "2-digit", year: "numeric",
    hour: "2-digit", minute: "2-digit", second: "2-digit"
  });
}

function etiquetaResultadoAuditoriaCaja(resultado) {
  const mapa = {
    intento: "Intento iniciado",
    validacion_error: "No se pudo guardar",
    guardado_local: "Guardado en el dispositivo",
    sincronizado: "Sincronizado online",
    sincronizacion_error: "Error de sincronización",
    editado: "Cierre editado"
  };
  return mapa[resultado] || resultado || "Evento";
}

function htmlAuditoriaCierreCaja(fecha, turno, cierre) {
  const eventos = eventosAuditoriaCierreCaja(fecha, turno);
  const intentos = eventos.filter(item => item.resultado === "intento").length;
  const primerIntento = eventos.find(item => item.resultado === "intento");
  const primerGuardado = eventos.find(item =>
    item.resultado === "guardado_local" || item.resultado === "sincronizado"
  );
  const ultimoEvento = eventos[eventos.length - 1];

  const creado = cierre?.creado || primerGuardado?.timestamp || "";
  const actualizado = cierre?.actualizado || ultimoEvento?.timestamp || "";
  const dispositivo = primerGuardado?.dispositivo || primerIntento?.dispositivo ||
    "No registrado: cierre anterior a v5.2.6";

  return `<details class="cajaAuditoriaInfo">
    <summary title="Información y auditoría del cierre">ⓘ</summary>
    <div class="cajaAuditoriaPanel">
      <div><span>Fecha y hora de carga</span><strong>${formatoFechaHoraAuditoriaCaja(creado)}</strong></div>
      <div><span>Última modificación</span><strong>${formatoFechaHoraAuditoriaCaja(actualizado)}</strong></div>
      <div><span>Dispositivo</span><strong>${escaparCaja(dispositivo)}</strong></div>
      <div><span>Intentos registrados</span><strong>${intentos || (cierre?.creado ? "No disponibles para carga anterior" : "0")}</strong></div>
      ${eventos.length ? `<div class="cajaAuditoriaEventos">
        <span>Historial</span>
        ${eventos.map(evento => `<p>
          <b>${formatoFechaHoraAuditoriaCaja(evento.timestamp)}</b>
          · ${escaparCaja(etiquetaResultadoAuditoriaCaja(evento.resultado))}
          ${evento.detalle ? `· ${escaparCaja(evento.detalle)}` : ""}
          <small>${escaparCaja(evento.dispositivo || "")}</small>
        </p>`).join("")}
      </div>` : `<p class="cajaAuditoriaAnterior">
        Este cierre ya existía antes de incorporar la auditoría. La fecha de creación y actualización proviene del registro original, pero no hay historial de intentos ni dispositivo.
      </p>`}
    </div>
  </details>`;
}

async function guardarCierreCaja() {
  const estado = $("estadoCierreCaja");
  const fecha = $("cajaFecha")?.value || "";
  const turno = $("cajaTurno")?.value || "";
  const persona = $("cajaPersona")?.value || "";

  registrarEventoAuditoriaCaja({
    fecha,
    turno,
    persona,
    resultado: "intento",
    detalle: "Se presionó Guardar cierre"
  });

  const error = validarCierreCaja();
  if (error) {
    registrarEventoAuditoriaCaja({
      fecha,
      turno,
      persona,
      resultado: "validacion_error",
      detalle: error
    });
    if (estado) {
      estado.textContent = `⚠️ ${error}`;
      estado.className = "cajaSaveStatus error";
    }
    guardarCajaModuloEnNube().catch(() => {});
    return;
  }

  const id = idCierreCaja(fecha, turno);
  cierresCajaEliminados = cierresCajaEliminados.filter(
    item => claveCierreCajaEliminado(item) !== id
  );
  const anterior = obtenerCierreCaja(fecha, turno);
  const ahora = new Date().toISOString();

  const cierre = {
    id,
    fecha,
    turno,
    persona,
    efectivo: montoCaja($("cajaEfectivo").value),
    transferencias: montoCaja($("cajaTransferencias").value),
    gastos: gastosCajaEdicion.map(gasto => ({
      motivo: String(gasto.motivo || "").trim(),
      monto: montoCaja(gasto.monto)
    })),
    observacion: String($("cajaObservacion")?.value || "").trim(),
    creado: anterior?.creado || ahora,
    actualizado: ahora,
    dispositivoCarga: anterior?.dispositivoCarga || descripcionDispositivoCaja(),
    dispositivoUltimaEdicion: descripcionDispositivoCaja()
  };

  const indice = cierresCaja.findIndex(item => item.id === id);
  if (indice >= 0) cierresCaja[indice] = cierre;
  else cierresCaja.push(cierre);

  registrarEventoAuditoriaCaja({
    fecha,
    turno,
    persona,
    resultado: anterior ? "editado" : "guardado_local",
    detalle: anterior ? "Se modificó un cierre existente" : "Cierre guardado localmente",
    cierreId: id
  });

  guardarCajaLocal();
  renderCajaAdmin();
  renderDashboardCaja();

  try {
    await Promise.resolve(guardarCajaModuloEnNube());
    registrarEventoAuditoriaCaja({
      fecha,
      turno,
      persona,
      resultado: "sincronizado",
      detalle: "Cierre confirmado en Firebase",
      cierreId: id
    });
    guardarCajaLocal();
    renderCajaAdmin();
    renderDashboardCaja();
  } catch (errorSync) {
    registrarEventoAuditoriaCaja({
      fecha,
      turno,
      persona,
      resultado: "sincronizacion_error",
      detalle: String(errorSync?.message || "No se pudo sincronizar"),
      cierreId: id
    });
    guardarCajaLocal();
    console.error("Error sincronizando cierre de Caja:", errorSync);
  }

  if (estado) {
    estado.textContent = anterior
      ? `✅ Cierre del turno ${turnoTextoCaja(turno).toLowerCase()} actualizado correctamente.`
      : `✅ Cierre del turno ${turnoTextoCaja(turno).toLowerCase()} guardado correctamente.`;
    estado.className = "cajaSaveStatus success";
  }

  limpiarFormularioCaja({ conservarFechaTurno: true });
  const avisoGuardado = $("avisoCierreExistente");
  if (avisoGuardado) {
    avisoGuardado.textContent = `✅ El cierre del turno ${turnoTextoCaja(turno).toLowerCase()} de esta fecha ya fue cargado.`;
    avisoGuardado.classList.remove("hidden");
  }
}

function iniciarTemporizadorCajaAdmin() {
  detenerTemporizadorCajaAdmin();
  ultimoMovimientoCajaAdmin = Date.now();

  temporizadorCajaAdmin = setInterval(() => {
    if (!cajaAdminActivo) return;
    if (Date.now() - ultimoMovimientoCajaAdmin >= CAJA_ADMIN_TIMEOUT_MS) {
      bloquearCajaAdmin("La sesión se cerró por inactividad.");
    }
  }, 5000);
}

function registrarActividadCajaAdmin() {
  if (!cajaAdminActivo) return;
  ultimoMovimientoCajaAdmin = Date.now();
}

function detenerTemporizadorCajaAdmin() {
  if (temporizadorCajaAdmin) {
    clearInterval(temporizadorCajaAdmin);
    temporizadorCajaAdmin = null;
  }
}

function bloquearCajaAdmin(mensaje = "") {
  cajaAdminActivo = false;
  detenerTemporizadorCajaAdmin();
  cerrarDetalleDiaCaja();
  cerrarModalPersonasCaja();

  const panel = $("panelCajaAdmin");
  panel?.classList.add("hidden");
  if (panel) {
    panel.style.display = "none";
    panel.setAttribute("aria-hidden", "true");
  }

  if ($("resumenCajaAdmin")) $("resumenCajaAdmin").innerHTML = "";
  if ($("cierresCajaAdmin")) $("cierresCajaAdmin").innerHTML = "";
  if ($("indicadoresCajaDashboard")) $("indicadoresCajaDashboard").innerHTML = "";
  if ($("libroDiarioCaja")) $("libroDiarioCaja").innerHTML = "";

  if ($("cajaAdminPin")) $("cajaAdminPin").value = "";
  if ($("estadoLoginCaja")) $("estadoLoginCaja").textContent = mensaje;
}

function alternarVisibilidadPinCaja(inputId, botonId) {
  const input = $(inputId);
  const boton = $(botonId);
  if (!input || !boton) return;

  const mostrar = input.type === "password";
  input.type = mostrar ? "text" : "password";
  boton.textContent = mostrar ? "🙈 Ocultar" : "👁 Mostrar";
}

function abrirModalPersonasCaja() {
  if (!tieneRolAdministrador()) {
    mostrarModalAdministrador();
    return;
  }

  cajaAdminActivo = true;
  renderPersonasCaja();
  $("modalPersonasCaja")?.classList.remove("hidden");
  document.body.classList.add("modal-open");
  registrarActividadCajaAdmin();
}

function cerrarModalPersonasCaja() {
  $("modalPersonasCaja")?.classList.add("hidden");
  document.body.classList.remove("modal-open");
}

function mostrarModoCaja(modo = "empleado") {
  $("panelCajaEmpleado")?.classList.remove("hidden");

  if (modo === "admin") {
    if (!tieneRolAdministrador()) {
      mostrarModalAdministrador();
      return;
    }
    cajaAdminActivo = true;
    renderCajaAdmin();
    renderDashboardCaja();
    activarTabAdministracion("caja");
    mostrarSeccion("seccionAdministracion");
  }
}

function ingresarCajaAdmin() {
  mostrarModoCaja("admin");
}

function salirCajaAdmin() {
  cajaAdminActivo = false;
  mostrarMenuAdministracion();
}

function totalesCierreCaja(cierre) {
  const efectivo = montoCaja(cierre?.efectivo);
  const transferencias = montoCaja(cierre?.transferencias);
  const gastos = (cierre?.gastos || []).reduce((suma, gasto) => suma + montoCaja(gasto.monto), 0);
  return {
    efectivo,
    transferencias,
    gastos,
    venta: efectivo + transferencias,
    efectivoRendir: efectivo - gastos
  };
}

function tarjetaResumenCaja(titulo, valor, clase = "") {
  return `<div class="cajaSummaryCard ${clase}">
    <span>${titulo}</span>
    <strong>${formatoDineroCaja(valor)}</strong>
  </div>`;
}

function renderCajaAdmin() {
  if (!cajaAdminActivo) return;
  renderLibroDiarioCaja();
  renderPersonasCaja();
}

function renderCajaAdminSeguro() {
  const panel = $("panelCajaAdmin");
  if (!panel) {
    console.error("Caja privada: panelCajaAdmin no existe.");
    return false;
  }
  try {
    panel.classList.remove("hidden");
    panel.style.display = "block";
    renderCajaAdmin();
    return true;
  } catch (error) {
    console.error("Caja privada: error al renderizar", error);
    panel.innerHTML = `<article class="adminRenderError"><h3>⚠️ No se pudo cargar Control de Caja</h3><p>La pantalla se recuperó sin quedar en blanco. Actualizá los datos o volvé a intentar.</p><button type="button" onclick="renderCajaAdminSeguro()">Reintentar</button></article>`;
    return false;
  }
}


function editarCierreDesdeAdminCaja(fecha, turno) {
  // Compatibilidad con botones de versiones anteriores.
  abrirEditorTurnoCaja(fecha, turno);
}

function agregarPersonaCaja(inputId = "nuevaPersonaCaja") {
  const input = $(inputId);
  const nombre = String(input?.value || "").trim();
  if (!nombre) return;

  if (personasCaja.some(item => item.toLowerCase() === nombre.toLowerCase())) {
    alert("Esa persona ya está cargada.");
    return;
  }

  personasCaja.push(nombre);
  personasCaja.sort((a, b) => a.localeCompare(b, "es"));
  guardarCajaLocal();
  guardarCajaModuloEnNube();
  if (input) input.value = "";
  renderPersonasCaja();
}

function eliminarPersonaCaja(indice) {
  const nombre = personasCaja[indice];
  if (!nombre) return;
  if (!confirm(`¿Eliminar a ${nombre} de la lista?`)) return;
  personasCaja.splice(indice, 1);
  guardarCajaLocal();
  guardarCajaModuloEnNube();
  renderPersonasCaja();
}

function cambiarPinCaja() {
  const input = $("nuevoPinCaja");
  const confirmar = $("confirmarPinCaja");
  const estado = $("estadoCambioPinCaja");
  const nuevoPin = String(input?.value || "").trim();
  const confirmacion = String(confirmar?.value || "").trim();

  if (estado) {
    estado.textContent = "";
    estado.className = "";
  }

  if (!/^\d{4,8}$/.test(nuevoPin)) {
    if (estado) {
      estado.textContent = "El PIN debe tener entre 4 y 8 números.";
      estado.className = "error";
    }
    return;
  }

  if (nuevoPin !== confirmacion) {
    if (estado) {
      estado.textContent = "Los dos PIN no coinciden.";
      estado.className = "error";
    }
    return;
  }

  configuracionCaja.pinAdmin = nuevoPin;
  guardarCajaLocal();
  guardarCajaModuloEnNube();

  if (input) {
    input.value = "";
    input.type = "password";
  }
  if (confirmar) {
    confirmar.value = "";
    confirmar.type = "password";
  }

  if ($("btnMostrarNuevoPinCaja")) $("btnMostrarNuevoPinCaja").textContent = "👁 Mostrar";
  if ($("btnMostrarConfirmarPinCaja")) $("btnMostrarConfirmarPinCaja").textContent = "👁 Mostrar";

  if (estado) {
    estado.textContent = "✅ PIN actualizado correctamente.";
    estado.className = "success";
  }

  registrarActividadCajaAdmin();
}


function inicioSemanaCaja(fecha = new Date()) {
  const d = new Date(fecha);
  const dia = d.getDay();
  const diferencia = dia === 0 ? -6 : 1 - dia;
  d.setDate(d.getDate() + diferencia);
  d.setHours(0, 0, 0, 0);
  return d;
}

function fechaDesdeISOCaja(iso) {
  const [y, m, d] = String(iso).split("-").map(Number);
  return new Date(y, (m || 1) - 1, d || 1);
}

function formatoFechaCaja(iso, incluirDia = true) {
  const fecha = fechaDesdeISOCaja(iso);
  return new Intl.DateTimeFormat("es-AR", {
    weekday: incluirDia ? "long" : undefined,
    day: "2-digit",
    month: "2-digit",
    year: "numeric"
  }).format(fecha);
}

function agruparCierresPorDiaCaja() {
  const mapa = new Map();

  cierresCaja.forEach(cierre => {
    if (!cierre?.fecha) return;
    if (!mapa.has(cierre.fecha)) {
      mapa.set(cierre.fecha, {
        fecha: cierre.fecha,
        cierres: [],
        efectivo: 0,
        transferencias: 0,
        gastos: 0,
        venta: 0,
        efectivoRendir: 0
      });
    }

    const dia = mapa.get(cierre.fecha);
    const totales = totalesCierreCaja(cierre);
    dia.cierres.push(cierre);
    dia.efectivo += totales.efectivo;
    dia.transferencias += totales.transferencias;
    dia.gastos += totales.gastos;
    dia.venta += totales.venta;
    dia.efectivoRendir += totales.efectivoRendir;
  });

  return [...mapa.values()].sort((a, b) => b.fecha.localeCompare(a.fecha));
}

function filtrarDiasCaja(periodo) {
  const dias = agruparCierresPorDiaCaja();
  const hoy = fechaDesdeISOCaja(hoyISOCaja());
  hoy.setHours(0, 0, 0, 0);

  if (periodo === "todo") return dias;
  if (periodo === "hoy") return dias.filter(d => d.fecha === hoyISOCaja());

  if (periodo === "semana") {
    const inicio = inicioSemanaCaja(hoy);
    const fin = new Date(inicio);
    fin.setDate(fin.getDate() + 6);
    return dias.filter(d => {
      const fecha = fechaDesdeISOCaja(d.fecha);
      return fecha >= inicio && fecha <= fin;
    });
  }

  return dias.filter(d => {
    const fecha = fechaDesdeISOCaja(d.fecha);
    return fecha.getFullYear() === hoy.getFullYear() && fecha.getMonth() === hoy.getMonth();
  });
}

function renderIndicadoresCaja() {
  const contenedor = $("indicadoresCajaDashboard");
  if (!contenedor) return;

  const periodo = $("filtroPeriodoCaja")?.value || "mes";
  const dias = filtrarDiasCaja(periodo);
  const totalVentas = dias.reduce((s, d) => s + d.venta, 0);
  const totalGastos = dias.reduce((s, d) => s + d.gastos, 0);
  const promedio = dias.length ? totalVentas / dias.length : 0;
  const mejor = dias.length ? [...dias].sort((a, b) => b.venta - a.venta)[0] : null;
  const peor = dias.length ? [...dias].sort((a, b) => a.venta - b.venta)[0] : null;

  contenedor.innerHTML = [
    `<div class="cajaIndicatorCard main"><span>Ventas del período</span><strong>${formatoDineroCaja(totalVentas)}</strong><small>${dias.length} día${dias.length === 1 ? "" : "s"} con movimientos</small></div>`,
    `<div class="cajaIndicatorCard"><span>Promedio diario</span><strong>${formatoDineroCaja(promedio)}</strong></div>`,
    `<div class="cajaIndicatorCard"><span>Total de gastos</span><strong>${formatoDineroCaja(totalGastos)}</strong></div>`,
    `<div class="cajaIndicatorCard best"><span>Mayor venta</span><strong>${mejor ? formatoDineroCaja(mejor.venta) : formatoDineroCaja(0)}</strong><small>${mejor ? formatoFechaCaja(mejor.fecha) : "Sin datos"}</small></div>`,
    `<div class="cajaIndicatorCard worst"><span>Menor venta</span><strong>${peor ? formatoDineroCaja(peor.venta) : formatoDineroCaja(0)}</strong><small>${peor ? formatoFechaCaja(peor.fecha) : "Sin datos"}</small></div>`
  ].join("");
}

function claseVentaDiaCaja(total) {
  const monto = montoCaja(total);
  if (monto >= 300000) return "high";
  if (monto <= 200000) return "low";
  return "medium";
}

function htmlGastosTurnoCaja(cierre) {
  const gastos = Array.isArray(cierre?.gastos) ? cierre.gastos : [];
  if (!gastos.length) return '<p class="cajaSinGastos">Sin gastos.</p>';
  return `<ul class="cajaListaGastos">${gastos.map(gasto => `
    <li><span>${escaparCaja(gasto.motivo || "Gasto")}</span><b>${formatoDineroCaja(gasto.monto)}</b></li>
  `).join("")}</ul>`;
}

function htmlDetalleTurnoCaja(fecha, turno, cierre) {
  if (!cierre) {
    return `<article class="cajaTurnoDetalle missing">
      <div class="cajaTurnoCabecera"><strong>${turnoTextoCaja(turno)}</strong><span>Sin cierre cargado</span></div>
      <button type="button" onclick="editarCierreDesdeAdminCaja('${fecha}','${turno}')">Cargar turno</button>
    </article>`;
  }

  const t = totalesCierreCaja(cierre);
  return `<article class="cajaTurnoDetalle">
    <div class="cajaTurnoCabecera">
      <div><strong>${turnoTextoCaja(turno)}</strong><span>${escaparCaja(cierre.persona || "")}</span></div>
      <div class="cajaTurnoAcciones">
        ${htmlAuditoriaCierreCaja(fecha, turno, cierre)}
        <button type="button" onclick="event.preventDefault();event.stopPropagation();window.abrirEditorTurnoCaja('${fecha}','${turno}')">✏️ Editar</button>
        <button type="button" class="danger" onclick="event.preventDefault();event.stopPropagation();window.eliminarCierreCajaAdmin('${fecha}','${turno}')">🗑 Eliminar</button>
      </div>
    </div>
    <div class="cajaTurnoNumeros">
      <span>Efectivo <b>${formatoDineroCaja(t.efectivo)}</b></span>
      <span>Transferencias <b>${formatoDineroCaja(t.transferencias)}</b></span>
      <span>Gastos <b>${formatoDineroCaja(t.gastos)}</b></span>
    </div>
    <div class="cajaTurnoGastos">
      <strong>Gastos del turno</strong>
      ${htmlGastosTurnoCaja(cierre)}
    </div>
    <div class="cajaInlineEditHost" id="editorCaja-${fecha}-${turno}"></div>
  </article>`;
}

function renderLibroDiarioCaja() {
  const contenedor = $("libroDiarioCaja");
  if (!contenedor) return;

  const mesSeleccionado = $("mesLibroCaja")?.value || hoyISOCaja().slice(0, 7);
  const dias = agruparCierresPorDiaCaja()
    .filter(dia => dia.fecha.startsWith(mesSeleccionado))
    .sort((a, b) => b.fecha.localeCompare(a.fecha));

  const totalMes = dias.reduce((suma, dia) => suma + montoCaja(dia.venta), 0);
  if ($("totalVentasMesCaja")) $("totalVentasMesCaja").textContent = formatoDineroCaja(totalMes);

  if (!dias.length) {
    contenedor.innerHTML = '<div class="cajaIngresosVacio">No hay cierres cargados para este mes.</div>';
    return;
  }

  contenedor.innerHTML = dias.map(dia => {
    const manana = dia.cierres.find(cierre => cierre.turno === "manana");
    const tarde = dia.cierres.find(cierre => cierre.turno === "tarde");
    return `<details class="cajaIngresoDia ${claseVentaDiaCaja(dia.venta)}">
      <summary>
        <span class="cajaIngresoFecha">${formatoFechaCaja(dia.fecha)}</span>
        <strong>${formatoDineroCaja(dia.venta)}</strong>
      </summary>

      <div class="cajaIngresoDetalle">
        <article class="cajaEfectivoPrincipal">
          <span>💵 Efectivo total</span>
          <strong>${formatoDineroCaja(dia.efectivo)}</strong>
          <small>Efectivo a rendir: <b>${formatoDineroCaja(dia.efectivoRendir)}</b></small>
        </article>
        <article>
          <span>🏦 Transferencias</span>
          <strong>${formatoDineroCaja(dia.transferencias)}</strong>
        </article>
      </div>

      <details class="cajaDetalleInterno">
        <summary>Ver detalle por turno y gastos</summary>
        <div class="cajaTurnosDetalle">
          ${htmlDetalleTurnoCaja(dia.fecha, "manana", manana)}
          ${htmlDetalleTurnoCaja(dia.fecha, "tarde", tarde)}
        </div>
      </details>
    </details>`;
  }).join("");
}

function renderDashboardCaja() {
  renderLibroDiarioCaja();
}

function abrirDetalleDiaCaja(fecha) {
  const cierres = cierresCaja
    .filter(c => c.fecha === fecha)
    .sort((a, b) => a.turno.localeCompare(b.turno));

  const dia = agruparCierresPorDiaCaja().find(d => d.fecha === fecha);
  if (!dia) return;

  if ($("tituloDetalleDiaCaja")) {
    $("tituloDetalleDiaCaja").textContent = formatoFechaCaja(fecha);
  }

  const detalleTurnos = ["manana", "tarde"].map(turno => {
    const cierre = cierres.find(c => c.turno === turno);
    if (!cierre) {
      return `<section class="cajaDayShift missing">
        <h4>${turnoTextoCaja(turno)}</h4>
        <p>Sin cierre cargado.</p>
      </section>`;
    }

    const t = totalesCierreCaja(cierre);
    const gastos = cierre.gastos?.length
      ? `<ul>${cierre.gastos.map(g => `<li><span>${escaparCaja(g.motivo)}</span><b>${formatoDineroCaja(g.monto)}</b></li>`).join("")}</ul>`
      : '<p class="hint">Sin gastos.</p>';

    return `<section class="cajaDayShift" data-turno="${turno}">
      <div class="cajaDayShiftHead">
        <div>
          <h4>${turnoTextoCaja(turno)}</h4>
          <span>${escaparCaja(cierre.persona || "")}</span>
        </div>
        <button type="button" class="btnEditarTurnoCaja" data-fecha="${fecha}" data-turno="${turno}" onclick="event.preventDefault();event.stopPropagation();window.abrirEditorTurnoCaja(\'${fecha}\', \'${turno}\')">✏️ Editar</button>
      </div>
      <div class="cajaDayShiftGrid">
        <span>Efectivo <b>${formatoDineroCaja(t.efectivo)}</b></span>
        <span>Transferencias <b>${formatoDineroCaja(t.transferencias)}</b></span>
        <span>Venta del turno <b>${formatoDineroCaja(t.venta)}</b></span>
        <span>Gastos <b>${formatoDineroCaja(t.gastos)}</b></span>
        <span>Efectivo a rendir <b>${formatoDineroCaja(t.efectivoRendir)}</b></span>
      </div>
      <details>
        <summary>Ver gastos</summary>
        ${gastos}
      </details>
      <div class="cajaInlineEditHost" id="editorCaja-${fecha}-${turno}"></div>
    </section>`;
  }).join("");

  if ($("contenidoDetalleDiaCaja")) {
    $("contenidoDetalleDiaCaja").innerHTML = `
      ${detalleTurnos}
      <section class="cajaDayTotal">
        <h4>Total del día</h4>
        <span>Venta total <b>${formatoDineroCaja(dia.venta)}</b></span>
        <span>Gastos <b>${formatoDineroCaja(dia.gastos)}</b></span>
        <span>Efectivo a rendir <b>${formatoDineroCaja(dia.efectivoRendir)}</b></span>
      </section>
    `;
  }

  const modalDetalle = $("modalDetalleDiaCaja");
  modalDetalle?.classList.remove("hidden");
  modalDetalle?.removeAttribute("aria-hidden");
  document.body.classList.add("modal-open");
  registrarActividadCajaAdmin();
}

function htmlGastoEditorCaja(gasto = {}, indice = 0) {
  return `<div class="cajaInlineExpenseRow" data-indice="${indice}">
    <input type="text" class="cajaInlineGastoMotivo" value="${escaparCaja(gasto.motivo || "")}" placeholder="Motivo">
    <input type="number" class="cajaInlineGastoMonto" value="${montoCaja(gasto.monto) || ""}" min="0" step="0.01" placeholder="Monto">
    <button type="button" class="btnQuitarGastoCajaInline" aria-label="Eliminar gasto" onclick="event.preventDefault();event.stopPropagation();window.quitarGastoCajaInline(this)">×</button>
  </div>`;
}

function abrirEditorTurnoCaja(fecha, turno) {
  const cierre = obtenerCierreCaja(fecha, turno);
  if (!cierre) return;

  document.querySelectorAll(".cajaInlineEditHost").forEach(host => {
    host.innerHTML = "";
  });

  const host = $(`editorCaja-${fecha}-${turno}`);
  if (!host) return;

  const gastos = Array.isArray(cierre.gastos) ? cierre.gastos : [];
  host.innerHTML = `
    <div class="cajaInlineEditor">
      <h5>Editar ${turnoTextoCaja(turno).toLowerCase()}</h5>

      <label>Persona
        <select class="cajaInlinePersona">
          ${personasCaja.map(nombre => `<option value="${escaparCaja(nombre)}" ${nombre === cierre.persona ? "selected" : ""}>${escaparCaja(nombre)}</option>`).join("")}
        </select>
      </label>

      <div class="cajaInlineMoneyGrid">
        <label>Efectivo
          <input type="number" class="cajaInlineEfectivo" min="0" step="0.01" value="${montoCaja(cierre.efectivo) || ""}">
        </label>
        <label>Transferencias
          <input type="number" class="cajaInlineTransferencias" min="0" step="0.01" value="${montoCaja(cierre.transferencias) || ""}">
        </label>
      </div>

      <label>Observación
        <textarea class="cajaInlineObservacion" rows="2">${escaparCaja(cierre.observacion || "")}</textarea>
      </label>

      <div class="cajaInlineExpensesHeader">
        <strong>Gastos</strong>
        <button type="button" class="btnAgregarGastoCajaInline" onclick="event.preventDefault();event.stopPropagation();window.agregarGastoCajaInline(this)">+ Agregar gasto</button>
      </div>

      <div class="cajaInlineExpenses">
        ${gastos.length ? gastos.map(htmlGastoEditorCaja).join("") : htmlGastoEditorCaja({}, 0)}
      </div>

      <div class="cajaInlineActions">
        <button type="button" class="btnCancelarCajaInline" onclick="event.preventDefault();event.stopPropagation();window.cancelarEdicionCajaInline(this)">Cancelar</button>
        <button type="button" class="primary btnGuardarCajaInline" data-fecha="${fecha}" data-turno="${turno}" onclick="event.preventDefault();event.stopPropagation();window.guardarEdicionTurnoCaja(\'${fecha}\', \'${turno}\', this)">Guardar cambios</button>
      </div>

      <div class="cajaInlineStatus"></div>
    </div>
  `;

  host.scrollIntoView({ behavior: "smooth", block: "nearest" });
}


function agregarGastoCajaInline(boton) {
  const editor = boton?.closest(".cajaInlineEditor");
  const lista = editor?.querySelector(".cajaInlineExpenses");
  if (lista) {
    lista.insertAdjacentHTML("beforeend", htmlGastoEditorCaja({}, lista.children.length));
  }
}

function quitarGastoCajaInline(boton) {
  const fila = boton?.closest(".cajaInlineExpenseRow");
  const lista = boton?.closest(".cajaInlineExpenses");
  if (!fila || !lista) return;

  if (lista.children.length > 1) {
    fila.remove();
  } else {
    fila.querySelectorAll("input").forEach(input => input.value = "");
  }
}

function cancelarEdicionCajaInline(boton) {
  const host = boton?.closest(".cajaInlineEditHost");
  if (host) host.innerHTML = "";
}

function recolectarGastosEditorCaja(host) {
  return [...host.querySelectorAll(".cajaInlineExpenseRow")]
    .map(fila => ({
      motivo: String(fila.querySelector(".cajaInlineGastoMotivo")?.value || "").trim(),
      monto: montoCaja(fila.querySelector(".cajaInlineGastoMonto")?.value)
    }))
    .filter(gasto => gasto.motivo || gasto.monto > 0);
}

async function guardarEdicionTurnoCaja(fecha, turno, boton) {
  const host = $(`editorCaja-${fecha}-${turno}`);
  if (!host) return;

  const cierre = obtenerCierreCaja(fecha, turno);
  if (!cierre) return;

  const persona = String(host.querySelector(".cajaInlinePersona")?.value || "").trim();
  const efectivo = montoCaja(host.querySelector(".cajaInlineEfectivo")?.value);
  const transferencias = montoCaja(host.querySelector(".cajaInlineTransferencias")?.value);
  const observacion = String(host.querySelector(".cajaInlineObservacion")?.value || "").trim();
  const gastos = recolectarGastosEditorCaja(host);
  const estado = host.querySelector(".cajaInlineStatus");

  if (!persona) {
    if (estado) estado.textContent = "Seleccioná una persona.";
    return;
  }

  boton.disabled = true;
  if (estado) estado.textContent = "Guardando...";

  const actualizado = {
    ...cierre,
    persona,
    efectivo,
    transferencias,
    observacion,
    gastos,
    actualizado: new Date().toISOString(),
    actualizadoEn: new Date().toISOString()
  };

  const indice = cierresCaja.findIndex(c => c.fecha === fecha && c.turno === turno);
  if (indice >= 0) cierresCaja[indice] = actualizado;

  guardarCajaLocal();
  renderCajaAdmin();
  renderDashboardCaja();

  try {
    await Promise.resolve(guardarCajaModuloEnNube());
    if (estado) estado.textContent = "✅ Cambios guardados.";
    abrirDetalleDiaCaja(fecha);
  } catch (error) {
    console.error("Error guardando edición de Caja:", error);
    if (estado) estado.textContent = "No se pudo sincronizar. Probá nuevamente.";
    boton.disabled = false;
  }
}

async function eliminarCierreCajaAdmin(fecha, turno) {
  const cierre = obtenerCierreCaja(fecha, turno);
  if (!cierre) {
    alert("Ese cierre ya no existe.");
    return;
  }

  const etiqueta = `${turnoTextoCaja(turno).toLowerCase()} del ${formatoFechaCaja(fecha)}`;
  if (!confirm(
    `¿Eliminar el cierre del turno ${etiqueta}?\n\n` +
    "Se eliminarán los importes y gastos de ese turno. Esta acción no se puede deshacer."
  )) return;

  const cierreId = idCierreCaja(fecha, turno);
  registrarEventoAuditoriaCaja({
    fecha,
    turno,
    persona: cierre.persona || "",
    resultado: "eliminado",
    detalle: "Cierre eliminado desde Administración",
    cierreId
  });
  cierresCajaEliminados = fusionarCierresCajaEliminados(
    cierresCajaEliminados,
    [{ id: cierreId, eliminadoEn: new Date().toISOString() }]
  );

  cierresCaja = cierresCaja.filter(item =>
    !(item.fecha === fecha && item.turno === turno)
  );

  ultimaFirmaCajaRenderizada = firmaCierresCaja(cierresCaja);
  guardarCajaLocal();
  renderCajaAdmin();
  renderDashboardCaja();

  try {
    await Promise.resolve(guardarCajaModuloEnNube());
    renderCajaAdmin();
    renderDashboardCaja();
    alert("Cierre eliminado correctamente.");
  } catch (error) {
    console.error("Error eliminando cierre de Caja:", error);
    alert("El cierre se eliminó en este dispositivo, pero no se pudo sincronizar todavía.");
  }
}

function cerrarDetalleDiaCaja() {
  const modal = $("modalDetalleDiaCaja");
  if (modal) {
    modal.classList.add("hidden");
    modal.setAttribute("aria-hidden", "true");
  }
  document.body.classList.remove("modal-open");
}


let unsubscribeCajaModulo = null;
let unsubscribeAdminModulo = null;
let guardandoCajaModulo = false;
let guardandoAdminModulo = false;

async function guardarCajaModuloEnNube() {
  guardarCajaLocal();
  if (!db) {
    setEstadoSync("Modo local — Firebase no inició");
    return false;
  }
  if (guardandoCajaModulo) return false;

  guardandoCajaModulo = true;
  setEstadoSync("Sincronizando Caja...");

  try {
    const ref = db.collection("fratello").doc("caja_estado");
    await db.runTransaction(async tx => {
      const snap = await tx.get(ref);
      const remoto = snap.exists ? snap.data() : {};

      cierresCajaEliminados = fusionarCierresCajaEliminados(
        remoto.cierresCajaEliminados,
        cierresCajaEliminados
      );
      auditoriaCaja = fusionarAuditoriaCaja(remoto.auditoriaCaja, auditoriaCaja);
      cierresCaja = fusionarCierresCaja(
        remoto.cierresCaja,
        cierresCaja,
        cierresCajaEliminados
      );

      tx.set(ref, {
        cierresCaja,
        cierresCajaEliminados,
        auditoriaCaja,
        personasCaja,
        configuracionCaja,
        actualizado: new Date().toISOString()
      }, { merge: true });
    });

    guardarCajaLocal();
    renderCajaAdmin();
    renderDashboardCaja();
    renderAdministracionFinanciera();
    setEstadoSync("Guardado online");
    setTimeout(() => setEstadoSync("Online actualizado"), 900);
    return true;
  } catch (error) {
    console.error("Error sincronizando módulo Caja:", error);
    setEstadoSync(navigator.onLine ? "Error de sincronización de Caja" : "Sin conexión — modo local");
    return false;
  } finally {
    guardandoCajaModulo = false;
  }
}

async function guardarAdminModuloEnNube() {
  guardarAdministracionLocal();
  if (!db) {
    setEstadoSync("Modo local — Firebase no inició");
    return false;
  }
  if (guardandoAdminModulo) return false;

  guardandoAdminModulo = true;
  setEstadoSync("Sincronizando Administración...");

  try {
    const ref = db.collection("fratello").doc("administracion_estado");
    await db.runTransaction(async tx => {
      const snap = await tx.get(ref);
      const remoto = snap.exists ? snap.data() : {};

      administracionFinanciera = fusionarAdministracionFinancieraSync(
        remoto.administracionFinanciera,
        administracionFinanciera
      );

      tx.set(ref, {
        administracionFinanciera,
        actualizado: new Date().toISOString()
      }, { merge: true });
    });

    guardarAdministracionLocal();
    renderAdministracionFinanciera();
    setEstadoSync("Guardado online");
    setTimeout(() => setEstadoSync("Online actualizado"), 900);
    return true;
  } catch (error) {
    console.error("Error sincronizando módulo Administración:", error);
    setEstadoSync(navigator.onLine ? "Error de sincronización de Administración" : "Sin conexión — modo local");
    return false;
  } finally {
    guardandoAdminModulo = false;
  }
}

function escucharModuloCajaNube() {
  if (!db || unsubscribeCajaModulo) return;

  unsubscribeCajaModulo = db.collection("fratello").doc("caja_estado")
    .onSnapshot(doc => {
      if (!doc.exists) return;
      const data = doc.data() || {};

      cierresCajaEliminados = fusionarCierresCajaEliminados(
        data.cierresCajaEliminados,
        cierresCajaEliminados
      );
      auditoriaCaja = fusionarAuditoriaCaja(data.auditoriaCaja, auditoriaCaja);
      cierresCaja = fusionarCierresCaja(
        data.cierresCaja,
        cierresCaja,
        cierresCajaEliminados
      );

      if (Array.isArray(data.personasCaja) && data.personasCaja.length) {
        personasCaja = data.personasCaja;
      }
      if (data.configuracionCaja && typeof data.configuracionCaja === "object") {
        configuracionCaja = { ...configuracionCaja, ...data.configuracionCaja };
      }

      ultimaFirmaCajaRenderizada = firmaCierresCaja(cierresCaja);
      guardarCajaLocal();
      renderPersonasCaja();
      renderCajaAdmin();
      renderDashboardCaja();
      renderAdministracionFinanciera();
      setEstadoSync("Online actualizado");
    }, error => {
      console.error("Listener módulo Caja:", error);
      setEstadoSync("Error recibiendo Caja");
    });
}

function escucharModuloAdminNube() {
  if (!db || unsubscribeAdminModulo) return;

  unsubscribeAdminModulo = db.collection("fratello").doc("administracion_estado")
    .onSnapshot(doc => {
      if (!doc.exists) return;
      const data = doc.data() || {};
      if (!data.administracionFinanciera) return;

      administracionFinanciera = fusionarAdministracionFinancieraSync(
        data.administracionFinanciera,
        administracionFinanciera
      );
      guardarAdministracionLocal();
      renderAdministracionFinanciera();
      setEstadoSync("Online actualizado");
    }, error => {
      console.error("Listener módulo Administración:", error);
      setEstadoSync("Error recibiendo Administración");
    });
}

function firmaModuloSync(valor) {
  try {
    return JSON.stringify(valor ?? null);
  } catch {
    return "";
  }
}

async function cargarYFusionarCajaModulo() {
  const ref = db.collection("fratello").doc("caja_estado");
  const snap = await ref.get();
  const remoto = snap.exists ? snap.data() : {};

  cierresCajaEliminados = fusionarCierresCajaEliminados(
    remoto.cierresCajaEliminados,
    cierresCajaEliminados
  );
  auditoriaCaja = fusionarAuditoriaCaja(remoto.auditoriaCaja, auditoriaCaja);
  cierresCaja = fusionarCierresCaja(
    remoto.cierresCaja,
    cierresCaja,
    cierresCajaEliminados
  );

  if (Array.isArray(remoto.personasCaja) && remoto.personasCaja.length) {
    personasCaja = [...new Set([...remoto.personasCaja, ...personasCaja])].sort((a,b) => a.localeCompare(b, "es"));
  }
  if (remoto.configuracionCaja && typeof remoto.configuracionCaja === "object") {
    configuracionCaja = { ...remoto.configuracionCaja, ...configuracionCaja };
  }

  const fusionado = {
    cierresCaja,
    cierresCajaEliminados,
    auditoriaCaja,
    personasCaja,
    configuracionCaja
  };
  const remotoComparable = {
    cierresCaja: remoto.cierresCaja || [],
    cierresCajaEliminados: remoto.cierresCajaEliminados || [],
    auditoriaCaja: remoto.auditoriaCaja || [],
    personasCaja: remoto.personasCaja || [],
    configuracionCaja: remoto.configuracionCaja || {}
  };

  guardarCajaLocal();

  if (!snap.exists || firmaModuloSync(fusionado) !== firmaModuloSync(remotoComparable)) {
    await ref.set({ ...fusionado, actualizado: new Date().toISOString() }, { merge: true });
  }
}

async function cargarYFusionarAdminModulo() {
  const ref = db.collection("fratello").doc("administracion_estado");
  const snap = await ref.get();
  const remoto = snap.exists ? snap.data() : {};

  administracionFinanciera = fusionarAdministracionFinancieraSync(
    remoto.administracionFinanciera,
    administracionFinanciera
  );
  guardarAdministracionLocal();

  const fusionado = { administracionFinanciera };
  const remotoComparable = {
    administracionFinanciera: remoto.administracionFinanciera || {}
  };

  if (!snap.exists || firmaModuloSync(fusionado) !== firmaModuloSync(remotoComparable)) {
    await ref.set(
      { administracionFinanciera, actualizado: new Date().toISOString() },
      { merge: true }
    );
  }
}

async function iniciarSincronizacionModulosFinancieros() {
  if (!db) return;

  try {
    setEstadoSync("Cargando online...");
    await Promise.all([
      cargarYFusionarCajaModulo(),
      cargarYFusionarAdminModulo()
    ]);

    renderPersonasCaja();
    renderCajaAdmin();
    renderDashboardCaja();
    renderAdministracionFinanciera();

    escucharModuloCajaNube();
    escucharModuloAdminNube();
    setEstadoSync("Online actualizado");
  } catch (error) {
    console.error("Error iniciando sincronización financiera:", error);
    setEstadoSync(navigator.onLine ? "Error online — requiere revisión" : "Sin conexión — modo local");
  }
}

function sincronizarCajaTiempoReal() {
  // Caja se sincroniza desde escucharCambiosNube(), usando la API compatible
  // ya cargada por la aplicación. Evita crear un segundo listener duplicado.
  ultimaFirmaCajaRenderizada = firmaCierresCaja(cierresCaja);
}

window.addEventListener("online", () => {
  setEstadoSync("Conexión recuperada — sincronizando...");
  clearTimeout(temporizadorGuardadoNube);
  intentosGuardadoNube = 0;
  if (guardadoNubePendiente) guardarEnNube(false);
  else setTimeout(() => setEstadoSync("Online actualizado"), 700);
});

window.addEventListener("offline", () => {
  setEstadoSync("Sin conexión — modo local");
});

function iniciarModuloCaja() {
  if (window.__FRATELLO_CAJA_INICIADA__) {
    cargarCierreSeleccionadoCaja();
    renderCajaAdmin();
    renderDashboardCaja();
    return;
  }
  window.__FRATELLO_CAJA_INICIADA__ = true;

  cargarCajaLocal();

  if ($("cajaFecha")) $("cajaFecha").value = hoyISOCaja();
  if ($("cajaAdminFecha")) $("cajaAdminFecha").value = hoyISOCaja();
  if ($("mesLibroCaja")) $("mesLibroCaja").value = hoyISOCaja().slice(0, 7);

  renderPersonasCaja();
  renderGastosCaja();

  $("btnAgregarGastoCaja")?.addEventListener("click", agregarGastoCaja);
  $("btnGuardarCierreCaja")?.addEventListener("click", guardarCierreCaja);
  $("cajaFecha")?.addEventListener("change", cargarCierreSeleccionadoCaja);
  $("cajaTurno")?.addEventListener("change", cargarCierreSeleccionadoCaja);
  $("btnVolverResumenAdministracion")?.addEventListener("click", mostrarMenuAdministracion);
  $("btnActualizarCajaAdmin")?.addEventListener("click", () => {
    renderCajaAdmin();
    renderDashboardCaja();
  });
  $("cajaAdminFecha")?.addEventListener("change", renderCajaAdmin);
  $("filtroPeriodoCaja")?.addEventListener("change", renderIndicadoresCaja);
  $("mesLibroCaja")?.addEventListener("change", renderLibroDiarioCaja);
  $("libroDiarioCaja")?.addEventListener("click", evento => {
    const boton = evento.target.closest(".btnDetalleDiaCaja");
    if (!boton) return;
    abrirDetalleDiaCaja(boton.dataset.fechaCaja);
  });
  $("btnCerrarDetalleDiaCaja")?.addEventListener("click", evento => {
    evento.preventDefault();
    evento.stopPropagation();
    cerrarDetalleDiaCaja();
  });

  $("modalDetalleDiaCaja")?.addEventListener("click", evento => {
    if (evento.target?.id === "modalDetalleDiaCaja") {
      cerrarDetalleDiaCaja();
      return;
    }

    const editar = evento.target.closest(".btnEditarTurnoCaja");
    if (editar) {
      abrirEditorTurnoCaja(editar.dataset.fecha, editar.dataset.turno);
      return;
    }

    const agregarGasto = evento.target.closest(".btnAgregarGastoCajaInline");
    if (agregarGasto) {
      const editor = agregarGasto.closest(".cajaInlineEditor");
      const lista = editor?.querySelector(".cajaInlineExpenses");
      if (lista) lista.insertAdjacentHTML("beforeend", htmlGastoEditorCaja({}, lista.children.length));
      return;
    }

    const quitarGasto = evento.target.closest(".btnQuitarGastoCajaInline");
    if (quitarGasto) {
      const fila = quitarGasto.closest(".cajaInlineExpenseRow");
      const lista = quitarGasto.closest(".cajaInlineExpenses");
      if (lista?.children.length > 1) fila?.remove();
      else {
        fila?.querySelectorAll("input").forEach(input => input.value = "");
      }
      return;
    }

    const cancelar = evento.target.closest(".btnCancelarCajaInline");
    if (cancelar) {
      const host = cancelar.closest(".cajaInlineEditHost");
      if (host) host.innerHTML = "";
      return;
    }

    const guardar = evento.target.closest(".btnGuardarCajaInline");
    if (guardar) {
      guardarEdicionTurnoCaja(guardar.dataset.fecha, guardar.dataset.turno, guardar);
    }
  });

  document.addEventListener("keydown", evento => {
    if (evento.key === "Escape" && !$("modalDetalleDiaCaja")?.classList.contains("hidden")) {
      cerrarDetalleDiaCaja();
    }
  });
  $("btnAgregarPersonaCaja")?.addEventListener("click", () => agregarPersonaCaja("nuevaPersonaCaja"));
  $("btnAdministrarPersonasCajaRapido")?.addEventListener("click", abrirModalPersonasCaja);
  $("btnCerrarModalPersonasCaja")?.addEventListener("click", cerrarModalPersonasCaja);
  $("btnAgregarPersonaCajaRapida")?.addEventListener("click", () => agregarPersonaCaja("nuevaPersonaCajaRapida"));
  $("modalPersonasCaja")?.addEventListener("click", evento => {
    if (evento.target?.id === "modalPersonasCaja") cerrarModalPersonasCaja();
  });

  ["click", "touchstart", "keydown", "input"].forEach(nombreEvento => {
    document.addEventListener(nombreEvento, registrarActividadCajaAdmin, { passive: true });
  });


  mostrarModoCaja("empleado");
}

window.agregarGastoCaja = agregarGastoCaja;
window.actualizarGastoCaja = actualizarGastoCaja;
window.eliminarGastoCaja = eliminarGastoCaja;
window.editarCierreDesdeAdminCaja = editarCierreDesdeAdminCaja;
window.eliminarCierreCajaAdmin = eliminarCierreCajaAdmin;
window.eliminarPersonaCaja = eliminarPersonaCaja;
window.abrirDetalleDiaCaja = abrirDetalleDiaCaja;
window.cerrarDetalleDiaCaja = cerrarDetalleDiaCaja;
window.abrirEditorTurnoCaja = abrirEditorTurnoCaja;
window.guardarEdicionTurnoCaja = guardarEdicionTurnoCaja;
window.agregarGastoCajaInline = agregarGastoCajaInline;
window.quitarGastoCajaInline = quitarGastoCajaInline;
window.cancelarEdicionCajaInline = cancelarEdicionCajaInline;

async function init() {
  iniciarModuloCaja();
  iniciarAccesoAdministrador();
  iniciarModuloAdministracion();

  // v3.0.1: los pedidos fijos se guardan desde cada tarjeta del cliente.
  if ($("btnCargarPedidosFijosFecha")) $("btnCargarPedidosFijosFecha").onclick=cargarPedidosFijosParaFecha;
  if ($("btnNuevoPedidoFijoCliente")) $("btnNuevoPedidoFijoCliente").onclick=()=>crearPedidoFijoCliente();
  if ($("fechaPedido")) $("fechaPedido").addEventListener("change", manejarCambioFechaPedidos);
  if ($("checkPedidoFuturo")) {
    $("checkPedidoFuturo").addEventListener("change", () => actualizarSelectorPedidoFuturo());
  }

  if ($("btnAgregarListaPrecio")) {
    $("btnAgregarListaPrecio").onclick = agregarListaPrecioPersonalizada;
  }

  if ($("btnGuardarListasPrecios")) {
    $("btnGuardarListasPrecios").onclick = guardarListasPrecios;
  }
  if ($("btnAgregarProductoCatalogo")) $("btnAgregarProductoCatalogo").onclick = agregarProductoCatalogo;
  if ($("listaAdministradorProductos")) $("listaAdministradorProductos").onclick = manejarClicksAdministradorProductos;
  renderAdministradorProductos();

  const btnContinuarResumen = $("btnContinuarResumen");
  if (btnContinuarResumen) {
    btnContinuarResumen.onclick = continuarAlResumenSiEstaConfirmado;
  }

  const btnBorrarNotificaciones = $("btnBorrarNotificaciones");
  if (btnBorrarNotificaciones) {
    btnBorrarNotificaciones.onclick = borrarTodasLasNotificaciones;
  }

  actualizarEstadoColaRecordatorios();

  
  let ultimaFechaOperativa = fechaOperativaActual();
  setInterval(() => {
    const nuevaFechaOperativa = fechaOperativaActual();
    if (nuevaFechaOperativa !== ultimaFechaOperativa) {
      ultimaFechaOperativa = nuevaFechaOperativa;
      if ($("checkPedidoFuturo") && !$("checkPedidoFuturo").checked) {
        actualizarSelectorPedidoFuturo();
      }
      renderPanelPedidosSemana();
      renderPedidosFuturos();
      depurarPedidosHoyPorJornada();
      renderPedidosHoy();
    }
  }, 60000);

  depurarPedidosHoyPorJornada();
  renderPedidosHoy();
  iniciarNavegacionFratello();

  document.addEventListener("click", evento => {
    const salida = evento.target.closest("#btnInicio, [data-volver='true'], .volverInicio, .menuButton");
    if (salida && cajaAdminActivo) bloquearCajaAdmin();
    if (salida && administracionPrivadaActiva) bloquearAdministracion();
  });

  procesarEntradaDesdeNotificacion();

  const btnActualizarNotificaciones = $("btnActualizarNotificaciones");
  if (btnActualizarNotificaciones) {
    btnActualizarNotificaciones.addEventListener(
      "click",
      cargarHistorialNotificaciones
    );
  }

  const btnActivarNotificaciones = $("btnActivarNotificaciones");

  [
    "chkNotificacionesActivas",
    "chkNotificacionesSonido",
    "chkNotificacionesVibracion",
    "chkNotificacionesBanners",
    "chkNotificacionesAgrupar"
  ].forEach(id => {
    $(id)?.addEventListener("change", cambiarConfiguracionNotificacionesDesdePantalla);
  });

  renderConfiguracionNotificaciones();
  enviarPreferenciasNotificacionesAlServiceWorker();
  marcarNotificacionesVistasAlAbrirApp();
  const btnProbarNotificacion = $("btnProbarNotificacion");

  if (btnActivarNotificaciones) {
    btnActivarNotificaciones.addEventListener("click", activarNotificacionesFratello);
  }

  if (btnProbarNotificacion) {
    btnProbarNotificacion.addEventListener("click", probarNotificacionFratello);
  }

  actualizarEstadoNotificaciones();

  const btnActualizarDatos = $("btnActualizarDatos");
  if (btnActualizarDatos) {
    btnActualizarDatos.addEventListener("click", actualizarDatosManual);
  }
  const btnActualizarGlobal = $("btnActualizarGlobal");
  if (btnActualizarGlobal) {
    btnActualizarGlobal.addEventListener("click", actualizarDatosManual);
  }


  const btnGuardarClienteCompleto = $("btnGuardarClienteCompleto");
  const btnLimpiarClienteCompleto = $("btnLimpiarClienteCompleto");

  if (btnGuardarClienteCompleto) {
    btnGuardarClienteCompleto.addEventListener("click", guardarClienteCompleto);
  }

  if (btnLimpiarClienteCompleto) {
    btnLimpiarClienteCompleto.addEventListener("click", limpiarFormularioClienteCompleto);
  }

  if (!Array.isArray(clientes) || clientes.length === 0) clientes = [...clientesIniciales];
  await cargarDesdeNube();
  await iniciarPedidosModuloNube();
  await iniciarSincronizacionModulosFinancieros();
  renderPersonasCaja();
  cargarCierreSeleccionadoCaja();
  renderCajaAdmin();
  renderDashboardCaja();
  sincronizarCajaTiempoReal();
  validarClientes();

  // v1.06: después de recuperar Firebase, volver a dibujar catálogo y precios.
  renderAdministradorProductos();
  renderListasPrecios();
  escucharCambiosNube();
  escucharHistorialNotificaciones();
  aplicarPermisosUsuario();
  if ($("fechaPedido") && !$("fechaPedido").value) $("fechaPedido").value = fechaEntregaPredeterminada();
  if ($("fechaCargarPedidosFijos")) $("fechaCargarPedidosFijos").value = fechaISOManana();
  actualizarSelectorPedidoFuturo();
  fechasDesdeHoyHastaDomingo().forEach(fecha => asegurarPedidosFijosParaFecha(fecha, false));
  renderClientes();

  if ($("cliente")) $("cliente").onchange = limpiarPedidoCrudo;
  if ($("btnAgregarCliente")) $("btnAgregarCliente").onclick = agregarCliente;
  if ($("btnModificarCliente")) $("btnModificarCliente").onclick = modificarCliente;

  $("diaProduccion").onchange = () => {
    renderProduccion();
    calcularDiferencias();
  };

  $("btnDesbloquearProduccion").onclick = desbloquearProduccion;
  $("btnBloquearProduccion").onclick = bloquearProduccion;
  $("btnGuardarProduccion").onclick = guardarProduccion;
  $("btnEditarPredeterminada").onclick = activarEdicionPredeterminada;
  $("btnGuardarPredeterminada").onclick = guardarPredeterminada;
  $("btnCancelarPredeterminada").onclick = cancelarEdicionPredeterminada;

  $("btnProcesar").onclick = () => procesarPedidoActual();
  $("btnLimpiarPedido").onclick = () => $("pedidoCrudo").value = "";
  $("btnCalcular").onclick = calcularDiferencias;
  if ($("btnWhatsAppGrupo")) $("btnWhatsAppGrupo").onclick = generarMensajeGrupoFratello;
  if ($("btnRecordarCliente")) $("btnRecordarCliente").onclick = recordarPedidoCliente;
  if ($("btnBorrarMemoriaEnvio")) $("btnBorrarMemoriaEnvio").onclick = borrarMemoriaEnvio;
  if ($("btnExportar")) $("btnExportar").onclick = copiarResumen;
  if ($("btnReset")) $("btnReset").onclick = resetDatos;
  if ($("btnVistaPedidos")) $("btnVistaPedidos").onclick = generarVistaPedidos;
  if ($("btnCerrarModalImpresion")) $("btnCerrarModalImpresion").onclick = cerrarModalImpresion;
  if ($("btnCerrarModalImpresion2")) $("btnCerrarModalImpresion2").onclick = cerrarModalImpresion;
  if ($("cerrarModalBackdrop")) $("cerrarModalBackdrop").onclick = cerrarModalImpresion;

  document.addEventListener("keydown", evento => {
    if (evento.key === "Escape" && !$("modalImpresion")?.classList.contains("hidden")) {
      cerrarModalImpresion();
    }
  });

  window.addEventListener("pageshow", liberarScrollTicket);
  if ($("btnImprimirImagenPedidos")) $("btnImprimirImagenPedidos").onclick = imprimirImagenPedidos;
  if ($("btnCompartirImagenPedidos")) $("btnCompartirImagenPedidos").onclick = compartirImagenPedidos;
  if ($("btnGuardarImagenPedidos")) $("btnGuardarImagenPedidos").onclick = guardarImagenPedidos;
  if ($("btnDescargarPdfPedidos")) $("btnDescargarPdfPedidos").onclick = descargarPdfPedidos;
  if ($("btnBorrarSeleccionados")) $("btnBorrarSeleccionados").onclick = borrarPedidosSeleccionados;

  iniciarSincronizacionDia();

  if (window.location.hash === "#notificaciones") {
    abrirSeccionFratello("seccionNotificaciones");
  }

  renderListaClientesCompleta();
  actualizarPanelMemoriaEnvio();
  actualizarCampanaNotificaciones();

  renderProduccion();
  renderPedidosCargados();
  renderPedidosFuturos();
  renderPedidosHoy();
  renderTicketsPorDia();
  inicializarIdsPedidosFormularioConocidos();
  migrarPedidosFijosV301();
  repararPedidosConParserV311();
  renderPedidosRecibidosFormulario();
  renderSelectorClientesPedidoFijo();
  renderPedidosFijos();
  renderPedidosFuturos();
  renderHistorialPedidos();
  renderListasPrecios();
  calcularDiferencias();
}




window.configurarPedidoFijoCliente=configurarPedidoFijoCliente;
window.actualizarPedidoFijoDesdePedido=actualizarPedidoFijoDesdePedido;
window.duplicarPedidoFijo=duplicarPedidoFijo;
window.crearPedidoFijoCliente=crearPedidoFijoCliente;
window.guardarPedidoFijoTarjeta=guardarPedidoFijoTarjeta;
window.eliminarPedidoFijo=eliminarPedidoFijo;
window.verPedidoFormularioEnFecha=verPedidoFormularioEnFecha;
window.alternarConfirmacionPedido=alternarConfirmacionPedido;
window.cambiarPestanaPedidos=cambiarPestanaPedidos;
window.editarPedidoCargado=editarPedidoCargado;
window.verPedidoFuturo=verPedidoFuturo;
window.repetirPedidoHistorial=repetirPedidoHistorial;
window.editarPedidoFijo=editarPedidoFijo;
window.alternarPedidoFijo=alternarPedidoFijo;
window.eliminarPedidoFijo=eliminarPedidoFijo;
window.eliminarListaPrecioPersonalizada = eliminarListaPrecioPersonalizada;
window.verTicketPedidoHoy = verTicketPedidoHoy;
window.descargarPdfPedidoIndividual = descargarPdfPedidoIndividual;
window.descargarPdfPedidoHoy = descargarPdfPedidoHoy;
window.verTicketIndividual = verTicketIndividual;
window.imprimirTicketIndividual = imprimirTicketIndividual;
window.guardarTicketIndividualJpg = guardarTicketIndividualJpg;
window.imprimirTicketsDelDia = imprimirTicketsDelDia;
window.guardarTicketsDelDiaJpg = guardarTicketsDelDiaJpg;
window.descargarTicketsDelDiaPdf = descargarTicketsDelDiaPdf;
window.guardarJpgPedidoHoy = guardarJpgPedidoHoy;
window.abrirEntregaTicket = abrirEntregaTicket;
window.cerrarEntregaTicketV42 = cerrarEntregaTicketV42;
window.marcarNoEntregadoV42 = marcarNoEntregadoV42;
window.guardarEntregaTicketV42 = guardarEntregaTicketV42;
window.repararPedidosYTicketsDelDia = repararPedidosYTicketsDelDia;
window.reprocesarPedidoFormulario = reprocesarPedidoFormulario;
window.resolverProductoPedido = resolverProductoPedido;
window.resolverUnidadPedido = resolverUnidadPedido;
window.editarClienteCompleto = editarClienteCompleto;
window.eliminarClienteCompleto = eliminarClienteCompleto;
 
if (!window.__FRATELLO_INICIADO__) {
  window.__FRATELLO_INICIADO__ = true;

  init().catch(error => {
    console.error("Error iniciando Fratello:", error);
    registrarErrorFratello("inicio", error);
    const estado = document.getElementById("estadoSync");
    if (estado) estado.textContent = "Error parcial al iniciar";
  });
}


window.recordarClientePendiente = recordarClientePendiente;
window.recordarTodosLosPendientes = recordarTodosLosPendientes;
window.enviarSiguienteRecordatorioPendiente = enviarSiguienteRecordatorioPendiente;
window.borrarTodasLasNotificaciones = borrarTodasLasNotificaciones;



window.alternarNotificacionesCliente = alternarNotificacionesCliente;
